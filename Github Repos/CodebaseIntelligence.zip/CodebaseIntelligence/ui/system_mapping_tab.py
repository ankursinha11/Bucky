"""
System Mapping Tab
==================
Discover equivalent or related system implementations across platforms

Features:
- Cross-system entity mapping (1-to-many)
- AI-powered similarity detection
- File-level links to implementations
- Comparison summaries
"""

import streamlit as st
import pandas as pd
import json
from typing import Dict, Any, List
from datetime import datetime
from pathlib import Path

from services.codebase_copilot import CodebaseCopilot
from services.lineage.lineage_agents import SimilarityAgent
from loguru import logger


def render_system_mapping_tab():
    """
    Render System Mapping tab

    Allows users to find equivalent implementations across systems
    """
    st.subheader("🧩 Cross-System Mapping Discovery")

    st.info("""
    **System Mapping** helps you discover equivalent implementations across platforms.

    **Use Cases:**
    - Find which Databricks pipelines replace an Ab Initio graph
    - Discover all Hadoop workflows that match a Databricks notebook
    - Identify 1-to-many mappings (1 Ab Initio graph → 3 Databricks pipelines)

    **How it works:**
    1. Select source system and enter entity name
    2. AI searches all target systems for similar implementations
    3. Returns ranked matches with similarity scores
    4. Provides AI comparison summary
    """)

    st.markdown("---")

    # Initialize agents if needed
    if 'copilot' not in st.session_state:
        indexer = st.session_state.get('indexer')
        ai_analyzer = st.session_state.get('ai_analyzer')

        st.session_state.copilot = CodebaseCopilot(
            indexer=indexer,
            ai_analyzer=ai_analyzer
        )

    if 'similarity_agent' not in st.session_state:
        indexer = st.session_state.get('indexer')
        logic_comparator = st.session_state.get('comparator')

        st.session_state.similarity_agent = SimilarityAgent(
            indexer=indexer,
            logic_comparator=logic_comparator
        )

    # Input section
    st.markdown("### 📋 Step 1: Select Source Entity")

    col1, col2 = st.columns(2)

    with col1:
        source_system = st.selectbox(
            "Source System",
            options=["Ab Initio", "Hadoop", "Databricks"],
            key="mapping_source_system"
        )

        entity_name = st.text_input(
            f"{source_system} Entity Name",
            placeholder="e.g., customer_load, bdf_download, 100_commGenPrePrep",
            help="Enter workflow, graph, or pipeline name",
            key="mapping_entity_name"
        )

    with col2:
        target_systems = st.multiselect(
            "Search in Target Systems",
            options=["Ab Initio", "Hadoop", "Databricks"],
            default=["Databricks"] if source_system != "Databricks" else ["Hadoop"],
            help="Systems to search for equivalent implementations",
            key="mapping_target_systems"
        )

        min_similarity = st.slider(
            "Minimum Similarity Score",
            min_value=0.0,
            max_value=1.0,
            value=0.5,
            step=0.05,
            help="Filter results by minimum similarity",
            key="mapping_min_similarity"
        )

    # Search button
    if st.button("🔍 Find Equivalent Implementations", type="primary", use_container_width=True):
        if not entity_name:
            st.error("Please enter an entity name")
            return

        if not target_systems:
            st.error("Please select at least one target system")
            return

        # Perform mapping search
        perform_system_mapping(entity_name, source_system, target_systems, min_similarity)

    # Display results
    if 'mapping_results' in st.session_state and st.session_state.mapping_results:
        render_mapping_results(st.session_state.mapping_results)


def perform_system_mapping(
    entity_name: str,
    source_system: str,
    target_systems: List[str],
    min_similarity: float
):
    """
    Perform cross-system mapping search

    Args:
        entity_name: Entity to find equivalents for
        source_system: Source system (Ab Initio, Hadoop, Databricks)
        target_systems: Target systems to search
        min_similarity: Minimum similarity threshold
    """
    progress_bar = st.progress(0)
    status_text = st.empty()

    # Map display names to internal names
    system_map = {
        "Ab Initio": "abinitio",
        "Hadoop": "hadoop",
        "Databricks": "databricks"
    }

    source_sys = system_map[source_system]
    target_sys = [system_map[t] for t in target_systems]

    try:
        status_text.text(f"🔍 Searching for '{entity_name}' in {source_system}...")
        progress_bar.progress(20)

        # Step 1: Use Copilot to get source entity context
        copilot = st.session_state.copilot
        source_context = copilot.retrieve_context_for_query(
            query=entity_name,
            systems=[source_sys],
            context_type="mapping"
        )

        logger.info(f"Found source context from {len(source_context.files_read)} files")

        status_text.text(f"🔍 Searching for equivalents in {len(target_sys)} target systems...")
        progress_bar.progress(50)

        # Step 2: Search each target system
        all_matches = []

        for target_system in target_sys:
            matches = search_target_system(
                entity_name=entity_name,
                source_system=source_sys,
                target_system=target_system,
                min_similarity=min_similarity
            )
            all_matches.extend(matches)

        progress_bar.progress(80)

        # Step 3: Generate AI comparison summaries
        status_text.text("🤖 Generating AI comparison summaries...")

        for match in all_matches:
            match['ai_summary'] = generate_match_summary(
                entity_name, source_sys, match
            )

        progress_bar.progress(100)

        # Store results
        st.session_state.mapping_results = {
            'source_entity': entity_name,
            'source_system': source_system,
            'target_systems': target_systems,
            'matches': all_matches,
            'total_matches': len(all_matches),
            'timestamp': datetime.now().isoformat()
        }

        status_text.empty()
        progress_bar.empty()

        st.success(f"✓ Found {len(all_matches)} equivalent implementations across {len(target_sys)} systems")

    except Exception as e:
        st.error(f"Error performing system mapping: {e}")
        logger.error(f"System mapping error: {e}", exc_info=True)
    finally:
        progress_bar.empty()
        status_text.empty()


def search_target_system(
    entity_name: str,
    source_system: str,
    target_system: str,
    min_similarity: float
) -> List[Dict[str, Any]]:
    """
    Search a target system for equivalent implementations

    Returns list of matches with similarity scores
    """
    indexer = st.session_state.get('indexer')
    if not indexer:
        return []

    collection_name = f"{target_system}_collection"

    try:
        # Search using indexer
        results = indexer.search_multi_collection(
            query=entity_name,
            collections=[collection_name],
            top_k=20  # Get top 20 candidates
        )

        if collection_name not in results:
            return []

        matches = []

        for result in results[collection_name]:
            metadata = result.get('metadata', {})
            similarity = result.get('distance', 0.0)

            # Convert distance to similarity (assuming cosine distance)
            # Lower distance = higher similarity
            similarity_score = 1.0 - min(similarity, 1.0)

            if similarity_score >= min_similarity:
                match = {
                    'target_system': target_system,
                    'entity_name': metadata.get('file_name', 'unknown'),
                    'file_path': metadata.get('absolute_file_path', ''),
                    'similarity_score': similarity_score,
                    'description': result.get('content', '')[:200],  # First 200 chars
                    'metadata': metadata
                }
                matches.append(match)

        # Sort by similarity (highest first)
        matches.sort(key=lambda x: x['similarity_score'], reverse=True)

        logger.info(f"Found {len(matches)} matches in {target_system}")

        return matches

    except Exception as e:
        logger.error(f"Error searching {target_system}: {e}")
        return []


def generate_match_summary(
    source_entity: str,
    source_system: str,
    match: Dict[str, Any]
) -> str:
    """
    Generate AI summary of why two entities match

    Args:
        source_entity: Source entity name
        source_system: Source system
        match: Match dictionary with target entity info

    Returns:
        AI-generated summary string
    """
    ai_analyzer = st.session_state.get('ai_analyzer')
    if not ai_analyzer or not ai_analyzer.enabled:
        return f"Similar implementation detected (similarity: {match['similarity_score']:.0%})"

    # Read target file content
    target_file = match.get('file_path')
    target_content = ""

    if target_file and Path(target_file).exists():
        try:
            with open(target_file, 'r', encoding='utf-8', errors='ignore') as f:
                target_content = f.read()[:3000]  # First 3000 chars
        except:
            pass

    prompt = f"""Analyze why these two entities are similar.

Source: {source_system}.{source_entity}
Target: {match['target_system']}.{match['entity_name']}
Similarity Score: {match['similarity_score']:.0%}

Target Entity Content (first 3000 chars):
```
{target_content}
```

Provide a 1-2 sentence summary explaining:
1. What this target entity does
2. Why it's similar to the source entity
3. Any key differences

Keep it concise and actionable.
"""

    try:
        response = ai_analyzer.client.chat.completions.create(
            model=ai_analyzer.deployment_name,
            messages=[
                {"role": "system", "content": "You are a data pipeline expert. Provide concise, actionable summaries."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.0,
            max_tokens=200
        )

        return response.choices[0].message.content.strip()

    except Exception as e:
        logger.debug(f"AI summary generation failed: {e}")
        return f"Similar implementation detected (similarity: {match['similarity_score']:.0%})"


def render_mapping_results(results: Dict[str, Any]):
    """
    Display system mapping results

    Args:
        results: Mapping results dictionary
    """
    st.markdown("---")
    st.markdown("### 📊 Step 2: Mapping Results")

    # Summary metrics
    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric("Source Entity", results['source_entity'])
    with col2:
        st.metric("Total Matches", results['total_matches'])
    with col3:
        avg_similarity = sum(m['similarity_score'] for m in results['matches']) / len(results['matches']) if results['matches'] else 0
        st.metric("Avg Similarity", f"{avg_similarity:.0%}")

    # Group matches by target system
    matches_by_system = {}
    for match in results['matches']:
        system = match['target_system']
        if system not in matches_by_system:
            matches_by_system[system] = []
        matches_by_system[system].append(match)

    # Display each system's matches
    for system, matches in matches_by_system.items():
        st.markdown("---")

        with st.expander(
            f"📊 {system.upper()} - {len(matches)} matches",
            expanded=True
        ):
            # Show mapping type
            if len(matches) == 1:
                st.info("🔵 **1-to-1 Mapping**: Single equivalent implementation found")
            else:
                st.warning(f"🔶 **1-to-Many Mapping**: Source entity maps to {len(matches)} implementations")

            # Display matches as table
            matches_data = []
            for idx, match in enumerate(matches, 1):
                matches_data.append({
                    "#": idx,
                    "Entity Name": match['entity_name'],
                    "Similarity": f"{match['similarity_score']:.1%}",
                    "File Path": match['file_path']
                })

            df = pd.DataFrame(matches_data)
            st.dataframe(df, use_container_width=True, hide_index=True)

            # Detailed view for each match
            st.markdown("**Detailed Analysis:**")

            for idx, match in enumerate(matches, 1):
                with st.container():
                    st.markdown(f"**{idx}. {match['entity_name']}** (Similarity: {match['similarity_score']:.0%})")

                    # AI Summary
                    if 'ai_summary' in match:
                        st.markdown(f"💡 {match['ai_summary']}")

                    # File link
                    if match['file_path']:
                        st.markdown(f"📄 **File**: `{match['file_path']}`")

                    # Show snippet
                    if match.get('description'):
                        with st.expander("View snippet"):
                            st.code(match['description'], language="text")

                    st.markdown("---")

    # Export results
    st.markdown("### 📤 Export Mapping Results")

    col1, col2 = st.columns(2)

    with col1:
        if st.button("📥 Download as JSON", use_container_width=True):
            json_str = json.dumps(results, indent=2)

            st.download_button(
                label="Download JSON",
                data=json_str,
                file_name=f"system_mapping_{results['source_entity']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json"
            )

    with col2:
        if st.button("📊 Download as Excel", use_container_width=True):
            # Create Excel with all matches
            all_matches_data = []
            for match in results['matches']:
                all_matches_data.append({
                    "Source Entity": results['source_entity'],
                    "Source System": results['source_system'],
                    "Target Entity": match['entity_name'],
                    "Target System": match['target_system'],
                    "Similarity Score": match['similarity_score'],
                    "File Path": match['file_path'],
                    "AI Summary": match.get('ai_summary', '')
                })

            df = pd.DataFrame(all_matches_data)

            import io
            output = io.BytesIO()
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='System_Mappings', index=False)

            output.seek(0)

            st.download_button(
                label="Download Excel",
                data=output,
                file_name=f"system_mapping_{results['source_entity']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )

    # Comparison view (if multiple matches)
    if results['total_matches'] > 1:
        st.markdown("---")
        st.markdown("### 🔄 Cross-Implementation Comparison")

        st.info("""
        Select up to 3 implementations to compare side-by-side.
        This will show you the differences in logic, transformations, and data flow.
        """)

        # Allow selecting matches for comparison
        selected_matches = st.multiselect(
            "Select implementations to compare:",
            options=[f"{m['target_system']}.{m['entity_name']}" for m in results['matches']],
            max_selections=3,
            key="comparison_selection"
        )

        if len(selected_matches) >= 2:
            if st.button("🔍 Compare Selected", type="primary"):
                st.info("Comparison feature will use LogicComparator to show detailed side-by-side analysis")
                # This would integrate with existing LogicComparator
                # For now, placeholder
