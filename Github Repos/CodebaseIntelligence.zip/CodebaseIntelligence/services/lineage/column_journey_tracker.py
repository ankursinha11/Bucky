"""
Column Journey Tracker
======================
Trace a single column's complete path across entire repository

Unlike workflow-based lineage, this searches ALL scripts for a specific
column and builds its complete transformation journey.
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from loguru import logger
from pathlib import Path
import json
import re


@dataclass
class ColumnOccurrence:
    """Single occurrence of a column in a script"""
    script_name: str = ""
    script_path: str = ""
    system: str = ""
    column_name: str = ""
    table_name: str = ""
    role: str = ""  # "source", "target", "transformation"
    transformation: str = ""
    code_snippet: str = ""
    input_table: str = ""
    output_table: str = ""
    confidence: float = 0.0


@dataclass
class JourneyStep:
    """Single step in column journey"""
    step_number: int = 0
    source_table: str = ""
    source_column: str = ""
    script_name: str = ""
    script_path: str = ""
    transformation: str = ""
    transformation_type: str = ""
    target_table: str = ""
    target_column: str = ""
    code_snippet: str = ""


@dataclass
class ColumnJourney:
    """Complete journey of a column"""
    column_name: str = ""
    system: str = ""
    steps: List[JourneyStep] = None
    total_steps: int = 0
    source_table: str = ""
    target_table: str = ""
    confidence: float = 0.0
    all_occurrences: List[ColumnOccurrence] = None

    def __post_init__(self):
        if self.steps is None:
            self.steps = []
        if self.all_occurrences is None:
            self.all_occurrences = []

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return {
            "column_name": self.column_name,
            "system": self.system,
            "steps": [asdict(step) for step in self.steps],
            "total_steps": self.total_steps,
            "source_table": self.source_table,
            "target_table": self.target_table,
            "confidence": self.confidence,
            "all_occurrences": [asdict(occ) for occ in self.all_occurrences]
        }


class ColumnJourneyTracker:
    """
    Track column lineage across entire repository

    This provides column-centric lineage instead of workflow-centric lineage.
    User enters a column name and sees its complete transformation path.
    """

    def __init__(self, indexer=None, ai_analyzer=None):
        """
        Initialize column journey tracker

        Args:
            indexer: MultiCollectionIndexer for searching indexed data
            ai_analyzer: AIScriptAnalyzer for extracting column context
        """
        self.indexer = indexer
        self.ai_analyzer = ai_analyzer

    def track_column_journey(
        self,
        column_name: str,
        system: str,
        target_systems: Optional[List[str]] = None
    ) -> Dict[str, ColumnJourney]:
        """
        Track complete journey of a column across systems

        Args:
            column_name: Column to track (e.g., "SSN", "customer_id")
            system: Source system (hadoop, databricks, abinitio)
            target_systems: Systems to find equivalent journey

        Returns:
            Dict mapping system_name → ColumnJourney
        """
        logger.info(f"🔍 Tracking column journey: {column_name} in {system}")

        # Step 1: Find all occurrences in source system
        occurrences = self._find_column_occurrences(column_name, system)
        logger.info(f"  ✓ Found {len(occurrences)} occurrences of {column_name}")

        # Step 2: Build journey from occurrences
        journey = self._build_journey(occurrences, column_name, system)
        logger.info(f"  ✓ Built journey with {len(journey.steps)} steps")

        results = {system: journey}

        # Step 3: Find equivalent journeys in target systems
        if target_systems:
            for target_system in target_systems:
                logger.info(f"  🔍 Searching for equivalent in {target_system}...")
                target_journey = self._find_equivalent_journey(
                    journey, target_system, column_name
                )
                if target_journey and target_journey.total_steps > 0:
                    results[target_system] = target_journey
                    logger.info(f"    ✓ Found equivalent journey ({target_journey.total_steps} steps)")
                else:
                    logger.info(f"    ⚠️ No equivalent journey found")

        return results

    def _find_column_occurrences(
        self,
        column_name: str,
        system: str
    ) -> List[ColumnOccurrence]:
        """
        Search entire indexed collection for column mentions

        Strategy:
        1. Full-text search for column name in all scripts
        2. Use AI to extract context (input, output, transformation)
        3. Extract table name and transformation logic
        """
        if not self.indexer:
            logger.warning("No indexer available for column search")
            return []

        collection_name = f"{system}_collection"
        occurrences = []

        # Search indexed data
        try:
            search_results = self.indexer.search_multi_collection(
                query=column_name,
                collections=[collection_name],
                top_k=50  # Get up to 50 scripts mentioning this column
            )

            if collection_name not in search_results:
                logger.warning(f"No results found in {collection_name}")
                return []

            logger.info(f"  📁 Found {len(search_results[collection_name])} scripts to analyze")

            for idx, result in enumerate(search_results[collection_name]):
                metadata = result.get("metadata", {})
                content = result.get("content", "")

                # Read full file content
                file_path = metadata.get("absolute_file_path")
                full_content = self._read_file_content(file_path, content)

                # Check if column actually appears in content
                if not self._column_appears_in_content(column_name, full_content):
                    continue

                # Use AI to extract column context
                if self.ai_analyzer and self.ai_analyzer.enabled:
                    column_contexts = self._extract_column_context(
                        full_content, column_name, metadata.get("file_name", "")
                    )

                    if column_contexts:
                        for ctx in column_contexts:
                            occurrence = ColumnOccurrence(
                                script_name=metadata.get("file_name", ""),
                                script_path=file_path or "",
                                system=system,
                                column_name=column_name,
                                table_name=ctx.get("table_name", ""),
                                role=ctx.get("role", "unknown"),
                                transformation=ctx.get("transformation", ""),
                                code_snippet=ctx.get("code_snippet", ""),
                                input_table=ctx.get("input_table", ""),
                                output_table=ctx.get("output_table", ""),
                                confidence=ctx.get("confidence", 0.7)
                            )
                            occurrences.append(occurrence)
                else:
                    # Fallback: Basic text parsing if AI not available
                    occurrence = self._basic_column_extraction(
                        full_content, column_name, metadata, file_path, system
                    )
                    if occurrence:
                        occurrences.append(occurrence)

        except Exception as e:
            logger.error(f"Error searching for column: {e}", exc_info=True)

        return occurrences

    def _read_file_content(self, file_path: Optional[str], fallback_content: str) -> str:
        """Read full file content from disk"""
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()
            except Exception as e:
                logger.debug(f"Could not read file {file_path}: {e}")

        return fallback_content

    def _column_appears_in_content(self, column_name: str, content: str) -> bool:
        """Check if column name appears in content (case-insensitive)"""
        # Match whole words only to avoid false positives
        pattern = r'\b' + re.escape(column_name) + r'\b'
        return bool(re.search(pattern, content, re.IGNORECASE))

    def _extract_column_context(
        self,
        content: str,
        column_name: str,
        script_name: str
    ) -> List[Dict[str, Any]]:
        """
        Use AI to extract column context from script

        Returns list of occurrences with their context
        """
        if not self.ai_analyzer or not self.ai_analyzer.enabled:
            return []

        prompt = f"""Analyze this script and find all references to column '{column_name}'.

Script: {script_name}
Content (first 6000 chars):
```
{content[:6000]}
```

For EACH occurrence of '{column_name}' (case-insensitive match), extract:
1. table_name: Which table this column belongs to
2. role: "source" (read from), "target" (written to), or "transformation" (modified)
3. transformation: What transformation is applied (e.g., "TRIM", "UPPER", "MASK", "JOIN", "FILTER")
4. code_snippet: 1-2 lines showing the transformation
5. input_table: Where the data comes from
6. output_table: Where the data goes to
7. confidence: 0.0-1.0 how confident you are this is the right column

Return JSON array (ONLY JSON, no markdown):
[
  {{
    "table_name": "customer_staging",
    "role": "source",
    "transformation": "TRIM",
    "code_snippet": "customer_clean = FOREACH customer_staging GENERATE TRIM(SSN);",
    "input_table": "customer_raw",
    "output_table": "customer_staging",
    "confidence": 0.9
  }}
]

If '{column_name}' is not found, return: []

IMPORTANT: Return ONLY the JSON array, no other text.
"""

        try:
            response = self.ai_analyzer.client.chat.completions.create(
                model=self.ai_analyzer.deployment_name,
                messages=[
                    {"role": "system", "content": "You are an expert data engineer analyzing ETL scripts. Return only valid JSON, no markdown."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.0,
                max_tokens=2000
            )

            result_text = response.choices[0].message.content.strip()

            # Remove markdown code blocks if present
            result_text = re.sub(r'^```json?\s*', '', result_text)
            result_text = re.sub(r'\s*```$', '', result_text)

            # Parse JSON
            try:
                occurrences = json.loads(result_text)
                return occurrences if isinstance(occurrences, list) else []
            except json.JSONDecodeError as e:
                logger.debug(f"JSON parse error: {e}")
                # Try to extract JSON array
                json_match = re.search(r'\[.*\]', result_text, re.DOTALL)
                if json_match:
                    occurrences = json.loads(json_match.group())
                    return occurrences if isinstance(occurrences, list) else []
                return []

        except Exception as e:
            logger.debug(f"Could not extract column context with AI: {e}")
            return []

    def _basic_column_extraction(
        self,
        content: str,
        column_name: str,
        metadata: Dict[str, Any],
        file_path: Optional[str],
        system: str
    ) -> Optional[ColumnOccurrence]:
        """
        Fallback: Basic text parsing if AI not available

        Just find lines containing the column and extract context
        """
        lines = content.split('\n')
        for line_num, line in enumerate(lines):
            if re.search(r'\b' + re.escape(column_name) + r'\b', line, re.IGNORECASE):
                return ColumnOccurrence(
                    script_name=metadata.get("file_name", ""),
                    script_path=file_path or "",
                    system=system,
                    column_name=column_name,
                    table_name="unknown",
                    role="unknown",
                    transformation="unknown",
                    code_snippet=line.strip(),
                    input_table="",
                    output_table="",
                    confidence=0.5
                )

        return None

    def _build_journey(
        self,
        occurrences: List[ColumnOccurrence],
        column_name: str,
        system: str
    ) -> ColumnJourney:
        """
        Build journey from occurrences

        Algorithm:
        1. Group occurrences by script
        2. Order scripts by dependencies (if detectable)
        3. Create journey steps showing transformation flow
        """
        journey = ColumnJourney(
            column_name=column_name,
            system=system,
            all_occurrences=occurrences
        )

        if not occurrences:
            return journey

        # Group by script and order
        script_groups = {}
        for occ in occurrences:
            if occ.script_name not in script_groups:
                script_groups[occ.script_name] = []
            script_groups[occ.script_name].append(occ)

        # Sort scripts by name (often numbered: 01_extract, 02_transform, etc.)
        sorted_scripts = sorted(script_groups.keys())

        # Build journey steps
        step_num = 1
        for script_name in sorted_scripts:
            script_occs = script_groups[script_name]

            # Create steps from occurrences in this script
            for occ in script_occs:
                step = JourneyStep(
                    step_number=step_num,
                    source_table=occ.input_table or occ.table_name,
                    source_column=occ.column_name,
                    script_name=occ.script_name,
                    script_path=occ.script_path,
                    transformation=occ.transformation,
                    transformation_type=self._classify_transformation(occ.transformation),
                    target_table=occ.output_table or occ.table_name,
                    target_column=occ.column_name,
                    code_snippet=occ.code_snippet
                )
                journey.steps.append(step)
                step_num += 1

        # Set journey metadata
        journey.total_steps = len(journey.steps)
        if journey.steps:
            journey.source_table = journey.steps[0].source_table
            journey.target_table = journey.steps[-1].target_table

        # Calculate confidence based on occurrence quality
        confidences = [occ.confidence for occ in occurrences if occ.confidence > 0]
        journey.confidence = sum(confidences) / len(confidences) if confidences else 0.5

        return journey

    def _classify_transformation(self, transformation: str) -> str:
        """Classify transformation type"""
        trans_lower = transformation.lower()

        if any(kw in trans_lower for kw in ['trim', 'upper', 'lower', 'concat', 'substr']):
            return "STRING_MANIPULATION"
        elif any(kw in trans_lower for kw in ['mask', 'encrypt', 'hash']):
            return "PRIVACY"
        elif any(kw in trans_lower for kw in ['join', 'merge']):
            return "JOIN"
        elif any(kw in trans_lower for kw in ['filter', 'where']):
            return "FILTER"
        elif any(kw in trans_lower for kw in ['group', 'aggregate', 'sum', 'count']):
            return "AGGREGATION"
        elif any(kw in trans_lower for kw in ['cast', 'convert']):
            return "TYPE_CONVERSION"
        else:
            return "OTHER"

    def _find_equivalent_journey(
        self,
        source_journey: ColumnJourney,
        target_system: str,
        column_name: str
    ) -> Optional[ColumnJourney]:
        """
        Find equivalent column journey in target system

        Strategy:
        1. Search for similar column names
        2. Build journey in target system
        3. Return if found
        """
        # Search for column in target system
        similar_columns = self._find_similar_column_names(column_name, target_system)

        for similar_col in similar_columns:
            occurrences = self._find_column_occurrences(similar_col, target_system)
            if occurrences:
                target_journey = self._build_journey(occurrences, similar_col, target_system)
                if target_journey.total_steps > 0:
                    return target_journey

        return None

    def _find_similar_column_names(
        self,
        column_name: str,
        system: str
    ) -> List[str]:
        """
        Find similar column names in target system

        Examples:
        - SSN → social_security_number, ssn, ssn_masked, member_ssn
        - customer_id → customerId, cust_id, customer_key
        """
        variations = [
            column_name,  # Exact match
            column_name.lower(),
            column_name.upper(),
            column_name.replace("_", ""),  # Remove underscores
            column_name.replace("_", ""),  # camelCase version
        ]

        # Add common synonyms
        synonyms = {
            'ssn': ['social_security_number', 'social_security', 'ssn_masked', 'member_ssn'],
            'id': ['identifier', 'key', 'number'],
            'customer': ['cust', 'client'],
            'date': ['dt', 'timestamp', 'time'],
        }

        col_lower = column_name.lower()
        for key, values in synonyms.items():
            if key in col_lower:
                variations.extend(values)

        # Remove duplicates while preserving order
        seen = set()
        unique_variations = []
        for v in variations:
            if v.lower() not in seen:
                seen.add(v.lower())
                unique_variations.append(v)

        return unique_variations[:10]  # Limit to 10 variations
