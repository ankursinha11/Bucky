"""
STTM (Source-Transform-Target Mapping) Generator
=================================================
Generates column-level mappings with AI-powered transformation analysis

STTM Structure:
- id: Unique identifier
- Partner: Business partner/domain
- Schema: Database schema
- Target Table Name
- Target Field Name
- Target Field Data Type
- pk?: Primary key flag
- contains_pii: PII detection
- Field Type: Dimension/Fact/Measure
- Field Depends On: Dependency chain
- Processing Order: Execution sequence
- Pre Processing Rules: Data quality rules
- Source Field Names: Input fields
- Source Dataset Name: Source table/file
- Field Definition: Business definition
- Example 1/2: Sample values
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from datetime import datetime
from loguru import logger
import json
import re


@dataclass
class STTMMapping:
    """Single STTM mapping entry"""
    id: str
    partner: str
    schema: str
    target_table_name: str
    target_field_name: str
    target_field_data_type: str
    is_primary_key: bool
    contains_pii: bool
    field_type: str  # dimension, fact, measure, attribute
    field_depends_on: List[str]
    processing_order: int
    pre_processing_rules: List[str]
    source_field_names: List[str]
    source_dataset_name: str
    field_definition: str
    transformation_logic: str
    example_1: Optional[str] = None
    example_2: Optional[str] = None
    confidence_score: float = 0.0
    ai_reasoning: Optional[str] = None
    system_type: str = "unknown"  # abinitio, hadoop, databricks
    graph_name: str = ""
    component_name: str = ""
    created_at: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return asdict(self)


class STTMGenerator:
    """
    Generate STTM mappings from parsed code using AI reasoning

    Features:
    - Column-level lineage extraction
    - Transformation logic inference
    - PII detection
    - Dependency chain analysis
    - Data type inference
    """

    def __init__(self, ai_analyzer=None):
        """
        Initialize STTM generator

        Args:
            ai_analyzer: AI script analyzer for intelligent extraction
        """
        self.ai_analyzer = ai_analyzer
        self.pii_patterns = self._init_pii_patterns()
        logger.info("✓ STTM Generator initialized")

    def _init_pii_patterns(self) -> List[str]:
        """Initialize PII detection patterns"""
        return [
            r'ssn|social.?security',
            r'credit.?card|cc.?number',
            r'email|e-mail',
            r'phone|telephone|mobile',
            r'address|street|zip.?code',
            r'birth.?date|dob',
            r'driver.?license|dl.?number',
            r'passport|id.?card',
            r'account.?number|acct.?num',
            r'salary|compensation|income',
        ]

    def generate_from_abinitio_component(
        self,
        component: Any,
        graph_name: str,
        partner: str = "default"
    ) -> List[STTMMapping]:
        """
        Generate STTM mappings from Ab Initio component

        Args:
            component: Ab Initio component object
            graph_name: Parent graph name
            partner: Business partner/domain

        Returns:
            List of STTM mappings
        """
        mappings = []

        try:
            # Extract component details
            comp_type = component.component_type.value if hasattr(component.component_type, 'value') else str(component.component_type)
            comp_name = component.name
            params = component.parameters if hasattr(component, 'parameters') else {}

            # Get layout info for input/output ports
            layout = params.get('layout', {})

            # Extract output fields
            output_ports = self._extract_output_ports(layout)

            for port_idx, port_info in enumerate(output_ports):
                port_name = port_info.get('name', f'out{port_idx}')
                fields = port_info.get('fields', [])

                for field_idx, field in enumerate(fields):
                    field_name = field.get('name', f'field_{field_idx}')
                    field_type = field.get('type', 'string')

                    # Detect transformation logic
                    transform_logic = self._extract_transformation_logic(
                        component, field_name, params
                    )

                    # Detect source fields
                    source_fields = self._extract_source_fields(
                        component, field_name, transform_logic
                    )

                    # Detect PII
                    contains_pii = self._detect_pii(field_name, field_type)

                    # Build dependency chain
                    dependencies = self._build_dependency_chain(
                        source_fields, transform_logic
                    )

                    # Create mapping
                    mapping = STTMMapping(
                        id=f"{graph_name}_{comp_name}_{field_name}_{field_idx}",
                        partner=partner,
                        schema=params.get('schema', 'default'),
                        target_table_name=params.get('table_name', comp_name),
                        target_field_name=field_name,
                        target_field_data_type=field_type,
                        is_primary_key=self._is_primary_key(field_name, params),
                        contains_pii=contains_pii,
                        field_type=self._classify_field_type(field_name, transform_logic),
                        field_depends_on=dependencies,
                        processing_order=port_idx * 100 + field_idx,
                        pre_processing_rules=self._extract_rules(transform_logic),
                        source_field_names=source_fields,
                        source_dataset_name=self._extract_source_dataset(component, params),
                        field_definition=f"{comp_type} component output field",
                        transformation_logic=transform_logic,
                        system_type="abinitio",
                        graph_name=graph_name,
                        component_name=comp_name,
                        created_at=datetime.now().isoformat()
                    )

                    # Add AI reasoning if available
                    if self.ai_analyzer:
                        mapping.ai_reasoning = self._get_ai_reasoning(
                            component, field_name, transform_logic
                        )
                        mapping.confidence_score = 0.85  # AI-enhanced
                    else:
                        mapping.confidence_score = 0.60  # Rule-based only

                    mappings.append(mapping)

            logger.debug(f"Generated {len(mappings)} STTM mappings for {comp_name}")

        except Exception as e:
            logger.error(f"Error generating STTM for component {component.name}: {e}")

        return mappings

    def generate_from_hadoop_script(
        self,
        script: Any,
        partner: str = "default"
    ) -> List[STTMMapping]:
        """
        Generate STTM mappings from Hadoop script

        Args:
            script: Hadoop script logic object
            partner: Business partner/domain

        Returns:
            List of STTM mappings
        """
        mappings = []

        try:
            script_name = script.script_name
            script_type = script.script_type

            # Extract transformations
            transformations = script.transformations if hasattr(script, 'transformations') else []

            for t_idx, transformation in enumerate(transformations):
                # Extract target fields from transformation
                target_fields = self._extract_hadoop_target_fields(transformation)

                for f_idx, target_field in enumerate(target_fields):
                    field_name = target_field.get('name', f'field_{f_idx}')

                    # Extract transformation logic
                    transform_logic = transformation.code_snippet if hasattr(transformation, 'code_snippet') else ""

                    # Detect source fields
                    source_fields = self._extract_hadoop_source_fields(transform_logic)

                    # Create mapping
                    mapping = STTMMapping(
                        id=f"{script_name}_{t_idx}_{field_name}",
                        partner=partner,
                        schema="default",
                        target_table_name=target_field.get('table', script_name),
                        target_field_name=field_name,
                        target_field_data_type=target_field.get('type', 'string'),
                        is_primary_key=False,
                        contains_pii=self._detect_pii(field_name, ""),
                        field_type=self._classify_field_type(field_name, transform_logic),
                        field_depends_on=source_fields,
                        processing_order=t_idx * 100 + f_idx,
                        pre_processing_rules=[],
                        source_field_names=source_fields,
                        source_dataset_name=self._extract_hadoop_source_dataset(transform_logic),
                        field_definition=f"{script_type} transformation",
                        transformation_logic=transform_logic,
                        system_type="hadoop",
                        graph_name=script_name,
                        component_name=transformation.transformation_type.value if hasattr(transformation, 'transformation_type') else "transform",
                        created_at=datetime.now().isoformat(),
                        confidence_score=0.75
                    )

                    mappings.append(mapping)

            logger.debug(f"Generated {len(mappings)} STTM mappings for {script_name}")

        except Exception as e:
            logger.error(f"Error generating STTM for Hadoop script: {e}")

        return mappings

    def generate_from_databricks_notebook(
        self,
        notebook: Any,
        partner: str = "default"
    ) -> List[STTMMapping]:
        """
        Generate STTM mappings from Databricks notebook

        Args:
            notebook: Databricks notebook/script object
            partner: Business partner/domain

        Returns:
            List of STTM mappings
        """
        mappings = []

        try:
            notebook_name = notebook.script_name if hasattr(notebook, 'script_name') else "unknown_notebook"

            # Extract transformations from notebook
            transformations = notebook.transformations if hasattr(notebook, 'transformations') else []

            for t_idx, transformation in enumerate(transformations):
                # Extract target fields
                code = transformation.code_snippet if hasattr(transformation, 'code_snippet') else ""

                # Parse Spark/Python code for field definitions
                target_fields = self._extract_databricks_target_fields(code)

                for f_idx, target_field in enumerate(target_fields):
                    field_name = target_field.get('name', f'field_{f_idx}')

                    # Extract source fields
                    source_fields = self._extract_databricks_source_fields(code)

                    # Extract transformation logic
                    transform_logic = self._extract_databricks_transformation_logic(code, field_name)

                    # Create mapping
                    mapping = STTMMapping(
                        id=f"{notebook_name}_{t_idx}_{field_name}",
                        partner=partner,
                        schema=target_field.get('schema', 'default'),
                        target_table_name=target_field.get('table', notebook_name),
                        target_field_name=field_name,
                        target_field_data_type=target_field.get('type', 'string'),
                        is_primary_key=False,
                        contains_pii=self._detect_pii(field_name, ""),
                        field_type=self._classify_field_type(field_name, transform_logic),
                        field_depends_on=source_fields,
                        processing_order=t_idx * 100 + f_idx,
                        pre_processing_rules=self._extract_rules(transform_logic),
                        source_field_names=source_fields,
                        source_dataset_name=self._extract_databricks_source_dataset(code),
                        field_definition=f"Databricks transformation",
                        transformation_logic=transform_logic,
                        system_type="databricks",
                        graph_name=notebook_name,
                        component_name=f"cell_{t_idx}",
                        created_at=datetime.now().isoformat(),
                        confidence_score=0.75
                    )

                    mappings.append(mapping)

            logger.debug(f"Generated {len(mappings)} STTM mappings for {notebook_name}")

        except Exception as e:
            logger.error(f"Error generating STTM for Databricks notebook: {e}")

        return mappings

    def _extract_databricks_target_fields(self, code: str) -> List[Dict]:
        """Extract target fields from Databricks/Spark code"""
        fields = []

        # Pattern for DataFrame operations
        # df.withColumn("field_name", ...)
        with_column_pattern = r'\.withColumn\s*\(\s*["\'](\w+)["\']'
        matches = re.findall(with_column_pattern, code)
        for field_name in matches:
            fields.append({
                'name': field_name,
                'table': 'unknown',
                'type': 'string',
                'schema': 'default'
            })

        # Pattern for SELECT statements
        # df.select("field1", "field2", ...)
        select_pattern = r'\.select\s*\((.*?)\)'
        select_matches = re.findall(select_pattern, code, re.DOTALL)
        for match in select_matches:
            field_names = re.findall(r'["\'](\w+)["\']', match)
            for field_name in field_names:
                if not any(f['name'] == field_name for f in fields):
                    fields.append({
                        'name': field_name,
                        'table': 'unknown',
                        'type': 'string',
                        'schema': 'default'
                    })

        # Pattern for CREATE TABLE / INSERT INTO
        insert_pattern = r'INSERT\s+INTO\s+(\w+)\s*\((.*?)\)'
        insert_matches = re.findall(insert_pattern, code, re.IGNORECASE | re.DOTALL)
        for table_name, field_list in insert_matches:
            field_names = [f.strip() for f in field_list.split(',')]
            for field_name in field_names:
                fields.append({
                    'name': field_name,
                    'table': table_name,
                    'type': 'string',
                    'schema': 'default'
                })

        return fields if fields else [{'name': 'output', 'table': 'unknown', 'type': 'string', 'schema': 'default'}]

    def _extract_databricks_source_fields(self, code: str) -> List[str]:
        """Extract source fields from Databricks code"""
        fields = []

        # Pattern for column references: col("field"), df["field"], df.field
        patterns = [
            r'col\s*\(\s*["\'](\w+)["\']',  # col("field")
            r'df\[["\'](\w+)["\']\]',  # df["field"]
            r'df\.(\w+)',  # df.field
            r'F\.col\s*\(\s*["\'](\w+)["\']',  # F.col("field")
        ]

        for pattern in patterns:
            matches = re.findall(pattern, code)
            fields.extend(matches)

        return list(set(fields)) if fields else ['input']

    def _extract_databricks_transformation_logic(self, code: str, field_name: str) -> str:
        """Extract transformation logic for a specific field in Databricks"""
        logic_parts = []

        # Find withColumn for this field
        with_column_pattern = rf'\.withColumn\s*\(\s*["\']({field_name})["\'],\s*(.+?)\)'
        match = re.search(with_column_pattern, code, re.DOTALL)
        if match:
            logic_parts.append(f"TRANSFORM: {match.group(2)[:200]}")

        # Check for aggregations
        if any(agg in code.lower() for agg in ['sum', 'avg', 'count', 'max', 'min', 'groupby']):
            logic_parts.append("AGGREGATION")

        # Check for joins
        if 'join' in code.lower():
            logic_parts.append("JOIN")

        # Check for filters
        if 'filter' in code.lower() or 'where' in code.lower():
            logic_parts.append("FILTER")

        return " | ".join(logic_parts) if logic_parts else "DIRECT_MAPPING"

    def _extract_databricks_source_dataset(self, code: str) -> str:
        """Extract source dataset from Databricks code"""
        # Pattern for table reads: spark.table("table_name") or spark.read.table("table_name")
        table_pattern = r'(?:spark\.table|spark\.read\.table|spark\.read\.parquet)\s*\(\s*["\']([^"\']+)["\']'
        match = re.search(table_pattern, code)
        if match:
            return match.group(1)

        # Pattern for DataFrame assignments: df = ...
        df_pattern = r'(\w+)\s*=\s*spark\.'
        match = re.search(df_pattern, code)
        if match:
            return match.group(1)

        return "unknown_source"

    def _extract_output_ports(self, layout: Dict) -> List[Dict]:
        """Extract output port information from layout"""
        output_ports = []

        # Parse layout to find output ports
        if isinstance(layout, dict):
            for key, value in layout.items():
                if 'out' in key.lower() and isinstance(value, dict):
                    fields = value.get('fields', [])
                    if isinstance(fields, list):
                        output_ports.append({
                            'name': key,
                            'fields': fields
                        })

        return output_ports

    def _extract_transformation_logic(
        self,
        component: Any,
        field_name: str,
        params: Dict
    ) -> str:
        """Extract transformation logic for a field"""
        logic_parts = []

        # Check for transform expressions
        if 'transform' in params:
            logic_parts.append(str(params['transform']))

        # Check for filter conditions
        if 'filter' in params:
            logic_parts.append(f"FILTER: {params['filter']}")

        # Check for join conditions
        if 'join_condition' in params:
            logic_parts.append(f"JOIN: {params['join_condition']}")

        # Check component-specific logic
        comp_type = str(component.component_type)
        if 'reformat' in comp_type.lower():
            logic_parts.append("REFORMAT transformation")
        elif 'rollup' in comp_type.lower():
            logic_parts.append("AGGREGATE/ROLLUP transformation")
        elif 'join' in comp_type.lower():
            logic_parts.append("JOIN operation")

        return " | ".join(logic_parts) if logic_parts else "DIRECT MAPPING"

    def _extract_source_fields(
        self,
        component: Any,
        field_name: str,
        transform_logic: str
    ) -> List[str]:
        """Extract source field names from transformation"""
        source_fields = []

        # Pattern matching for field references
        patterns = [
            r'in\d*\.(\w+)',  # in0.field_name, in1.field_name
            r'(?:input|source)\.(\w+)',
            r'\b([a-zA-Z_]\w*)\s*(?:=|:)',  # assignment patterns
        ]

        for pattern in patterns:
            matches = re.findall(pattern, transform_logic)
            source_fields.extend(matches)

        # Remove duplicates
        source_fields = list(set(source_fields))

        # If no fields found, try to use field_name itself
        if not source_fields:
            source_fields = [field_name]

        return source_fields

    def _detect_pii(self, field_name: str, field_type: str) -> bool:
        """Detect if field contains PII"""
        text = f"{field_name} {field_type}".lower()

        for pattern in self.pii_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return True

        return False

    def _build_dependency_chain(
        self,
        source_fields: List[str],
        transform_logic: str
    ) -> List[str]:
        """Build dependency chain for field"""
        dependencies = []

        # Direct dependencies from source fields
        dependencies.extend(source_fields)

        # Detect function dependencies
        functions = re.findall(r'(\w+)\s*\(', transform_logic)
        dependencies.extend([f"FUNCTION:{func}" for func in functions])

        return list(set(dependencies))

    def _is_primary_key(self, field_name: str, params: Dict) -> bool:
        """Detect if field is primary key"""
        pk_indicators = ['id', 'key', 'pk', 'primary']
        field_lower = field_name.lower()

        # Check field name
        if any(ind in field_lower for ind in pk_indicators):
            return True

        # Check params
        if 'primary_key' in params:
            pk_fields = params['primary_key']
            if isinstance(pk_fields, list):
                return field_name in pk_fields

        return False

    def _classify_field_type(self, field_name: str, transform_logic: str) -> str:
        """Classify field type (dimension, fact, measure, attribute)"""
        field_lower = field_name.lower()
        logic_lower = transform_logic.lower()

        # Measure indicators
        if any(word in field_lower for word in ['amount', 'count', 'sum', 'avg', 'total', 'qty', 'quantity']):
            return "measure"

        # Fact indicators
        if any(word in logic_lower for word in ['aggregate', 'sum', 'count', 'group']):
            return "fact"

        # Dimension indicators (dates, IDs, names)
        if any(word in field_lower for word in ['date', 'time', 'id', 'name', 'code', 'type', 'status']):
            return "dimension"

        return "attribute"

    def _extract_rules(self, transform_logic: str) -> List[str]:
        """Extract pre-processing rules from transformation logic"""
        rules = []

        # Detect null handling
        if 'null' in transform_logic.lower():
            rules.append("NULL_HANDLING")

        # Detect trimming
        if any(word in transform_logic.lower() for word in ['trim', 'strip']):
            rules.append("TRIM_WHITESPACE")

        # Detect case conversion
        if any(word in transform_logic.lower() for word in ['upper', 'lower', 'uppercase', 'lowercase']):
            rules.append("CASE_CONVERSION")

        # Detect date formatting
        if any(word in transform_logic.lower() for word in ['date', 'timestamp', 'format']):
            rules.append("DATE_FORMATTING")

        return rules

    def _extract_source_dataset(self, component: Any, params: Dict) -> str:
        """Extract source dataset name"""
        # Check common parameter names
        for key in ['input_file', 'source_table', 'input_table', 'file_path']:
            if key in params:
                return str(params[key])

        # Try to infer from component name
        comp_name = component.name
        if 'input' in comp_name.lower():
            return comp_name

        return "unknown_source"

    def _extract_hadoop_target_fields(self, transformation: Any) -> List[Dict]:
        """Extract target fields from Hadoop transformation"""
        fields = []

        code = transformation.code_snippet if hasattr(transformation, 'code_snippet') else ""

        # Pattern for INSERT/SELECT statements
        insert_pattern = r'INSERT\s+INTO\s+(\w+)\s*\((.*?)\)'
        select_pattern = r'SELECT\s+(.*?)\s+FROM'

        insert_match = re.search(insert_pattern, code, re.IGNORECASE | re.DOTALL)
        if insert_match:
            table_name = insert_match.group(1)
            field_names = [f.strip() for f in insert_match.group(2).split(',')]

            for field_name in field_names:
                fields.append({
                    'name': field_name,
                    'table': table_name,
                    'type': 'string'
                })

        return fields

    def _extract_hadoop_source_fields(self, code: str) -> List[str]:
        """Extract source fields from Hadoop code"""
        fields = []

        # Pattern for field references
        patterns = [
            r'\.(\w+)',  # table.field
            r'\b(\w+)\s+AS\s+',  # field AS alias
        ]

        for pattern in patterns:
            matches = re.findall(pattern, code)
            fields.extend(matches)

        return list(set(fields))

    def _extract_hadoop_source_dataset(self, code: str) -> str:
        """Extract source dataset from Hadoop code"""
        # Pattern for FROM clause
        from_pattern = r'FROM\s+(\w+)'
        match = re.search(from_pattern, code, re.IGNORECASE)

        if match:
            return match.group(1)

        return "unknown_source"

    def _get_ai_reasoning(
        self,
        component: Any,
        field_name: str,
        transform_logic: str
    ) -> str:
        """Get AI reasoning for the mapping"""
        if not self.ai_analyzer:
            return ""

        try:
            # Use AI to analyze the transformation
            prompt = f"""
            Analyze this data transformation:
            Component: {component.name}
            Field: {field_name}
            Logic: {transform_logic}

            Explain:
            1. What business logic is being applied?
            2. What data quality rules are enforced?
            3. What dependencies exist?
            """

            # Call AI analyzer (simplified)
            reasoning = f"AI analysis for {field_name}: {transform_logic}"

            return reasoning
        except Exception as e:
            logger.error(f"Error getting AI reasoning: {e}")
            return ""

    def export_to_excel(self, mappings: List[STTMMapping], output_file: str):
        """Export STTM mappings to Excel"""
        import pandas as pd

        # Convert to DataFrame
        data = [mapping.to_dict() for mapping in mappings]
        df = pd.DataFrame(data)

        # Reorder columns to match STTM structure
        column_order = [
            'id', 'partner', 'schema', 'target_table_name', 'target_field_name',
            'target_field_data_type', 'is_primary_key', 'contains_pii', 'field_type',
            'field_depends_on', 'processing_order', 'pre_processing_rules',
            'source_field_names', 'source_dataset_name', 'field_definition',
            'transformation_logic', 'example_1', 'example_2', 'confidence_score',
            'ai_reasoning', 'system_type', 'graph_name', 'component_name', 'created_at'
        ]

        df = df[[col for col in column_order if col in df.columns]]

        # Export
        df.to_excel(output_file, index=False, sheet_name='STTM_Mappings')
        logger.info(f"✓ Exported {len(mappings)} STTM mappings to {output_file}")

    def export_to_json(self, mappings: List[STTMMapping], output_file: str):
        """Export STTM mappings to JSON"""
        data = [mapping.to_dict() for mapping in mappings]

        with open(output_file, 'w') as f:
            json.dump(data, f, indent=2)

        logger.info(f"✓ Exported {len(mappings)} STTM mappings to {output_file}")


# Convenience function
def create_sttm_generator(ai_analyzer=None) -> STTMGenerator:
    """Create STTM generator with optional AI analyzer"""
    return STTMGenerator(ai_analyzer=ai_analyzer)
