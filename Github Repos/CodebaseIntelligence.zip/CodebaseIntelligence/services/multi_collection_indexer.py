"""
Multi-Collection Indexer - Separate Collections per System
============================================================
Implements the architecture for clean, system-specific retrieval

Collections:
- abinitio_collection: Ab Initio graphs, components, DMLs
- hadoop_collection: Hive, Pig, Spark scripts
- databricks_collection: Notebooks, jobs
- autosys_collection: Job definitions, schedules
- cross_system_links: Autosys→AbInitio, cross-system flows
- documents_collection: PDFs, reports, business docs
"""

from typing import List, Dict, Any, Optional
from pathlib import Path
from loguru import logger

from core.models import Process, Component, Repository, WorkflowFlow
from core.models.script_logic import ScriptLogic
from services.local_search.local_search_client import LocalSearchClient


class MultiCollectionIndexer:
    """
    Index parsed data into separate collections per system

    Benefits:
    - Clean, targeted retrieval
    - Better metadata filtering
    - Easier cross-system comparison
    - Optimized search performance
    """

    def __init__(self, vector_db_path: str = "./outputs/vector_db"):
        """
        Initialize multi-collection indexer

        Args:
            vector_db_path: Base path for vector database
        """
        self.vector_db_path = Path(vector_db_path)
        self.vector_db_path.mkdir(parents=True, exist_ok=True)

        # Create separate search clients for each collection
        self.collections = {}
        self._initialize_collections()

        logger.info("✅ Multi-Collection Indexer initialized")

    def _initialize_collections(self):
        """Initialize all collections"""
        collection_names = [
            "abinitio_collection",
            "hadoop_collection",
            "databricks_collection",
            "autosys_collection",
            "cross_system_links",
            "documents_collection",
            # STTM collections (separate per system for targeted retrieval)
            "sttm_abinitio_collection",
            "sttm_hadoop_collection",
            "sttm_databricks_collection",
        ]

        for name in collection_names:
            client = LocalSearchClient(persist_directory=str(self.vector_db_path))
            client.create_index(name)
            self.collections[name] = client
            logger.info(f"  ✓ Collection ready: {name}")

    def index_abinitio(
        self,
        processes: List[Process],
        components: List[Component],
        raw_mp_data: List[Dict[str, Any]] = None,
    ) -> Dict[str, int]:
        """
        Index Ab Initio data

        Args:
            processes: List of Process objects (graphs)
            components: List of Component objects
            raw_mp_data: Raw MP parsing data (optional)

        Returns:
            Dict with indexed counts
        """
        logger.info("📊 Indexing Ab Initio data...")

        documents = []

        # Index graphs (processes)
        for process in processes:
            doc = self._create_abinitio_graph_document(process)
            documents.append(doc)

        # Index components
        for component in components:
            doc = self._create_abinitio_component_document(component)
            documents.append(doc)

        # Index to collection
        self.collections["abinitio_collection"].index_documents(documents)

        logger.info(f"✓ Indexed {len(documents)} Ab Initio documents")

        return {
            "graphs": len(processes),
            "components": len(components),
            "total": len(documents)
        }

    def index_hadoop(
        self,
        repositories: List[Repository],
        workflow_flows: List[WorkflowFlow],
        script_logics: List[ScriptLogic],
    ) -> Dict[str, int]:
        """
        Index Hadoop data

        Args:
            repositories: Repository objects
            workflow_flows: Workflow flows (Oozie, etc.)
            script_logics: Script logic (Hive, Pig, Spark)

        Returns:
            Dict with indexed counts
        """
        logger.info("📊 Indexing Hadoop data...")

        documents = []

        # Index repositories
        for repo in repositories:
            doc = self._create_repository_document(repo, "hadoop")
            documents.append(doc)

        # Index workflows
        for workflow in workflow_flows:
            doc = self._create_workflow_document(workflow, "hadoop")
            documents.append(doc)

        # Index scripts
        for script in script_logics:
            doc = self._create_script_document(script, "hadoop")
            documents.append(doc)

            # Also index transformations separately
            for trans in script.transformations:
                trans_doc = self._create_transformation_document(script, trans, "hadoop")
                documents.append(trans_doc)

        # Index to collection
        self.collections["hadoop_collection"].index_documents(documents)

        logger.info(f"✓ Indexed {len(documents)} Hadoop documents")

        return {
            "repositories": len(repositories),
            "workflows": len(workflow_flows),
            "scripts": len(script_logics),
            "total": len(documents)
        }

    def index_databricks(
        self,
        repositories: List[Repository],
        workflow_flows: List[WorkflowFlow],
        script_logics: List[ScriptLogic],
    ) -> Dict[str, int]:
        """Index Databricks data"""
        logger.info("📊 Indexing Databricks data...")

        documents = []

        # Similar to Hadoop but in databricks_collection
        for repo in repositories:
            doc = self._create_repository_document(repo, "databricks")
            documents.append(doc)

        for workflow in workflow_flows:
            doc = self._create_workflow_document(workflow, "databricks")
            documents.append(doc)

        for script in script_logics:
            doc = self._create_script_document(script, "databricks")
            documents.append(doc)

        self.collections["databricks_collection"].index_documents(documents)

        logger.info(f"✓ Indexed {len(documents)} Databricks documents")

        return {"total": len(documents)}

    def index_autosys(self, jobs: List[Dict[str, Any]]) -> Dict[str, int]:
        """
        Index Autosys jobs

        Args:
            jobs: List of job dictionaries from Autosys parser

        Returns:
            Dict with indexed counts
        """
        logger.info("📊 Indexing Autosys data...")

        documents = []

        for job in jobs:
            doc = self._create_autosys_job_document(job)
            documents.append(doc)

        self.collections["autosys_collection"].index_documents(documents)

        logger.info(f"✓ Indexed {len(documents)} Autosys jobs")

        return {"jobs": len(documents)}

    def index_cross_system_links(
        self,
        autosys_jobs: List[Dict[str, Any]],
        abinitio_processes: List[Process],
    ) -> Dict[str, int]:
        """
        Create and index cross-system links (Autosys → Ab Initio)

        Args:
            autosys_jobs: Autosys job definitions
            abinitio_processes: Ab Initio processes (graphs)

        Returns:
            Dict with link counts
        """
        logger.info("🔗 Creating cross-system links...")

        documents = []

        # Build graph name → process mapping
        graph_map = {p.name: p for p in abinitio_processes}

        for job in autosys_jobs:
            job_name = job.get("job_name", "")
            command = job.get("command", "")

            # Extract Ab Initio graph reference from command
            graph_name = self._extract_abinitio_graph_from_command(command)

            if graph_name and graph_name in graph_map:
                # Found a link!
                process = graph_map[graph_name]

                link_doc = self._create_cross_system_link_document(job, process)
                documents.append(link_doc)

                logger.debug(f"  ✓ Linked: {job_name} → {graph_name}")

        if documents:
            self.collections["cross_system_links"].index_documents(documents)
            logger.info(f"✓ Created {len(documents)} cross-system links")
        else:
            logger.warning("⚠️  No cross-system links found")

        return {"links": len(documents)}

    def index_documents(self, documents: List[Dict[str, Any]]) -> Dict[str, int]:
        """
        Index business documents (PDFs, Excel, DOCX, etc.)

        Args:
            documents: List of parsed documents from DocumentParser

        Returns:
            Dict with indexing stats
        """
        logger.info(f"📄 Indexing {len(documents)} business documents...")

        doc_chunks = []

        for doc in documents:
            # Index each chunk as a separate document for better retrieval
            for chunk in doc.get('chunks', []):
                chunk_doc = {
                    "id": f"{doc['file_name']}_{chunk['chunk_id']}",
                    "content": chunk['text'],
                    "doc_type": "business_document",
                    "system": "documents",
                    "title": f"{doc['title']} (Part {chunk['chunk_id'] + 1})",
                    "metadata": {
                        "file_name": doc['file_name'],
                        "file_type": doc['file_type'],
                        "file_path": doc['file_path'],
                        "chunk_id": chunk['chunk_id'],
                        "total_chunks": len(doc['chunks']),
                        "parsed_at": doc['parsed_at'],
                    }
                }

                # Add file-specific metadata
                if 'metadata' in doc:
                    chunk_doc['metadata'].update(doc['metadata'])

                doc_chunks.append(chunk_doc)

        if doc_chunks:
            self.collections["documents_collection"].index_documents(doc_chunks)
            logger.info(f"✓ Indexed {len(doc_chunks)} document chunks from {len(documents)} files")
        else:
            logger.warning("⚠️  No document chunks to index")

        return {
            "total": len(doc_chunks),
            "files": len(documents),
        }

    # Document creation methods

    def _create_abinitio_graph_document(self, process: Process) -> Dict[str, Any]:
        """Create document for Ab Initio graph"""
        content_parts = [
            f"Ab Initio Graph: {process.name}",
            f"",
            f"Description: {process.description or 'N/A'}",
            f"Components: {process.component_count}",
            f"File Path: {process.file_path}",
        ]

        # Add graph parameters if available
        if hasattr(process, 'graph_parameters') and process.graph_parameters:
            content_parts.append("\nGraph Parameters:")
            for key, value in list(process.graph_parameters.items())[:10]:
                content_parts.append(f"  - {key}: {value}")

        return {
            "id": process.id,
            "content": "\n".join(content_parts),
            "doc_type": "abinitio_graph",
            "system": "abinitio",
            "title": f"Graph: {process.name}",
            "metadata": {
                "graph_name": process.name,
                "component_count": process.component_count,
                "file_path": process.file_path,
                "has_autosys_link": False,  # Will be updated if link found
            }
        }

    def _create_abinitio_component_document(self, component: Component) -> Dict[str, Any]:
        """Create document for Ab Initio component"""
        content_parts = [
            f"Component: {component.name}",
            f"Type: {component.component_type.value}",
            f"Graph: {component.process_name}",
        ]

        # Add parameters
        if component.parameters:
            content_parts.append("\nParameters:")
            for key, value in list(component.parameters.items())[:10]:
                content_parts.append(f"  - {key}: {str(value)[:100]}")

        return {
            "id": component.id,
            "content": "\n".join(content_parts),
            "doc_type": "abinitio_component",
            "system": "abinitio",
            "title": f"Component: {component.name}",
            "metadata": {
                "component_name": component.name,
                "component_type": component.component_type.value,
                "graph_name": component.process_name,
                "graph_id": component.process_id,
            }
        }

    def _create_autosys_job_document(self, job: Dict[str, Any]) -> Dict[str, Any]:
        """Create document for Autosys job"""
        job_name = job.get("job_name", "Unknown")
        command = job.get("command", "")
        job_type = job.get("job_type", "CMD")
        condition = job.get("condition", "")
        description = job.get("description", "")

        content_parts = [
            f"Autosys Job: {job_name}",
            f"",
            f"Type: {job_type}",
            f"Command: {command[:200]}",
            f"Dependencies: {condition}",
            f"Description: {description}",
        ]

        # Extract Ab Initio graph if present
        abinitio_graph = self._extract_abinitio_graph_from_command(command)
        if abinitio_graph:
            content_parts.append(f"\nExecutes Ab Initio Graph: {abinitio_graph}")

        return {
            "id": f"autosys_{job_name}",
            "content": "\n".join(content_parts),
            "doc_type": "autosys_job",
            "system": "autosys",
            "title": f"Job: {job_name}",
            "metadata": {
                "job_name": job_name,
                "job_type": job_type,
                "has_abinitio_link": bool(abinitio_graph),
                "abinitio_graph": abinitio_graph or "",
                "has_dependencies": bool(condition),
            }
        }

    def _create_cross_system_link_document(
        self,
        autosys_job: Dict[str, Any],
        abinitio_process: Process,
    ) -> Dict[str, Any]:
        """Create cross-system link document"""
        job_name = autosys_job.get("job_name", "")
        command = autosys_job.get("command", "")
        condition = autosys_job.get("condition", "")

        content_parts = [
            f"CROSS-SYSTEM EXECUTION FLOW",
            f"=" * 60,
            f"",
            f"AUTOSYS JOB: {job_name}",
            f"Job Type: {autosys_job.get('job_type', 'CMD')}",
            f"Dependencies: {condition or 'None'}",
            f"",
            f"EXECUTES AB INITIO GRAPH: {abinitio_process.name}",
            f"Graph Description: {abinitio_process.description or 'N/A'}",
            f"Components: {abinitio_process.component_count}",
            f"",
            f"FULL EXECUTION FLOW:",
            f"1. Autosys job '{job_name}' triggers",
            f"2. Executes command: {command[:100]}...",
            f"3. Runs Ab Initio graph: {abinitio_process.name}",
            f"4. Graph processes {abinitio_process.component_count} components",
        ]

        return {
            "id": f"link_{job_name}_{abinitio_process.name}",
            "content": "\n".join(content_parts),
            "doc_type": "cross_system_link",
            "system": "autosys_abinitio",
            "title": f"Link: {job_name} → {abinitio_process.name}",
            "metadata": {
                "autosys_job": job_name,
                "abinitio_graph": abinitio_process.name,
                "systems": ["autosys", "abinitio"],
                "link_type": "job_executes_graph",
            }
        }

    def _create_repository_document(self, repo: Repository, system: str) -> Dict[str, Any]:
        """Create repository document (for Hadoop/Databricks)"""
        return {
            "id": repo.id,
            "content": repo.get_searchable_content(),
            "doc_type": f"{system}_repository",
            "system": system,
            "title": f"Repository: {repo.name}",
            "metadata": {
                "repo_name": repo.name,
                "total_workflows": repo.total_workflows,
                "total_scripts": repo.total_scripts,
            }
        }

    def _create_workflow_document(self, workflow: WorkflowFlow, system: str) -> Dict[str, Any]:
        """Create workflow document"""
        return {
            "id": workflow.workflow_id,
            "content": workflow.get_searchable_content(),
            "doc_type": f"{system}_workflow",
            "system": system,
            "title": f"Workflow: {workflow.workflow_name}",
            "metadata": {
                "workflow_name": workflow.workflow_name,
                "workflow_type": workflow.workflow_type,
            }
        }

    def _create_script_document(self, script: ScriptLogic, system: str) -> Dict[str, Any]:
        """Create script document"""
        return {
            "id": script.script_id,
            "content": script.get_searchable_content(),
            "doc_type": f"{system}_script",
            "system": system,
            "title": f"Script: {script.script_name}",
            "metadata": {
                "script_name": script.script_name,
                "script_type": script.script_type,
            }
        }

    def _create_transformation_document(
        self,
        script: ScriptLogic,
        transformation,
        system: str
    ) -> Dict[str, Any]:
        """Create transformation document"""
        content_parts = [
            f"Transformation: {transformation.transformation_type.value}",
            f"Script: {script.script_name}",
            f"",
            f"Code: {transformation.code_snippet}",
        ]

        return {
            "id": transformation.transformation_id,
            "content": "\n".join(content_parts),
            "doc_type": f"{system}_transformation",
            "system": system,
            "title": f"Transform: {transformation.transformation_type.value}",
            "metadata": {
                "transformation_type": transformation.transformation_type.value,
                "script_id": script.script_id,
            }
        }

    def _extract_abinitio_graph_from_command(self, command: str) -> Optional[str]:
        """
        Extract Ab Initio graph name from Autosys command

        Patterns:
        - runpset.ksh -P graph_name.pset
        - /path/to/graph.mp
        - air sandbox run graph_name
        """
        import re

        if not command:
            return None

        # Pattern 1: runpset.ksh -P graph_name.pset
        pset_match = re.search(r'runpset\.ksh\s+-P\s+([a-zA-Z0-9_\-]+)\.pset', command)
        if pset_match:
            return pset_match.group(1)

        # Pattern 2: .pset file
        pset_file_match = re.search(r'([a-zA-Z0-9_\-/]+)\.pset', command)
        if pset_file_match:
            return Path(pset_file_match.group(1)).stem

        # Pattern 3: .mp file
        mp_match = re.search(r'([a-zA-Z0-9_\-/]+\.mp)', command)
        if mp_match:
            return Path(mp_match.group(1)).stem

        return None

    def search_multi_collection(
        self,
        query: str,
        collections: List[str] = None,
        top_k: int = 5
    ) -> Dict[str, Any]:
        """
        Search across multiple collections

        Args:
            query: Search query
            collections: List of collection names to search (default: all)
            top_k: Number of results per collection

        Returns:
            Dict with results grouped by collection
        """
        if collections is None:
            collections = list(self.collections.keys())

        results_by_collection = {}

        for coll_name in collections:
            if coll_name in self.collections:
                search_results = self.collections[coll_name].search(
                    query=query,
                    top=top_k
                )

                if search_results and "results" in search_results:
                    results_by_collection[coll_name] = search_results["results"]

        return results_by_collection

    def index_sttm_mappings(
        self,
        sttm_mappings: List[Dict[str, Any]],
        system_type: str,
        entity_name: str
    ) -> Dict[str, int]:
        """
        Index STTM (Source-Transform-Target Mappings) to system-specific collection

        Args:
            sttm_mappings: List of STTM mapping dictionaries
            system_type: abinitio, hadoop, or databricks
            entity_name: Name of the source entity (graph/workflow/notebook)

        Returns:
            Dict with indexed counts
        """
        logger.info(f"📊 Indexing {len(sttm_mappings)} STTM mappings for {system_type}/{entity_name}...")

        # Determine collection name
        collection_map = {
            "abinitio": "sttm_abinitio_collection",
            "hadoop": "sttm_hadoop_collection",
            "databricks": "sttm_databricks_collection"
        }

        collection_name = collection_map.get(system_type.lower())
        if not collection_name:
            logger.error(f"Unknown system type for STTM indexing: {system_type}")
            return {"error": "Unknown system type"}

        # Create documents from STTM mappings
        documents = []
        for mapping in sttm_mappings:
            doc = self._create_sttm_document(mapping, system_type, entity_name)
            documents.append(doc)

        # Index to collection
        try:
            self.collections[collection_name].index_documents(documents)

            logger.info(f"  ✓ Indexed {len(documents)} STTM mappings to {collection_name}")

            return {
                "collection": collection_name,
                "system_type": system_type,
                "entity_name": entity_name,
                "total_mappings": len(documents)
            }

        except Exception as e:
            logger.error(f"Error indexing STTM mappings: {e}")
            return {"error": str(e)}

    def _create_sttm_document(
        self,
        mapping: Dict[str, Any],
        system_type: str,
        entity_name: str
    ) -> Dict[str, Any]:
        """
        Create searchable document from STTM mapping

        Document includes:
        - Field name and data type (title)
        - Transformation logic and source fields (content)
        - Complete metadata for filtering
        """
        # Extract key fields
        target_field = mapping.get('target_field_name', 'unknown')
        data_type = mapping.get('target_field_data_type', 'unknown')
        transform_logic = mapping.get('transformation_logic', '')
        source_fields = mapping.get('source_field_names', [])
        source_dataset = mapping.get('source_dataset_name', 'unknown')
        field_definition = mapping.get('field_definition', '')
        contains_pii = mapping.get('contains_pii', False)
        field_type = mapping.get('field_type', 'unknown')

        # Build searchable content
        content_parts = [
            f"Target Field: {target_field} ({data_type})",
            f"Source Dataset: {source_dataset}",
            f"Source Fields: {', '.join(source_fields)}",
            f"Transformation Logic: {transform_logic}",
            f"Field Definition: {field_definition}",
        ]

        if mapping.get('field_depends_on'):
            content_parts.append(f"Dependencies: {', '.join(mapping['field_depends_on'])}")

        if mapping.get('pre_processing_rules'):
            content_parts.append(f"Pre-processing Rules: {', '.join(mapping['pre_processing_rules'])}")

        if mapping.get('ai_reasoning'):
            content_parts.append(f"AI Analysis: {mapping['ai_reasoning']}")

        content = "\n".join(content_parts)

        return {
            "id": mapping.get('id', f"{entity_name}_{target_field}"),
            "title": f"STTM: {target_field} ({data_type}) from {entity_name}",
            "content": content,
            "metadata": {
                "doc_type": "sttm_mapping",
                "system": system_type,
                "entity_name": entity_name,
                "target_table": mapping.get('target_table_name', 'unknown'),
                "target_field": target_field,
                "target_data_type": data_type,
                "source_dataset": source_dataset,
                "source_fields": source_fields,
                "transformation_logic": transform_logic,
                "contains_pii": contains_pii,
                "is_primary_key": mapping.get('is_primary_key', False),
                "field_type": field_type,
                "confidence_score": mapping.get('confidence_score', 0.0),
                "processing_order": mapping.get('processing_order', 0),
                "partner": mapping.get('partner', 'unknown'),
                "schema": mapping.get('schema', 'unknown'),
                "created_at": mapping.get('created_at', ''),
            }
        }

    def search_sttm(
        self,
        query: str,
        system_type: Optional[str] = None,
        top_k: int = 5,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        Search STTM mappings across systems

        Args:
            query: Search query (field name, transformation, etc.)
            system_type: Optional filter by system (abinitio, hadoop, databricks)
            top_k: Number of results
            filters: Optional metadata filters (contains_pii, field_type, etc.)

        Returns:
            List of matching STTM mappings
        """
        results = []

        # Determine which collections to search
        if system_type:
            collection_map = {
                "abinitio": "sttm_abinitio_collection",
                "hadoop": "sttm_hadoop_collection",
                "databricks": "sttm_databricks_collection"
            }
            collections_to_search = [collection_map.get(system_type.lower())]
        else:
            # Search all STTM collections
            collections_to_search = [
                "sttm_abinitio_collection",
                "sttm_hadoop_collection",
                "sttm_databricks_collection"
            ]

        # Search each collection
        for collection_name in collections_to_search:
            if collection_name in self.collections:
                try:
                    collection_results = self.collections[collection_name].search(
                        query=query,
                        top_k=top_k
                    )

                    # Apply additional filters if provided
                    if filters:
                        collection_results = self._filter_sttm_results(collection_results, filters)

                    results.extend(collection_results)

                except Exception as e:
                    logger.warning(f"Error searching {collection_name}: {e}")

        # Sort by relevance and limit
        results = sorted(results, key=lambda x: x.get('score', 0), reverse=True)[:top_k]

        return results

    def _filter_sttm_results(
        self,
        results: List[Dict[str, Any]],
        filters: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Apply metadata filters to STTM search results"""
        filtered = []

        for result in results:
            metadata = result.get('metadata', {})
            include = True

            # Check each filter
            if 'contains_pii' in filters and metadata.get('contains_pii') != filters['contains_pii']:
                include = False

            if 'field_type' in filters and metadata.get('field_type') != filters['field_type']:
                include = False

            if 'is_primary_key' in filters and metadata.get('is_primary_key') != filters['is_primary_key']:
                include = False

            if 'min_confidence' in filters and metadata.get('confidence_score', 0) < filters['min_confidence']:
                include = False

            if include:
                filtered.append(result)

        return filtered

    def get_stats(self) -> Dict[str, Any]:
        """Get statistics for all collections"""
        stats = {}

        for name, client in self.collections.items():
            try:
                client_stats = client.get_stats()
                stats[name] = client_stats
            except Exception as e:
                logger.warning(f"Could not get stats for {name}: {e}")
                stats[name] = {"error": str(e)}

        return stats
