"""
Metadata Extractor
==================
Extract tables and columns from indexed metadata for dropdown population

This powers the enhanced lineage tab with auto-populated dropdowns.
"""

from typing import List, Dict, Any, Set, Optional
from loguru import logger
from pathlib import Path
import json
import re


class MetadataExtractor:
    """
    Extract tables and columns from indexed data

    Provides dropdown options for lineage tracking UI
    """

    def __init__(self, indexer=None, ai_analyzer=None):
        """
        Initialize metadata extractor

        Args:
            indexer: MultiCollectionIndexer for searching metadata
            ai_analyzer: AIScriptAnalyzer for AI-based extraction
        """
        self.indexer = indexer
        self.ai_analyzer = ai_analyzer
        self._metadata_cache = {}  # Cache extracted metadata

    def get_tables(self, system: str) -> List[str]:
        """
        Get list of all tables/datasets in a system

        Args:
            system: System name (hadoop, databricks, abinitio)

        Returns:
            Sorted list of unique table names
        """
        cache_key = f"{system}_tables"

        if cache_key in self._metadata_cache:
            return self._metadata_cache[cache_key]

        logger.info(f"📊 Extracting tables from {system}...")

        tables = set()

        # Get all indexed documents from system
        documents = self._get_all_documents(system)

        for doc in documents:
            # Extract tables from metadata
            metadata = doc.get('metadata', {})

            # Check if metadata has tables directly
            if 'input_tables' in metadata:
                tables.update(metadata['input_tables'])

            if 'output_tables' in metadata:
                tables.update(metadata['output_tables'])

            # Also parse content for table references
            content = doc.get('content', '')
            extracted_tables = self._extract_tables_from_content(content, system)
            tables.update(extracted_tables)

        # Convert to sorted list
        tables_list = sorted(list(tables))

        # Cache result
        self._metadata_cache[cache_key] = tables_list

        logger.info(f"  ✓ Found {len(tables_list)} unique tables in {system}")

        return tables_list

    def get_columns(self, system: str, table_name: Optional[str] = None) -> List[str]:
        """
        Get list of columns for a specific table or all columns

        Args:
            system: System name
            table_name: Optional table name to filter columns

        Returns:
            Sorted list of unique column names
        """
        cache_key = f"{system}_{table_name or 'all'}_columns"

        if cache_key in self._metadata_cache:
            return self._metadata_cache[cache_key]

        logger.info(f"📊 Extracting columns from {system}.{table_name or 'all tables'}...")

        columns = set()

        # Get all indexed documents
        documents = self._get_all_documents(system)

        for doc in documents:
            metadata = doc.get('metadata', {})
            content = doc.get('content', '')

            # Check if this document mentions the table
            if table_name:
                # Only extract columns if document mentions this table
                if not self._document_mentions_table(content, metadata, table_name):
                    continue

            # Extract columns from metadata
            if 'columns' in metadata:
                columns.update(metadata['columns'])

            # Also parse content for column references
            extracted_columns = self._extract_columns_from_content(content, system, table_name)
            columns.update(extracted_columns)

        # Convert to sorted list
        columns_list = sorted(list(columns))

        # Cache result
        self._metadata_cache[cache_key] = columns_list

        logger.info(f"  ✓ Found {len(columns_list)} unique columns")

        return columns_list

    def clear_cache(self):
        """Clear metadata cache (call after re-indexing)"""
        self._metadata_cache = {}
        logger.info("Metadata cache cleared")

    def _get_all_documents(self, system: str) -> List[Dict[str, Any]]:
        """Get all indexed documents from a system"""
        if not self.indexer:
            logger.warning("No indexer available for metadata extraction")
            return []

        collection_name = f"{system}_collection"

        try:
            # Search with broad query to get many results
            results = self.indexer.search_multi_collection(
                query="table dataset column",  # Broad query
                collections=[collection_name],
                top_k=500  # Get many documents
            )

            return results.get(collection_name, [])

        except Exception as e:
            logger.error(f"Error getting documents from {collection_name}: {e}")
            return []

    def _extract_tables_from_content(
        self,
        content: str,
        system: str
    ) -> Set[str]:
        """
        Extract table names from script content using regex patterns

        Different patterns for different systems
        """
        tables = set()

        if system == "hadoop":
            # Pig patterns: LOAD 'table_name', STORE INTO 'table_name'
            pig_load = re.findall(r"LOAD\s+'?(\w+)'?", content, re.IGNORECASE)
            pig_store = re.findall(r"STORE\s+\w+\s+INTO\s+'?(\w+)'?", content, re.IGNORECASE)
            tables.update(pig_load)
            tables.update(pig_store)

            # Hive patterns: FROM table_name, INSERT INTO table_name
            hive_from = re.findall(r"FROM\s+(\w+)", content, re.IGNORECASE)
            hive_insert = re.findall(r"INSERT\s+(?:INTO|OVERWRITE)\s+TABLE\s+(\w+)", content, re.IGNORECASE)
            tables.update(hive_from)
            tables.update(hive_insert)

            # CREATE TABLE patterns
            create_table = re.findall(r"CREATE\s+(?:EXTERNAL\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(\w+)", content, re.IGNORECASE)
            tables.update(create_table)

        elif system == "databricks":
            # PySpark patterns: spark.read.table("table_name"), df.write.saveAsTable("table_name")
            spark_read = re.findall(r'spark\.read\.table\(["\'](\w+)["\']\)', content)
            spark_write = re.findall(r'\.saveAsTable\(["\'](\w+)["\']\)', content)
            tables.update(spark_read)
            tables.update(spark_write)

            # SQL patterns in notebooks
            sql_from = re.findall(r"FROM\s+(\w+)", content, re.IGNORECASE)
            sql_insert = re.findall(r"INSERT\s+INTO\s+(\w+)", content, re.IGNORECASE)
            tables.update(sql_from)
            tables.update(sql_insert)

        elif system == "abinitio":
            # Ab Initio DML patterns: in("table_name"), out("table_name")
            abinitio_in = re.findall(r'in\(["\'](\w+)["\']\)', content)
            abinitio_out = re.findall(r'out\(["\'](\w+)["\']\)', content)
            tables.update(abinitio_in)
            tables.update(abinitio_out)

        # Filter out common false positives
        tables = {t for t in tables if len(t) > 2 and not t.lower() in {'select', 'where', 'group', 'order', 'limit'}}

        return tables

    def _extract_columns_from_content(
        self,
        content: str,
        system: str,
        table_name: Optional[str]
    ) -> Set[str]:
        """
        Extract column names from script content

        Args:
            content: Script content
            system: System name
            table_name: Optional table name to filter columns

        Returns:
            Set of column names
        """
        columns = set()

        if system == "hadoop":
            # Pig: col1, col2, col3 (after GENERATE)
            pig_generate = re.findall(r"GENERATE\s+([\w\s,]+?)(?:;|AS)", content, re.IGNORECASE)
            for match in pig_generate:
                cols = [c.strip() for c in match.split(',')]
                columns.update(cols)

            # Hive: SELECT col1, col2
            select_cols = re.findall(r"SELECT\s+(.*?)\s+FROM", content, re.IGNORECASE | re.DOTALL)
            for match in select_cols:
                # Remove functions like COUNT(), SUM()
                clean_match = re.sub(r'\w+\([^)]*\)', '', match)
                cols = [c.strip().split()[-1] for c in clean_match.split(',') if c.strip() and c.strip() != '*']
                columns.update(cols)

        elif system == "databricks":
            # PySpark: df.select("col1", "col2")
            pyspark_select = re.findall(r'\.select\((.*?)\)', content)
            for match in pyspark_select:
                cols = re.findall(r'["\'](\w+)["\']', match)
                columns.update(cols)

            # PySpark: col("col_name")
            pyspark_col = re.findall(r'col\(["\'](\w+)["\']\)', content)
            columns.update(pyspark_col)

        # Filter out common false positives
        columns = {c for c in columns if len(c) > 1 and c.isidentifier()}

        return columns

    def _document_mentions_table(
        self,
        content: str,
        metadata: Dict[str, Any],
        table_name: str
    ) -> bool:
        """Check if document mentions a specific table"""

        # Check metadata
        input_tables = metadata.get('input_tables', [])
        output_tables = metadata.get('output_tables', [])

        if table_name in input_tables or table_name in output_tables:
            return True

        # Check content (case-insensitive)
        pattern = r'\b' + re.escape(table_name) + r'\b'
        return bool(re.search(pattern, content, re.IGNORECASE))

    def get_table_column_mapping(self, system: str) -> Dict[str, List[str]]:
        """
        Get mapping of tables to their columns

        Returns:
            Dict mapping table_name → list of column names
        """
        logger.info(f"📊 Building table-column mapping for {system}...")

        mapping = {}

        tables = self.get_tables(system)

        for table in tables:
            columns = self.get_columns(system, table)
            if columns:
                mapping[table] = columns

        logger.info(f"  ✓ Mapped {len(mapping)} tables with columns")

        return mapping
