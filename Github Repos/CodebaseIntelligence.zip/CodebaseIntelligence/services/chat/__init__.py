"""
Chat Service Package
====================

Agent-based chat orchestration with streaming updates.

Components:
- QueryClassifier: Intent detection and query routing
- ChatOrchestrator: Multi-agent coordination with streaming
"""

from services.chat.query_classifier import (
    QueryClassifier,
    QueryIntent,
    ClassifiedQuery,
    create_query_classifier
)

from services.chat.chat_orchestrator import (
    ChatOrchestrator,
    StreamUpdate,
    UpdateType,
    create_chat_orchestrator
)

__all__ = [
    'QueryClassifier',
    'QueryIntent',
    'ClassifiedQuery',
    'create_query_classifier',
    'ChatOrchestrator',
    'StreamUpdate',
    'UpdateType',
    'create_chat_orchestrator',
]
