"""
Codebase Copilot - Dynamic File Search & Context Retrieval Agent
=================================================================

Like Claude Code or Cursor, this agent can:
- Search indexed codebase dynamically
- Read and analyze files on-demand
- Provide deeper context when RAG alone isn't enough
- Self-retrieve relevant code for any query

This powers all STAG tabs with intelligent file inspection.
"""

from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path
from loguru import logger
import re
import json


class CodebaseContext:
    """Retrieved codebase context"""
    def __init__(self):
        self.files_read: List[str] = []
        self.total_characters: int = 0
        self.snippets: List[Dict[str, Any]] = []
        self.confidence: float = 0.0
        self.search_queries_used: List[str] = []


class CodebaseCopilot:
    """
    Intelligent code assistant that dynamically searches and reads files

    Similar to Claude Code's file inspection capabilities, but tailored
    for ETL pipeline analysis across multiple platforms.
    """

    def __init__(self, indexer=None, ai_analyzer=None):
        """
        Initialize copilot

        Args:
            indexer: MultiCollectionIndexer for searching
            ai_analyzer: AIScriptAnalyzer for understanding code
        """
        self.indexer = indexer
        self.ai_analyzer = ai_analyzer
        self.max_files_per_search = 10
        self.max_context_chars = 20000  # Max context to send to LLM

    def retrieve_context_for_query(
        self,
        query: str,
        systems: Optional[List[str]] = None,
        context_type: str = "general"
    ) -> CodebaseContext:
        """
        Retrieve relevant codebase context for a query

        This is the core copilot function - it intelligently searches
        and reads files to build context.

        Args:
            query: User query or agent request
            systems: Systems to search (hadoop, databricks, abinitio)
            context_type: Type of context needed (general, lineage, mapping, comparison)

        Returns:
            CodebaseContext with files read and snippets extracted
        """
        logger.info(f"🔍 Copilot retrieving context for: {query}")

        context = CodebaseContext()

        if not systems:
            systems = ["hadoop", "databricks", "abinitio"]

        # Step 1: Generate intelligent search queries based on context type
        search_queries = self._generate_search_queries(query, context_type)
        context.search_queries_used = search_queries

        logger.info(f"  📝 Generated {len(search_queries)} search queries")

        # Step 2: Search indexed codebase
        all_results = []
        for search_query in search_queries:
            results = self._search_codebase(search_query, systems)
            all_results.extend(results)

        # Deduplicate by file path
        unique_results = self._deduplicate_results(all_results)
        logger.info(f"  📄 Found {len(unique_results)} unique files")

        # Step 3: Read and extract relevant content from files
        for result in unique_results[:self.max_files_per_search]:
            file_context = self._read_and_extract(result, query, context_type)
            if file_context:
                context.snippets.append(file_context)
                context.files_read.append(file_context['file_name'])
                context.total_characters += len(file_context.get('content', ''))

        # Step 4: Calculate confidence based on results
        context.confidence = self._calculate_confidence(context, query)

        logger.info(f"  ✅ Retrieved context from {len(context.files_read)} files ({context.total_characters} chars)")
        logger.info(f"  📊 Confidence: {context.confidence:.0%}")

        return context

    def _generate_search_queries(
        self,
        query: str,
        context_type: str
    ) -> List[str]:
        """
        Generate intelligent search queries based on user query and context type

        This is like how Claude Code generates search terms from user intent.
        """
        queries = []

        # Extract key entities from query
        entities = self._extract_entities(query)

        # Base query
        queries.append(query)

        # Context-specific queries
        if context_type == "lineage":
            # For lineage, search for table/column names
            for entity in entities:
                queries.append(f"table {entity}")
                queries.append(f"column {entity}")
                queries.append(f"CREATE TABLE {entity}")
                queries.append(f"INSERT INTO {entity}")
                queries.append(f"SELECT * FROM {entity}")

        elif context_type == "mapping":
            # For mapping, search for workflow/graph names
            for entity in entities:
                queries.append(f"graph {entity}")
                queries.append(f"workflow {entity}")
                queries.append(f"pipeline {entity}")
                queries.append(f"notebook {entity}")

        elif context_type == "comparison":
            # For comparison, search both systems
            for entity in entities:
                queries.append(entity)
                queries.append(f"transform {entity}")
                queries.append(f"process {entity}")

        else:  # general
            # Add variations
            for entity in entities:
                queries.append(entity)
                queries.append(f"{entity} script")
                queries.append(f"{entity} job")

        # Limit to top 5 queries to avoid too many searches
        return queries[:5]

    def _extract_entities(self, query: str) -> List[str]:
        """
        Extract key entities (table names, workflow names) from query

        Examples:
        - "lineage for customer_table" → ["customer_table"]
        - "compare hadoop.bdf_download to databricks.bdf_download" → ["bdf_download"]
        - "SSN column" → ["SSN"]
        """
        entities = []

        # Remove common stop words
        stop_words = {'for', 'the', 'and', 'or', 'to', 'from', 'in', 'of', 'a', 'an',
                      'what', 'how', 'where', 'when', 'why', 'compare', 'show', 'find',
                      'get', 'table', 'column', 'workflow', 'pipeline', 'script'}

        # Split into words
        words = re.findall(r'\b\w+\b', query.lower())

        # Extract meaningful entities (not stop words, length > 2)
        for word in words:
            if word not in stop_words and len(word) > 2:
                entities.append(word)

        # Also look for dot-notation (hadoop.bdf_download)
        dot_entities = re.findall(r'(\w+)\.(\w+)', query)
        for system, entity in dot_entities:
            entities.append(entity)

        # Remove duplicates while preserving order
        seen = set()
        unique_entities = []
        for e in entities:
            if e not in seen:
                seen.add(e)
                unique_entities.append(e)

        return unique_entities[:3]  # Top 3 entities

    def _search_codebase(
        self,
        search_query: str,
        systems: List[str]
    ) -> List[Dict[str, Any]]:
        """Search indexed codebase for query"""
        if not self.indexer:
            logger.warning("No indexer available for copilot search")
            return []

        collections = [f"{system}_collection" for system in systems]

        try:
            results = self.indexer.search_multi_collection(
                query=search_query,
                collections=collections,
                top_k=10
            )

            # Flatten results from all collections
            all_results = []
            for collection, collection_results in results.items():
                for result in collection_results:
                    result['_collection'] = collection
                    all_results.append(result)

            return all_results

        except Exception as e:
            logger.error(f"Error searching codebase: {e}")
            return []

    def _deduplicate_results(
        self,
        results: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Remove duplicate files from search results"""
        seen_paths = set()
        unique_results = []

        for result in results:
            metadata = result.get('metadata', {})
            file_path = metadata.get('absolute_file_path') or metadata.get('file_path', '')

            if file_path and file_path not in seen_paths:
                seen_paths.add(file_path)
                unique_results.append(result)

        return unique_results

    def _read_and_extract(
        self,
        result: Dict[str, Any],
        query: str,
        context_type: str
    ) -> Optional[Dict[str, Any]]:
        """
        Read file and extract relevant content

        This is like Claude Code's file reading - it reads the actual
        file and extracts relevant sections.
        """
        metadata = result.get('metadata', {})
        file_path = metadata.get('absolute_file_path')
        file_name = metadata.get('file_name', 'unknown')
        system = result.get('_collection', '').replace('_collection', '')

        if not file_path or not Path(file_path).exists():
            return None

        try:
            # Read file content
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            # Extract relevant sections using AI or regex
            if self.ai_analyzer and self.ai_analyzer.enabled:
                extracted = self._ai_extract_relevant_sections(
                    content, query, context_type, file_name
                )
            else:
                extracted = self._regex_extract_relevant_sections(
                    content, query, file_name
                )

            return {
                'file_name': file_name,
                'file_path': file_path,
                'system': system,
                'content': extracted['content'],
                'relevance_score': extracted['relevance_score'],
                'summary': extracted['summary'],
                'key_elements': extracted['key_elements']
            }

        except Exception as e:
            logger.debug(f"Could not read file {file_path}: {e}")
            return None

    def _ai_extract_relevant_sections(
        self,
        content: str,
        query: str,
        context_type: str,
        file_name: str
    ) -> Dict[str, Any]:
        """Use AI to extract relevant sections from file"""

        # Truncate content if too large
        truncated_content = content[:8000]

        prompt = f"""Analyze this file and extract relevant sections for the query.

Query: {query}
Context Type: {context_type}
File: {file_name}

File Content (first 8000 chars):
```
{truncated_content}
```

Extract and return in JSON format:
{{
    "relevant_sections": "The most relevant code sections (max 2000 chars)",
    "summary": "1-sentence summary of what this file does related to the query",
    "key_elements": ["list", "of", "key", "tables/columns/transformations"],
    "relevance_score": 0.0-1.0
}}

Focus on extracting sections that help answer the query.
"""

        try:
            response = self.ai_analyzer.client.chat.completions.create(
                model=self.ai_analyzer.deployment_name,
                messages=[
                    {"role": "system", "content": "You are a code analysis assistant. Return only valid JSON."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.0,
                max_tokens=1500
            )

            result_text = response.choices[0].message.content.strip()

            # Parse JSON
            result_text = re.sub(r'^```json?\s*', '', result_text)
            result_text = re.sub(r'\s*```$', '', result_text)

            result = json.loads(result_text)

            return {
                'content': result.get('relevant_sections', truncated_content[:2000]),
                'summary': result.get('summary', ''),
                'key_elements': result.get('key_elements', []),
                'relevance_score': result.get('relevance_score', 0.5)
            }

        except Exception as e:
            logger.debug(f"AI extraction failed: {e}, using fallback")
            return self._regex_extract_relevant_sections(content, query, file_name)

    def _regex_extract_relevant_sections(
        self,
        content: str,
        query: str,
        file_name: str
    ) -> Dict[str, Any]:
        """Fallback: Use regex to extract relevant sections"""

        # Extract entities from query
        entities = self._extract_entities(query)

        # Find lines containing any entity
        lines = content.split('\n')
        relevant_lines = []

        for i, line in enumerate(lines):
            for entity in entities:
                if re.search(r'\b' + re.escape(entity) + r'\b', line, re.IGNORECASE):
                    # Include context (5 lines before and after)
                    start = max(0, i - 5)
                    end = min(len(lines), i + 6)
                    relevant_lines.extend(lines[start:end])
                    break

        # Deduplicate and join
        relevant_content = '\n'.join(dict.fromkeys(relevant_lines))

        # If no matches, take first 2000 chars
        if not relevant_content:
            relevant_content = content[:2000]
        else:
            relevant_content = relevant_content[:2000]

        return {
            'content': relevant_content,
            'summary': f"File mentions {', '.join(entities)}",
            'key_elements': entities,
            'relevance_score': 0.6 if relevant_lines else 0.3
        }

    def _calculate_confidence(
        self,
        context: CodebaseContext,
        query: str
    ) -> float:
        """Calculate confidence in retrieved context"""

        if not context.snippets:
            return 0.0

        # Factors:
        # 1. Number of files found
        # 2. Total context size
        # 3. Average relevance score

        file_score = min(len(context.files_read) / 5.0, 1.0)  # Max at 5 files
        char_score = min(context.total_characters / 10000.0, 1.0)  # Max at 10k chars

        relevance_scores = [s.get('relevance_score', 0.5) for s in context.snippets]
        avg_relevance = sum(relevance_scores) / len(relevance_scores) if relevance_scores else 0.0

        # Weighted average
        confidence = (file_score * 0.3) + (char_score * 0.2) + (avg_relevance * 0.5)

        return confidence

    def format_context_for_llm(
        self,
        context: CodebaseContext,
        query: str
    ) -> str:
        """
        Format retrieved context for LLM consumption

        Returns a well-structured context string to include in LLM prompt
        """
        if not context.snippets:
            return "No relevant code context found in indexed repositories."

        formatted = f"## Retrieved Codebase Context for: {query}\n\n"
        formatted += f"**Files Analyzed:** {len(context.files_read)}\n"
        formatted += f"**Confidence:** {context.confidence:.0%}\n\n"

        for idx, snippet in enumerate(context.snippets, 1):
            formatted += f"### File {idx}: {snippet['file_name']} ({snippet['system']})\n\n"
            formatted += f"**Summary:** {snippet['summary']}\n\n"
            formatted += f"**Key Elements:** {', '.join(snippet['key_elements'])}\n\n"
            formatted += f"**Relevant Code:**\n```\n{snippet['content']}\n```\n\n"
            formatted += "---\n\n"

        # Truncate if too large
        if len(formatted) > self.max_context_chars:
            formatted = formatted[:self.max_context_chars] + "\n\n[Context truncated due to length...]"

        return formatted
