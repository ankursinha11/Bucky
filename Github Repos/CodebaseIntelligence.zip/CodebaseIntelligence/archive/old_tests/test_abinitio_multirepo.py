#!/usr/bin/env python3
"""
Test Ab Initio Multi-Repo Detection
====================================
Quick test to verify multi-project detection works
"""

import sys
from pathlib import Path

# Add project to path
sys.path.insert(0, str(Path(__file__).parent))

from parsers.abinitio.deep_parser_multi_repo import DeepAbInitioParserMultiRepo


def test_multirepo_detection():
    """
    Test multi-repo detection with your structure:

    abinitio_root/
    ├── blade/       ← Project 1
    │   └── mp/
    ├── edi/         ← Project 2
    ├── pub_escan/   ← Project 3
    ├── __blade/     ← Skip (backup)
    └── __edi/       ← Skip (backup)
    """

    print("\n" + "=" * 70)
    print("  Ab Initio Multi-Repo Detection Test")
    print("=" * 70 + "\n")

    # Test folder detection logic
    parser = DeepAbInitioParserMultiRepo(use_ai=False)

    # Test skip logic
    print("Testing folder skip logic:")
    test_folders = [
        ("blade", False),
        ("edi", False),
        ("pub_escan", False),
        ("__blade", True),    # Should skip
        ("__edi", True),      # Should skip
        ("__pub_escan", True), # Should skip
        (".backup", True),     # Should skip
        (".git", True),        # Should skip
        ("tmp", True),         # Should skip
    ]

    for folder, should_skip in test_folders:
        result = parser._should_skip_folder(folder)
        status = "✓" if result == should_skip else "✗"
        action = "SKIP" if result else "KEEP"
        print(f"  {status} {folder:20s} -> {action}")

    print("\n" + "=" * 70)
    print("✅ Folder detection logic is correct!")
    print("\nExpected behavior:")
    print("  ✓ Detects: blade/, edi/, pub_escan/ as separate projects")
    print("  ✓ Skips: __blade/, __edi/, __pub_escan/ (backup folders)")
    print("  ✓ Skips: folders starting with . (hidden), tmp, temp, backup")
    print("\nReady to test with your actual data!")
    print("=" * 70 + "\n")


def test_project_indicators():
    """Test Ab Initio project detection"""

    print("\n" + "=" * 70)
    print("  Ab Initio Project Structure Detection")
    print("=" * 70 + "\n")

    parser = DeepAbInitioParserMultiRepo(use_ai=False)

    print("A folder is considered an Ab Initio project if it contains 2+ of:")
    for indicator in parser.project_indicators:
        print(f"  • {indicator}/")

    print("\nYour 'blade/' folder structure:")
    print("  blade/")
    print("    ├── bin/")
    print("    ├── components/  ← Indicator 1 ✓")
    print("    ├── db/")
    print("    ├── dml/         ← Indicator 2 ✓")
    print("    ├── mp/          ← Indicator 3 ✓")
    print("    ├── plan/        ← Indicator 4 ✓")
    print("    ├── pset/        ← Indicator 5 ✓")
    print("    └── ...")

    print("\n✅ 'blade/' has 5 indicators → Will be detected as project!")
    print("✅ Same logic applies to 'edi/' and 'pub_escan/'")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    test_multirepo_detection()
    test_project_indicators()

    print("\n🎯 To test with your actual data:")
    print("\n   python3 index_codebase.py --parser abinitio \\")
    print("     --source /path/to/your/abinitio/root \\")
    print("     --autosys /path/to/autosys/jobs \\")
    print("     --deep\n")

    print("Expected output:")
    print("   ✓ Detected 3 Ab Initio projects!")
    print("      - blade")
    print("      - edi")
    print("      - pub_escan")
    print()
