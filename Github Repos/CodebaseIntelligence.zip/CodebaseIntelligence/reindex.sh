#!/bin/bash

# Quick Re-Indexing Script
# =========================
# Simple wrapper for common vector database operations

echo "🔄 Vector Database Manager"
echo "=========================="
echo ""
echo "What would you like to do?"
echo ""
echo "1. Show database status"
echo "2. Clear ALL data and re-index from scratch"
echo "3. Clear specific collection only"
echo "4. Re-index Ab Initio only"
echo "5. Re-index Autosys only"
echo "6. Re-index Documents only"
echo "7. Export statistics to JSON"
echo "8. Exit"
echo ""

read -p "Select option (1-8): " choice

case $choice in
    1)
        echo ""
        python manage_vector_db.py --status
        ;;

    2)
        echo ""
        echo "⚠️  This will DELETE all existing data!"
        read -p "Are you sure? (yes/no): " confirm
        if [ "$confirm" = "yes" ]; then
            python manage_vector_db.py --clear-all --yes
            echo ""
            echo "Now re-indexing..."
            python manage_vector_db.py --reindex-all
        else
            echo "Cancelled."
        fi
        ;;

    3)
        echo ""
        echo "Available collections:"
        echo "  - abinitio"
        echo "  - hadoop"
        echo "  - databricks"
        echo "  - autosys"
        echo "  - links"
        echo "  - documents"
        echo ""
        read -p "Collection name: " collection
        python manage_vector_db.py --clear "$collection"
        ;;

    4)
        echo ""
        read -p "Ab Initio directory path: " path
        if [ -d "$path" ]; then
            python manage_vector_db.py --reindex abinitio --path "$path"
        else
            echo "❌ Directory not found: $path"
        fi
        ;;

    5)
        echo ""
        read -p "Autosys directory path: " path
        if [ -d "$path" ]; then
            python manage_vector_db.py --reindex autosys --path "$path"
        else
            echo "❌ Directory not found: $path"
        fi
        ;;

    6)
        echo ""
        read -p "Documents directory path: " path
        if [ -d "$path" ]; then
            python manage_vector_db.py --reindex documents --path "$path"
        else
            echo "❌ Directory not found: $path"
        fi
        ;;

    7)
        echo ""
        python manage_vector_db.py --export-stats
        ;;

    8)
        echo "Goodbye!"
        exit 0
        ;;

    *)
        echo "Invalid option"
        exit 1
        ;;
esac

echo ""
echo "✓ Done!"
