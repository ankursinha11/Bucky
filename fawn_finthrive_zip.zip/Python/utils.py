import os
from datetime import datetime
import chardet 

def create_directory(directory_path: str) -> None: 
    if os.path.exists(directory_path): 
        pass 
    else: 
        os.makedirs(directory_path) 
        print(f"Created directory: {directory_path}") 
        
def detect_encoding(file_path: str) -> str:
    with open(file_path, 'rb') as file: 
        raw_data = file.read() 
    result = chardet.detect(raw_data) 
    return result['encoding']
    
def mp_to_txt(upload_folder: str, text_folder: str, sandbox_file_path: str, timestamp: str) -> tuple[str, str, str]: 
    create_directory(upload_folder) 
    create_directory(text_folder) 
    
    script_dir = os.path.dirname(os.path.abspath(__file__)) 
    source_dir = os.path.dirname(sandbox_file_path) 
   
    if not os.path.isdir(source_dir): 
        raise ValueError(f"Directory not found: {source_dir}. Check the relative path or directory existence.") 
    base_file_name = os.path.basename(sandbox_file_path) 
    
    mp_files = [f for f in os.listdir(source_dir) if f.endswith('.mp') and base_file_name in f]
    if not mp_files: 
        raise ValueError(f"No .mp files found in {source_dir}") 
    
    input_mp_file = os.path.join(source_dir, mp_files[0]) 
    original_filename = os.path.splitext(os.path.basename(input_mp_file))[0] 
    
    uploaded_mp_filename = f"{original_filename}_{timestamp}.mp" 
    output_txt_filename = f"{original_filename}_{timestamp}.txt" 
    
    uploaded_mp_path = os.path.join(upload_folder, uploaded_mp_filename) 
    output_txt_file = os.path.join(text_folder, output_txt_filename) 
    
    encoding = detect_encoding(input_mp_file) 
    
    with open(input_mp_file, 'r', encoding=encoding) as source_file: 
        mp_content = source_file.read() 
    with open(uploaded_mp_path, 'w', encoding='utf-8') as dest_file: 
        dest_file.write(mp_content) 
    
    with open(uploaded_mp_path, 'r', encoding='utf-8') as mp_file: 
        mp_content = mp_file.read() 
    with open(output_txt_file, 'w', encoding='utf-8') as txt_file: 
        txt_file.write(mp_content) 
    return output_txt_file, sandbox_file_path, original_filename 
    
def read_file(file_path: str) -> str: 
    with open(file_path, 'r', encoding='utf-8') as fp: 
        return fp.read()