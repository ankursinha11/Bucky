import re
import os
import pandas as pd
from typing import List, Dict
from config import *
from utils import create_directory, mp_to_txt, read_file
from datetime import datetime
import yaml
import getpass



def load_patterns():
    from cryptography.fernet import Fernet
    import getpass

    script_dir = os.path.dirname(os.path.abspath(__file__))

    
    secure_dir = os.path.join(script_dir, ".ip")
    encrypted_file = os.path.join(secure_dir, "pttyml")
    key_file = os.path.join(secure_dir, ".sk")

    
    config_dir = os.path.join(script_dir, "bbi_config")
    username = getpass.getuser()
    decrypted_file = os.path.join(config_dir, f"{username}_pattern.yaml")

    
    if not os.path.exists(encrypted_file):
        raise FileNotFoundError(f"Encrypted pattern file not found: {encrypted_file}")

    if not os.path.exists(key_file):
        raise FileNotFoundError(f"Encryption key not found: {key_file}")

    
    with open(key_file, 'rb') as kf:
        key = kf.read()

    cipher = Fernet(key)

    
    with open(encrypted_file, 'rb') as ef:
        encrypted_data = ef.read()

    
    try:
        decrypted_data = cipher.decrypt(encrypted_data)
    except Exception as e:
        raise ValueError(f"Decryption failed: {e}")

    
    with open(decrypted_file, 'wb') as df:
        df.write(decrypted_data)

    
    with open(decrypted_file, 'r') as file:
        patterns = yaml.safe_load(file)

    return patterns, decrypted_file

def break_down_block(block: str, patterns: Dict) -> tuple[str, str, str]:
    internal_match = re.search(patterns["BLOCK_INTERNAL_PATTERN"], block, re.DOTALL)
    if internal_match:
        start_index = internal_match.start()
        stack = []
        end_index = -1
        for i in range(start_index, len(block)):
            if block[i] == "{":
                stack.append("{")
            elif block[i] == "}":
                if stack:
                    stack.pop()
                if not stack:
                    end_index = i + 1
                    break
        if end_index != -1:
            return (
                block[:start_index].strip(),
                block[start_index:end_index].strip(),
                block[end_index:].strip()
            )
    else:
        
        start_match = re.match(r'\{(\d+)\|', block)
        if start_match and start_match.group(1) == patterns["GRAPH_ID"]:
            no_match = re.search(r'\\', block)
            end_match = re.search(r'\{\}', block)
            start_index = no_match.start() if no_match else 0
            end_index = end_match.start() if end_match else -1
            if end_index != -1:
                return (
                    block[:start_index].strip(),
                    tuple(),
                    block[end_index:].strip()
                )
    return "", "", ""

def extract_and_store_blocks(content: str, patterns: Dict) -> tuple[List[Dict[str, str]], Dict[str, List[Dict[str, str]]]]:
    block_with_internal_section = []
    blocks_by_graph_id = {}
    stack = []
    current_block = ''
    block_count = 0
    graph_id_counters = {}
    for char in content:
        if char == '{':
            if not stack:
                current_block = ''
            stack.append(char)
            current_block += char
        elif char == '}':
            if stack:
                stack.pop()
            current_block += char
            if not stack:
                block_count += 1
                start, internal, end = break_down_block(current_block, patterns)
                if internal:
                    graph_id = start.strip('{}').split('|')[0] if start else ""
                    if graph_id.isdigit():
                        if graph_id not in graph_id_counters:
                            graph_id_counters[graph_id] = 1
                        block_idx = graph_id_counters[graph_id]
                        graph_id_counters[graph_id] += 1
                        block_data = {
                            f"block_idx_{block_idx}": current_block.strip(),
                            "start_session": start,
                            "internal_session": internal,
                            "end_session": end
                        }
                        block_with_internal_section.append(block_data)
                        if graph_id not in blocks_by_graph_id:
                            blocks_by_graph_id[graph_id] = []
                        blocks_by_graph_id[graph_id].append(block_data)
        elif stack:
            current_block += char
    if stack:
        print("Warning: Unmatched '{' detected. Some blocks may be incomplete.")
    return block_with_internal_section, blocks_by_graph_id

def extract_blocks(content: str) -> List[str]:
    blocks = []
    stack = []
    current_block = ''
    for char in content:
        if char == '{':
            if not stack:
                current_block = ''
            stack.append(char)
            current_block += char
        elif char == '}':
            if stack:
                stack.pop()
            current_block += char
            if not stack:
                blocks.append(current_block.strip())
        elif stack:
            current_block += char
    return blocks

def extract_parameter_blocks(block: str, patterns: Dict) -> List[Dict[str, str]]:
    match = re.search(patterns["PARAMETER_SECTION_PATTERN"], block, re.DOTALL)
    parameter_list = []
    if match:
        parameter_section = match.group(1)
        nested_blocks = extract_blocks(parameter_section)
        for param_block in nested_blocks:
            param_match = re.search(patterns["PARAMETER_PATTERN"], param_block, re.DOTALL)
            param_dict = {}
            if param_match:
                param_dict["parameter_id"] = param_match.group(1)
                param_dict["parameter_name"] = param_match.group(3)
                param_dict["parameter_value"] = param_match.group(4).strip() if param_match.group(4) is not None else ""
                param_dict["execution_order"] = param_match.group(5) if param_match.group(5) is not None else ""
                param_dict["version"] = param_match.group(6) if param_match.group(6) is not None else ""
                param_dict["parameter_type"] = param_match.group(7) if param_match.group(7) is not None else ""
                param_dict["extra_field"] = param_match.group(8) if param_match.group(8) is not None else ""
            else:
                print(f"Warning: Failed to parse parameter block: {param_block}")
            parameter_list.append(param_dict)
    return parameter_list






def extract_end_section_details(end_section: str, patterns: Dict, ID: str) -> Dict[str, str]:
      split_end = end_section.split('|')
      end_dict = {}
      if len(split_end) >= patterns["END_SECTION_MIN_LENGTH"]:
          end_dict["component_phase"] = split_end[0].strip('@')
          end_dict["disable_check"] = 0
          end_dict["graph_name"] = split_end[8] if len(split_end) > 8 else ""

          
          if patterns["COMPONENT_NAME"] in split_end:
              component_index = split_end.index(patterns["COMPONENT_NAME"])
              end_dict["component_name"] = split_end[component_index - 1]
          else:
             
              if len(split_end) > 8 and split_end[8].strip():
                  end_dict["component_name"] = split_end[8]

          if ID == patterns["GRAPH_ID"]:
              end_dict["subgraph_name"] = split_end[8] if len(split_end) > 8 else ""

      return end_dict




def parse_blocks(blocks_by_graph_id: Dict[str, List[Dict[str, str]]], patterns: Dict) -> List[Dict]:
    block_dicts = []
    for unique_id, block_list in blocks_by_graph_id.items():
        for block_entry in block_list:
            block_key = next(key for key in block_entry.keys() if key.startswith('block_idx_'))
            block = block_entry[block_key]
            start_section = block_entry.get('start_session', '')
            internal_section = block_entry.get('internal_session', '')
            end_section = block_entry.get('end_session', '')
            sub_graph = block_entry.get('subgraph', '')
            start_split = start_section.strip('{}').split('|')
            graph_id = start_split[0] if len(start_split) > 0 else ""
            graph_type = start_split[1] if len(start_split) > 1 else ""
            parameter_list = extract_parameter_blocks(block, patterns)
            check_valid = any('!prototype_path' in item['parameter_name'] for item in parameter_list)
            end_details = extract_end_section_details(end_section, patterns, graph_id)
           

            valid = 1 if check_valid else 0

            component_type = ""
            if parameter_list:
                first_param_value = ' '.join([item['parameter_value'] for item in parameter_list if '!prototype_path' in item['parameter_name']]).strip(' ')
                if first_param_value:
                    component_type_parts = first_param_value.strip('{}').split('|')
                    if len(component_type_parts) >= 1:
                        last_part = component_type_parts[0].split('/')[-1]
                        component_type = last_part.split('.')[0]
                    else:
                        component_type = first_param_value.split('.')[0]
            block_dict = {
                unique_id: [{
                    block_key: block,
                    'start_session': start_section,
                    'internal_session': internal_section,
                    'end_session': end_section
                }],
                'graph_id': graph_id,
                'graph_type': graph_type,
                'graph_name': end_details.get('graph_name', ''),
                'subgraph_hierarchy': sub_graph,  
                'parameter_list': parameter_list,
                'component_phase': end_details.get('component_phase', ''),
                'component_type': component_type,
                'component_name': end_details.get('component_name', ''),
                'disable_check': end_details.get('disable_check', ''),
                'valid': valid
            }
            block_dicts.append(block_dict)
    return block_dicts

def flatten_data(block_dicts: List[Dict]) -> List[Dict]:
    flattened_data = []
    for block_dict in block_dicts:
        unique_id = list(block_dict.keys())[0]
        graph_id = block_dict['graph_id']
        graph_type = block_dict['graph_type']
        component_phase = block_dict['component_phase']
        component_type = block_dict['component_type']
        component_name = block_dict['component_name']
        disable_check = block_dict["disable_check"]
        graph_name = block_dict['graph_name']
        valid = block_dict['valid']
        subgraph_hierarchy = block_dict['subgraph_hierarchy']  

        subgraph_parts = subgraph_hierarchy.split('.') if subgraph_hierarchy else []
        if len(subgraph_parts) >= 2:
            final_subgraph = '.'.join(subgraph_parts[-2:])
        elif len(subgraph_parts) == 1:
            final_subgraph = subgraph_parts[0]
        else:
            final_subgraph = ""
        if not block_dict['parameter_list']:
            flattened_data.append({
                "graph_id": graph_id,
                "graph_type": graph_type,
                "graph_name": graph_name,
                "subgraph_hierarchy": subgraph_hierarchy,  
                "final_subgraph": final_subgraph,  
                "component_phase": component_phase,
                "component_type": component_type,
                "component_name": component_name,
                "disable_check": disable_check,
                "parameter_id": "",
                "parameter_name": "",
                "parameter_value": "",
                "execution_order": "",
                "version": "",
                "parameter_type": "",
                "valid": valid
            })
        else:
            for param in block_dict['parameter_list']:
                Keys = ""
                if param.get("parameter_name", "") == "key":
                    Keys = param.get("parameter_value", "")
                flattened_data.append({
                    "graph_id": graph_id,
                    "graph_type": graph_type,
                    "graph_name": graph_name,
                    "component_phase": component_phase,
                    "component_type": component_type,
                    "component_name": component_name,
                    "disable_check": disable_check,
                    "parameter_id": param.get("parameter_id", ""),
                    "parameter_name": param.get("parameter_name", ""),
                    "parameter_value": param.get("parameter_value", ""),
                    "execution_order": param.get("execution_order", ""),
                    "version": param.get("version", ""),
                    "parameter_type": param.get("parameter_type", ""),
                    "valid": valid,
                    "Keys": Keys,
                    "subgraph_hierarchy": subgraph_hierarchy,  
                    "final_subgraph": final_subgraph  
                })
    return flattened_data

def process_and_save_data(df: pd.DataFrame, sandbox_file_path: str, patterns: Dict, output_folder: str, base_filename: str, timestamp: str) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, str]:
    orig_df = df
    component_df = orig_df[orig_df['graph_type'] != patterns["GRAPH_TYPE"]].copy()
    graph_parameter_df = orig_df[orig_df['graph_type'] == patterns["GRAPH_TYPE"]].copy()
    graph_parameter_df = graph_parameter_df[~graph_parameter_df['graph_name'].isin(['@@@1'])]
    graph_parameter_df = pd.DataFrame([graph_parameter_df['graph_name'], graph_parameter_df['parameter_name'], graph_parameter_df['parameter_value']]).T
    graph_parameter_df.reset_index(drop=True, inplace=True)
    component_df['component_phase'] = component_df['component_phase'].str.replace('@', '', regex=False)
    component_df_filtered = component_df[
        component_df['parameter_value'].notna() &
        (component_df['parameter_value'] != '') & (component_df['valid'] == 1)
    ]
    columns_to_keep = [
        'component_phase',
        'subgraph_hierarchy', 
        'final_subgraph',  
        'component_type',
        'component_name',
        'disable_check',
        'parameter_name',
        'parameter_value',
        'Keys'
    ]
    columns_rename_mapping = {
        'component_type': 'Component Name',
        'component_name': 'Transform Component',
        'parameter_name': 'TransLocation',
        'parameter_value': 'Transform Rule'
    }
    component_df_minimized = component_df_filtered[columns_to_keep].copy()
    component_df_minimized.rename(columns=columns_rename_mapping, inplace=True)
    component_df_minimized.insert(0, 'sr_no', range(1, len(component_df_minimized) + 1))
    allowed_component_types = set(patterns["ALLOWED_COMPONENT_TYPES"])

    def create_component_dict(df, component_type):
        type_df = df[df['Component Name'] == component_type].copy()
        unique_names = type_df['Transform Component'].unique()
        component_dict = {}
        for name in unique_names:
            comp_df = type_df[type_df['Transform Component'] == name]
            params_list = [
                {"parameter_name": row['TransLocation'], "parameter_value": row['Transform Rule']}
                for _, row in comp_df.iterrows()
            ]
            component_dict[name] = params_list
        return component_dict

    result_dict = {}
    unique_component_types = sorted(set(component_df_minimized['Component Name'].unique()) & allowed_component_types)
    for comp_type in unique_component_types:
        result_dict[comp_type] = create_component_dict(component_df_minimized, comp_type)
    columns = [
        patterns["COMP_DISPLAY_LABEL"],
        patterns["COMPONENT_TYPE_COL"],
        patterns["DATASET_NAMES"],
        patterns["DML_COL"],
        patterns["KEY_PARAM_VALUE"]
    ]
    rows = []
    dml_params = patterns["DML_PARAMS"]
    for comp_type in unique_component_types:
        components = result_dict[comp_type]
        if comp_type in allowed_component_types:
            for comp_name, params in components.items():
                row = {
                    patterns["COMP_DISPLAY_LABEL"]: comp_name,
                    patterns["COMPONENT_TYPE_COL"]: comp_type,
                    patterns["DATASET_NAMES"]: '',
                    patterns["DML_COL"]: '',
                    patterns["KEY_PARAM_VALUE"]: ''
                }
                for param in params:
                    param_name = param['parameter_name']
                    param_value = param['parameter_value']
                    if param_name == patterns["LAYOUT_PARAM"]:
                        row[patterns["DATASET_NAMES"]] = param_value
                    if param_name == dml_params.get(comp_type):
                        row[patterns["DML_COL"]] = param_value
                    if param_name == patterns["KEY_PARAM"]:
                        row[patterns["KEY_PARAM_VALUE"]] = param_value
                rows.append(row)
    dataset_df = pd.DataFrame(rows, columns=columns)
    df_required_unix = component_df_minimized[['sr_no', 'Transform Component', 'TransLocation', 'Transform Rule']]
    df_required_unix = df_required_unix[df_required_unix['Transform Rule'].str.contains(patterns["UNIX_PARAM_PATTERN"], na=False)]
    csv_file = os.path.join(output_folder, f"{base_filename}_{timestamp}.csv")
    with open(csv_file, 'w', encoding='utf-8') as f:
        f.write(f'"sandbox_file_path"="{sandbox_file_path}"\n')
        df_required_unix.to_csv(f, index=False, sep='|', lineterminator='\n')
    return dataset_df, component_df_minimized, graph_parameter_df, csv_file

def update_transform_rule_and_save(dataset_df, component_df, graph_parameter_df, tracking_df, csv_file_path, graph_csv_input, output_folder, original_filename, timestamp):
    try:
        
        with open(csv_file_path, 'r', encoding='utf-8') as file:
            csv_content = file.read()
        records = csv_content.split('\n')
        csv_data = []
        current_record = []
        for line in records:
            if line.strip() and line[0].isdigit():
                if current_record:
                    csv_data.append(current_record)
                current_record = [line]
            else:
                current_record.append(line)
        if current_record:
            csv_data.append(current_record)
        csv_records = []
        for record in csv_data:
            if record[0].startswith('"sandbox_file_path"='):
                continue
            sr_no, transform_component, trans_location, transform_rule = record[0].split('|', 3)
            transform_rule += '\n'.join(record[1:])
            csv_records.append([sr_no.strip(), transform_component.strip(), trans_location.strip(), transform_rule.strip()])
        csv_df = pd.DataFrame(csv_records, columns=['sr_no', 'Transform Component', 'TransLocation', 'Transform Rule'])
        if csv_df.iloc[0]['sr_no'].lower() == 'sr_no':
            csv_df = csv_df.drop(0)
        csv_df['sr_no'] = csv_df['sr_no'].astype(int)
        for index, row in csv_df.iterrows():
            sr_no = row['sr_no']
            transform_rule = row['Transform Rule']
            component_df.loc[component_df['sr_no'] == sr_no, 'Transform Rule'] = transform_rule

       
        with open(graph_csv_input, 'r', encoding='utf-8') as file:
            graph_csv_content = file.read()
        graph_records = graph_csv_content.split('\n')
        graph_csv_data = []
        current_record = []
        for line in graph_records:
            if line.strip() and line[0].isdigit():
                if current_record:
                    graph_csv_data.append(current_record)
                current_record = [line]
            else:
                current_record.append(line)
        if current_record:
            graph_csv_data.append(current_record)
        graph_csv_records = []
        for record in graph_csv_data:
            if len(record[0].split(',')) < 4:
                continue
            sr_no, graph_name, parameter_name, parameter_value = record[0].split(',', 3)
            parameter_value += '\n'.join(record[1:])
            graph_csv_records.append([sr_no.strip(), graph_name.strip(), parameter_name.strip(), parameter_value.strip()])
        graph_csv_df = pd.DataFrame(graph_csv_records, columns=['sr_no', 'Graph Name', 'Parameter Name', 'Parameter Value'])
        if graph_csv_df.iloc[0]['sr_no'].lower() == 'sr_no':
            graph_csv_df = graph_csv_df.drop(0)
        graph_csv_df['sr_no'] = graph_csv_df['sr_no'].astype(int)
        for index, row in graph_csv_df.iterrows():
            sr_no = row['sr_no']
            parameter_value = row['Parameter Value']
            graph_parameter_df.loc[graph_parameter_df['sr_no'] == sr_no, 'parameter_value'] = parameter_value

        
        component_df = component_df.sort_values(by='sr_no')
        graph_parameter_df = graph_parameter_df.sort_values(by='sr_no')

       
        new_xlsx_file_name = f"{original_filename}_{timestamp}.xlsx"
        output_file_path = os.path.join(output_folder, new_xlsx_file_name)
        with pd.ExcelWriter(output_file_path, engine='xlsxwriter') as writer:
            dataset_df.to_excel(writer, sheet_name='DataSet', index=False)
            component_df.to_excel(writer, sheet_name='Component&Fields', index=False)
            graph_parameter_df.to_excel(writer, sheet_name='GraphParameters', index=False)
            tracking_df.to_excel(writer, sheet_name='GraphFlow', index=False)

        return new_xlsx_file_name
    except Exception as e:
        print(f"An error occurred while updating the transform rule: {e}")
        return None

def generate_csv_from_dataframe(df, output_folder, original_filename, timestamp):
    df.insert(0, 'sr_no', range(1, len(df) + 1))
    csv_file_path = os.path.join(output_folder, f"{original_filename}_graph_parameters_{timestamp}.csv")
    df.to_csv(csv_file_path, index=False)
    return csv_file_path

def break_block_content(blk: List[str], patterns: Dict) -> tuple[List[Dict[str, str]], Dict[str, List[Dict[str, str]]]]:
    global sub_graph, prev_subgrh
    sub_graph = ""
    block_with_internal_section = []
    blocks_by_graph_id = {}
    graph_id_counters = {}
    prev_subgrh = ""
    for block in blk:
        start, internal, end = break_down_block(block, patterns)
        internal1 = internal if internal else tuple()
        graph_id = ""
        if start:
            graph_id = start.strip('{}').split('|')[0]
            if graph_id == patterns["GRAPH_ID"]:
                if end:
                    grh = end.strip('{}').split('|')[8].strip()
                    if (grh != '@@@1' and grh != prev_subgrh):
                        sub_graph = grh if sub_graph == "" else sub_graph + "." + grh
                        prev_subgrh = grh
                else:
                    sub_graph = sub_graph
        if graph_id.isdigit():
            if graph_id not in graph_id_counters:
                graph_id_counters[graph_id] = 1
            block_idx = graph_id_counters[graph_id]
            graph_id_counters[graph_id] += 1
            block_data = {
                f"block_idx_{block_idx}": block.strip(),
                "subgraph": sub_graph,
                "start_session": start,
                "internal_session": internal1,
                "end_session": end
            }
            block_with_internal_section.append(block_data)
            if graph_id not in blocks_by_graph_id:
                blocks_by_graph_id[graph_id] = []
            blocks_by_graph_id[graph_id].append(block_data)
    return block_with_internal_section, blocks_by_graph_id

def log_execution(saved_file_name, sandbox_file_name, timestamp):
    timestamp = datetime.strptime(timestamp, "%Y_%m_%d_%H_%M_%S").strftime("%Y-%m-%d %H:%M:%S")
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    project_root = os.path.abspath(os.path.join(script_dir))
    output_folder = os.path.join(project_root, "bbi_preprocessing_output")
    log_file_path = os.path.join(output_folder, "FAWN_execution_log.csv")
    if os.path.exists(log_file_path):
        log_df = pd.read_csv(log_file_path)
        last_execution_no = log_df['execution_no'].max()
        new_execution_no = last_execution_no + 1
    else:
        log_df = pd.DataFrame(columns=['execution_no', 'graph_name', 'date & time', 'output'])
        new_execution_no = 1
    new_log_entry = pd.DataFrame([{
        'execution_no': new_execution_no,
        'graph_name': sandbox_file_name,
        'date & time': timestamp,
        'output': saved_file_name
    }])
    log_df = pd.concat([log_df, new_log_entry], ignore_index=True)
    log_df.to_csv(log_file_path, index=False)

def main():
      user_pattern_file = None
      try:
          
          timestamp = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
          create_directory(OUTPUT_FOLDER)

          
          sandbox_file_path = input("1. Please enter the sandbox/graph file path (.mp): ").strip()
          while not sandbox_file_path.endswith('.mp'):
              print("Invalid file path. Please provide a valid .mp file.")
              sandbox_file_path = input("1. Please enter the sandbox/graph file path (.mp): ").strip()

          while True:
              tracking_file_availability = input("2. Do you have tracking file? Provide response as YES/NO (you can also use Y/y or N/n):    ").strip().lower()
              if tracking_file_availability in ["yes", "y", "Y", "YES"]:
                  tracking_file_path = input("3. Please provide the path to the tracking file: ").strip()
                  break
              elif tracking_file_availability in ["no", "n", "N", "NO"]:
                  tracking_file_availability = "NO"
                  break
              else:
                  print("Invalid response. Please provide YES or NO.")

          sandbox_file_name = os.path.basename(sandbox_file_path)

          
          print("\nLoading secure configuration...")
          patterns, user_pattern_file = load_patterns()
          print("Configuration loaded successfully.\n")

          
          print("Converting MP to TXT...")
          file_path, sandbox_file_path, original_filename = mp_to_txt(UPLOAD_FOLDER, TEXT_FOLDER, sandbox_file_path, timestamp)
          print("Conversion completed.")
          print("Reading file content...")
          content = read_file(file_path)
          print("File content read successfully.")
          print("Extracting and storing blocks...")
          blockset = extract_blocks(content)
          block_with_internal_section, blocks_by_graph_id = break_block_content(blockset, patterns)
          unique_id_blocks = {graph_id: blocks for graph_id, blocks in blocks_by_graph_id.items()}
          print("Blocks extracted and stored successfully.")
          print("Parsing blocks...")
          block_dicts = parse_blocks(unique_id_blocks, patterns)
          flattened_data = flatten_data(block_dicts)
          df = pd.DataFrame(flattened_data)
          print("Blocks parsed successfully.")
          print("Processing data...")
          dataset_df, component_df_minimized, graph_parameter_df, csv_file = process_and_save_data(df, sandbox_file_path, patterns,
  OUTPUT_FOLDER, original_filename, timestamp)
          print("Data processed successfully.")
          print("Generating CSV from graph parameters...")
          graph_csv_input = generate_csv_from_dataframe(graph_parameter_df, OUTPUT_FOLDER, original_filename, timestamp)
          print("CSV generated successfully.")
          if tracking_file_availability == "YES":
              print("Processing tracking file...")
              tracking_df = process_tracking_file(tracking_file_path)
              print("Tracking file processed successfully.")
          else:
              tracking_df = pd.DataFrame()
          print("Updating transform rule and Graph parameters data...")
          saved_file_name = update_transform_rule_and_save(dataset_df, component_df_minimized, graph_parameter_df, tracking_df, csv_file,    
   graph_csv_input, OUTPUT_FOLDER, original_filename, timestamp)
          if saved_file_name:
              log_execution(saved_file_name, sandbox_file_name, timestamp)
              print("Execution logged successfully.")
              print(f'File saved successfully! Filename: {saved_file_name}')
          else:
              print("Failed to save the output file.")

          
          for file in os.listdir(TEXT_FOLDER):
              if file.endswith(".txt"):
                  file_path = os.path.join(TEXT_FOLDER, file)
                  os.remove(file_path)
          for file in os.listdir(UPLOAD_FOLDER):
              file_path = os.path.join(UPLOAD_FOLDER, file)
              os.remove(file_path)
          print("Script execution completed.")
      except Exception as e:
          print(f"An error occurred: {e}")
      finally:
          if user_pattern_file and os.path.exists(user_pattern_file):
              os.remove(user_pattern_file)
              print(f"Temporary  file deleted")
          else:
              if user_pattern_file:
                  print("temperory file already cleaned up.")

if __name__ == "__main__":
    main()