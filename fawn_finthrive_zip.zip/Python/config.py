#config.py 
# Configuration settings 
UPLOAD_FOLDER = "user_uploaded_mp" 
TEXT_FOLDER = "user_mp_text_file" 
OUTPUT_FOLDER = "bbi_preprocessing_output"