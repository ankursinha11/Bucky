# 🚀 Quick Reference - CodebaseIntelligence RAG System

## 30-Second Quick Start

```python
# 1. Index your code
from services.multi_collection_indexer import MultiCollectionIndexer
from parsers.abinitio.parser import AbInitioParser

indexer = MultiCollectionIndexer()
parser = AbInitioParser()
result = parser.parse_directory("/path/to/abinitio")
indexer.index_abinitio(result["processes"], result["components"])

# 2. Query
from services.query_router import QueryRouter

router = QueryRouter()
routing = router.route_query("What does customer_load graph do?")
results = indexer.search_multi_collection(routing["collections"], top_k=5)
```

---

## 🚀 STAG - Streamlit UI (Recommended)

### Launch STAG
```bash
# Quick start
./start_stag.sh

# Or manually
streamlit run stag_app.py
```

### Using STAG
1. **Chat**: Ask questions in natural language
   - "What does customer_load do?"
   - "Compare Hadoop vs Ab Initio"
   - "When does job_X run?"

2. **Upload Files**: Drag and drop .mp, .jil, PDF, Excel files

3. **Compare Systems**: Use Compare tab for side-by-side analysis

4. **Export**: Download comparisons as Excel or PDF

5. **Configure**: Adjust AI model, temperature, top-k in sidebar

**See [STAG_README.md](STAG_README.md) for full documentation**

---

## 🔄 Vector Database Management

### Quick Re-Index (Interactive)
```bash
# Interactive menu - easiest option
./reindex.sh

# Shows options for:
# 1. Check status
# 2. Clear all & re-index
# 3. Clear specific collection
# 4-6. Re-index individual systems
```

### Command Line Options
```bash
# Check current status
python manage_vector_db.py --status

# Clear everything and start fresh
python manage_vector_db.py --clear-all
python manage_vector_db.py --reindex-all

# Clear just one collection
python manage_vector_db.py --clear abinitio

# Re-index specific system
python manage_vector_db.py --reindex abinitio --path /path/to/abinitio
python manage_vector_db.py --reindex autosys --path /path/to/autosys
python manage_vector_db.py --reindex documents --path /path/to/docs

# Export statistics
python manage_vector_db.py --export-stats
```

**See [VECTOR_DB_MANAGEMENT.md](VECTOR_DB_MANAGEMENT.md) for detailed guide**

---

## Common Tasks

### Parse Ab Initio with FAWN Features
```python
from parsers.abinitio.parser import AbInitioParser

parser = AbInitioParser(
    enable_filter=False,     # Parse all graphs
    enable_logging=True      # Log executions
)

result = parser.parse_directory("/path/to/abinitio")

# Check results
print(f"Graphs: {len(result['processes'])}")
print(f"Components: {len(result['components'])}")

# Check hierarchy (FAWN feature)
first_comp = result['components'][0]
print(f"Hierarchy: {first_comp.parameters.get('subgraph_hierarchy', 'N/A')}")

# Export to Excel with hierarchy columns
parser.export_to_excel("output.xlsx", source_files=result['source_files'])
```

### Parse Autosys with AI Analysis
```python
from parsers.autosys.parser import AutosysParser

parser = AutosysParser(
    enable_ai=True,          # Enable AI analysis
    enable_logging=True
)

result = parser.parse_directory("/path/to/autosys")

# Check AI analysis
from services.ai_script_analyzer import AIScriptAnalyzer

ai = AIScriptAnalyzer()
for job in result['components'][:5]:  # First 5 jobs
    analysis = ai.analyze_autosys_job(job.__dict__)
    print(f"{job.name}: {analysis.get('business_purpose')}")
```

### Create Cross-System Links
```python
from services.multi_collection_indexer import MultiCollectionIndexer

indexer = MultiCollectionIndexer()

# Parse both systems
abinitio_result = abinitio_parser.parse_directory("/path/to/abinitio")
autosys_result = autosys_parser.parse_directory("/path/to/autosys")

# Index separately
indexer.index_abinitio(abinitio_result["processes"], abinitio_result["components"])
indexer.index_autosys([j.__dict__ for j in autosys_result["components"]])

# Create links
link_stats = indexer.index_cross_system_links(
    autosys_jobs=[j.__dict__ for j in autosys_result["components"]],
    abinitio_processes=abinitio_result["processes"]
)

print(f"Created {link_stats['links']} cross-system links")
```

### Query with Intelligent Routing
```python
from services.query_router import QueryRouter
from services.multi_collection_indexer import MultiCollectionIndexer

router = QueryRouter()
indexer = MultiCollectionIndexer()

# Query examples
queries = [
    "What does customer_load graph do?",                    # → abinitio_collection
    "When does job_X run?",                                 # → autosys_collection + cross_system_links
    "Compare Hadoop and Ab Initio for customer processing", # → hadoop_collection + abinitio_collection
    "Show lineage for customer_id",                         # → ALL collections
]

for query in queries:
    routing = router.route_query(query)
    print(f"\nQuery: {query}")
    print(f"→ Collections: {routing['collections']}")
    print(f"→ Intent: {routing['intent']}")

    results = indexer.search_multi_collection(
        query=query,
        collections=routing["collections"],
        top_k=3
    )

    for coll, docs in results.items():
        if docs:
            print(f"  {coll}: {len(docs)} results")
```

### Use Azure OpenAI Embeddings
```python
from services.azure_embeddings import create_embedding_client

# Auto-detects Azure OpenAI or falls back to local
client = create_embedding_client(
    use_azure=True,
    fallback_to_local=True
)

print(f"Mode: {client.mode}")            # "azure" or "local"
print(f"Dimensions: {client.embedding_dim}")  # 3072 or 384

# Embed single text
embedding = client.embed_text("customer data processing")

# Embed batch
embeddings = client.embed_batch([
    "Ab Initio graph",
    "Hadoop script",
    "Databricks notebook"
])
```

### Full RAG Query
```python
from services.rag_chatbot_integrated import CodebaseRAGChatbot

chatbot = CodebaseRAGChatbot(
    use_local_search=True,
    vector_db_path="./outputs/vector_db"
)

# Simple query
response = chatbot.query("What does the customer_load graph do?")
print(response['answer'])

# Multi-turn conversation
chatbot.chat("Tell me about customer processing")
chatbot.chat("How does it compare to Hadoop?")  # Context-aware
chatbot.chat("Show me the schedule")            # Context-aware
```

---

## Environment Variables

```bash
# Required for Azure OpenAI features
export AZURE_OPENAI_API_KEY="your-key"
export AZURE_OPENAI_ENDPOINT="https://your-endpoint.openai.azure.com/"
export AZURE_OPENAI_API_VERSION="2024-02-15-preview"
export AZURE_OPENAI_DEPLOYMENT_NAME="gpt-4"
export AZURE_OPENAI_FAST_DEPLOYMENT="gpt-35-turbo"

# Optional
export AZURE_OPENAI_EMBEDDING_MODEL="text-embedding-3-large"
```

---

## Collection Cheat Sheet

| Collection | Contains | Query When |
|-----------|----------|------------|
| `abinitio_collection` | Graphs, components, DMLs | "Ab Initio", "graph", "component" |
| `hadoop_collection` | Hive, Pig, Spark scripts | "Hadoop", "Spark", "Hive", "Pig" |
| `databricks_collection` | Notebooks, jobs | "Databricks", "notebook" |
| `autosys_collection` | Jobs, schedules | "job", "schedule", "when does" |
| `cross_system_links` | Autosys→AbInitio flows | "job runs graph", "execution flow" |
| `documents_collection` | PDFs, reports | "documentation", "report" |

---

## Intent Detection Cheat Sheet

| Query Contains | Intent | Collections Searched |
|---------------|--------|---------------------|
| "compare", "difference" | comparison | Multiple system collections |
| "lineage", "flow", "trace" | lineage | ALL collections |
| "schedule", "trigger", "when" | schedule | autosys + cross_system_links |
| "logic", "transform" | logic | Specific system collection |
| "dependency", "depends on" | dependency | autosys_collection |
| General search | search | Default collections |

---

## Quick Checks

### Check if Collections are Indexed
```python
stats = indexer.get_stats()
for coll, info in stats.items():
    print(f"{coll}: {info.get('total_documents', 0)} docs")
```

### Check Query Routing
```python
router = QueryRouter()
print(f"Router enabled: {router.enabled}")
routing = router.route_query("test query")
print(f"Collections: {routing['collections']}")
```

### Check Embeddings
```python
from services.azure_embeddings import create_embedding_client

client = create_embedding_client()
print(f"Mode: {client.mode}")  # azure or local
print(f"Dims: {client.embedding_dim}")  # 3072 or 384
```

### Check Execution Logs
```python
import pandas as pd

# View Ab Initio execution log
log = pd.read_csv("test_output/abinitio_parser_execution_log.csv")
print(log.tail())

# View Excel with hierarchy
df = pd.read_excel("output.xlsx", sheet_name="Components&Fields")
print(df[['Component', 'Subgraph_Hierarchy', 'Final_Subgraph']].head())
```

---

## Troubleshooting One-Liners

```python
# No results found?
stats = indexer.get_stats()
print({k: v.get('total_documents', 0) for k, v in stats.items()})

# Azure OpenAI not working?
import os
print(f"API Key: {bool(os.getenv('AZURE_OPENAI_API_KEY'))}")
print(f"Endpoint: {bool(os.getenv('AZURE_OPENAI_ENDPOINT'))}")

# Routing not working?
router = QueryRouter()
print(f"Enabled: {router.enabled}, Model: {getattr(router, 'model_name', 'N/A')}")

# Embeddings check
from services.azure_embeddings import create_embedding_client
client = create_embedding_client()
print(client.get_info())
```

---

## Example Queries & Expected Results

| Query | Expected Collections | Expected Results |
|-------|---------------------|------------------|
| "What does customer_load do?" | abinitio_collection | Graph description, components |
| "When does job_X run?" | autosys, cross_system_links | Schedule, triggers, linked graph |
| "Compare Hadoop vs Ab Initio" | hadoop, abinitio | Logic from both systems |
| "Show lineage for customer_id" | ALL | Cross-system column lineage |
| "Job dependencies for X" | autosys | Job dependency chain |

---

## Files to Know

### Documentation
- [PROJECT_STATUS_SUMMARY.md](PROJECT_STATUS_SUMMARY.md) - Overall status
- [ARCHITECTURE_ANALYSIS.md](ARCHITECTURE_ANALYSIS.md) - Architecture deep dive
- [EMI_RAG_IMPLEMENTATION_GUIDE.md](EMI_RAG_IMPLEMENTATION_GUIDE.md) - Full implementation guide
- [FAWN_ENHANCEMENTS_README.md](FAWN_ENHANCEMENTS_README.md) - FAWN features

### Core Code
- `services/multi_collection_indexer.py` - Multi-system indexing
- `services/query_router.py` - Intelligent routing
- `services/azure_embeddings.py` - High-quality embeddings
- `parsers/abinitio/parser.py` - Ab Initio with FAWN
- `parsers/autosys/parser.py` - Autosys with AI

### Tests
- `test_updated_parser.py` - Test FAWN enhancements
- `test_output/` - Test output files

---

**Quick Help**: For detailed examples, see [EMI_RAG_IMPLEMENTATION_GUIDE.md](EMI_RAG_IMPLEMENTATION_GUIDE.md)
