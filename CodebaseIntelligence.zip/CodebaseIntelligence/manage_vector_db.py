#!/usr/bin/env python3
"""
Vector Database Management Script
==================================
Manage, clear, and re-index your vector database collections

Usage:
    python manage_vector_db.py --help
    python manage_vector_db.py --status
    python manage_vector_db.py --clear-all
    python manage_vector_db.py --clear abinitio_collection
    python manage_vector_db.py --reindex-all
    python manage_vector_db.py --reindex abinitio
"""

import argparse
import shutil
from pathlib import Path
from typing import List, Optional
from loguru import logger
import sys

from services.multi_collection_indexer import MultiCollectionIndexer
from parsers.abinitio.parser import AbInitioParser
from parsers.autosys.parser import AutosysParser
from parsers.documents.document_parser import DocumentParser


class VectorDBManager:
    """Manage vector database operations"""

    def __init__(self, vector_db_path: str = "./outputs/vector_db"):
        self.vector_db_path = Path(vector_db_path)
        self.indexer = None

    def show_status(self):
        """Show current vector database status"""
        print("\n" + "="*60)
        print("📊 Vector Database Status")
        print("="*60)

        if not self.vector_db_path.exists():
            print("\n⚠️  Vector database does not exist!")
            print(f"   Path: {self.vector_db_path}")
            print("\nRun --reindex-all to create and populate it.")
            return

        print(f"\n📁 Database Path: {self.vector_db_path}")

        # Show directory size
        total_size = sum(f.stat().st_size for f in self.vector_db_path.rglob('*') if f.is_file())
        print(f"💾 Total Size: {total_size / (1024*1024):.2f} MB")

        # Initialize indexer to get stats
        try:
            self.indexer = MultiCollectionIndexer(vector_db_path=str(self.vector_db_path))
            stats = self.indexer.get_stats()

            print("\n📈 Collection Statistics:")
            print("-" * 60)

            total_docs = 0
            for collection_name, collection_stats in stats.items():
                doc_count = collection_stats.get('total_documents', 0)
                total_docs += doc_count

                # Display collection info
                display_name = collection_name.replace('_collection', '').title()
                print(f"\n  {display_name}:")
                print(f"    Documents: {doc_count:,}")

                # Show additional stats if available
                if 'error' in collection_stats:
                    print(f"    ⚠️  Error: {collection_stats['error']}")

            print("\n" + "-" * 60)
            print(f"📊 Total Documents: {total_docs:,}")

        except Exception as e:
            print(f"\n⚠️  Error reading database: {e}")

        print("\n" + "="*60 + "\n")

    def clear_all(self, confirm: bool = False):
        """Clear entire vector database"""
        print("\n" + "="*60)
        print("🗑️  Clear Entire Vector Database")
        print("="*60)

        if not self.vector_db_path.exists():
            print("\n✓ Vector database already empty (doesn't exist)")
            return

        if not confirm:
            print(f"\n⚠️  This will DELETE all data in:")
            print(f"   {self.vector_db_path}")

            response = input("\n   Type 'yes' to confirm: ")
            if response.lower() != 'yes':
                print("\n✗ Cancelled")
                return

        try:
            shutil.rmtree(self.vector_db_path)
            print("\n✓ Vector database cleared successfully")
            print(f"   Deleted: {self.vector_db_path}")
        except Exception as e:
            print(f"\n✗ Error clearing database: {e}")

    def clear_collection(self, collection_name: str):
        """Clear specific collection"""
        print("\n" + "="*60)
        print(f"🗑️  Clear Collection: {collection_name}")
        print("="*60)

        if not self.vector_db_path.exists():
            print("\n⚠️  Vector database doesn't exist")
            return

        # Map friendly names to actual collection names
        collection_map = {
            'abinitio': 'abinitio_collection',
            'hadoop': 'hadoop_collection',
            'databricks': 'databricks_collection',
            'autosys': 'autosys_collection',
            'links': 'cross_system_links',
            'documents': 'documents_collection',
        }

        actual_name = collection_map.get(collection_name, collection_name)

        try:
            # Initialize indexer
            self.indexer = MultiCollectionIndexer(vector_db_path=str(self.vector_db_path))

            # Check if collection exists
            if actual_name not in self.indexer.collections:
                print(f"\n⚠️  Collection '{actual_name}' not found")
                print(f"\nAvailable collections: {', '.join(self.indexer.collections.keys())}")
                return

            # Get current count
            stats = self.indexer.get_stats()
            current_count = stats.get(actual_name, {}).get('total_documents', 0)

            print(f"\n📊 Current documents: {current_count:,}")

            response = input(f"\n   Clear this collection? (yes/no): ")
            if response.lower() != 'yes':
                print("\n✗ Cancelled")
                return

            # Clear collection (delete and recreate)
            collection_path = self.vector_db_path / actual_name
            if collection_path.exists():
                shutil.rmtree(collection_path)
                print(f"\n✓ Collection '{actual_name}' cleared successfully")
            else:
                print(f"\n⚠️  Collection directory not found: {collection_path}")

        except Exception as e:
            print(f"\n✗ Error clearing collection: {e}")

    def reindex_all(self,
                    abinitio_path: Optional[str] = None,
                    autosys_path: Optional[str] = None,
                    documents_path: Optional[str] = None):
        """Re-index all collections from scratch"""
        print("\n" + "="*60)
        print("🔄 Re-Index All Collections")
        print("="*60)

        # Ask for paths if not provided
        if not abinitio_path:
            abinitio_path = input("\nAb Initio directory path (or skip): ").strip()
            if not abinitio_path or abinitio_path.lower() == 'skip':
                abinitio_path = None

        if not autosys_path:
            autosys_path = input("Autosys directory path (or skip): ").strip()
            if not autosys_path or autosys_path.lower() == 'skip':
                autosys_path = None

        if not documents_path:
            documents_path = input("Documents directory path (or skip): ").strip()
            if not documents_path or documents_path.lower() == 'skip':
                documents_path = None

        # Clear existing database
        print("\n📋 Step 1: Clearing existing database...")
        self.clear_all(confirm=True)

        # Initialize fresh indexer
        print("\n📋 Step 2: Initializing fresh indexer...")
        self.indexer = MultiCollectionIndexer(vector_db_path=str(self.vector_db_path))

        # Index Ab Initio
        if abinitio_path:
            self.reindex_abinitio(abinitio_path)

        # Index Autosys
        if autosys_path:
            self.reindex_autosys(autosys_path)

        # Index Documents
        if documents_path:
            self.reindex_documents(documents_path)

        # Create cross-system links if both Ab Initio and Autosys indexed
        if abinitio_path and autosys_path:
            print("\n📋 Creating cross-system links...")
            # This would require storing parsed data, simplified for now
            print("   ℹ️  Cross-system links require re-parsing. Run separately if needed.")

        # Show final status
        print("\n" + "="*60)
        print("✓ Re-indexing Complete!")
        print("="*60)
        self.show_status()

    def reindex_abinitio(self, directory_path: str):
        """Re-index Ab Initio collection"""
        print("\n📋 Indexing Ab Initio...")
        print(f"   Path: {directory_path}")

        if not Path(directory_path).exists():
            print(f"   ✗ Directory not found: {directory_path}")
            return

        try:
            parser = AbInitioParser()
            result = parser.parse_directory(directory_path)

            if self.indexer is None:
                self.indexer = MultiCollectionIndexer(vector_db_path=str(self.vector_db_path))

            stats = self.indexer.index_abinitio(
                processes=result.get("processes", []),
                components=result.get("components", [])
            )

            print(f"   ✓ Indexed {stats.get('graphs', 0)} graphs")
            print(f"   ✓ Indexed {stats.get('components', 0)} components")

        except Exception as e:
            print(f"   ✗ Error indexing Ab Initio: {e}")
            logger.error(f"Ab Initio indexing error: {e}", exc_info=True)

    def reindex_autosys(self, directory_path: str):
        """Re-index Autosys collection"""
        print("\n📋 Indexing Autosys...")
        print(f"   Path: {directory_path}")

        if not Path(directory_path).exists():
            print(f"   ✗ Directory not found: {directory_path}")
            return

        try:
            parser = AutosysParser()
            result = parser.parse_directory(directory_path)

            if self.indexer is None:
                self.indexer = MultiCollectionIndexer(vector_db_path=str(self.vector_db_path))

            # Convert components to dicts
            jobs_dict = [job.__dict__ for job in result.get("components", [])]

            stats = self.indexer.index_autosys(jobs=jobs_dict)

            print(f"   ✓ Indexed {stats.get('jobs', 0)} Autosys jobs")

        except Exception as e:
            print(f"   ✗ Error indexing Autosys: {e}")
            logger.error(f"Autosys indexing error: {e}", exc_info=True)

    def reindex_documents(self, directory_path: str):
        """Re-index Documents collection"""
        print("\n📋 Indexing Documents...")
        print(f"   Path: {directory_path}")

        if not Path(directory_path).exists():
            print(f"   ✗ Directory not found: {directory_path}")
            return

        try:
            parser = DocumentParser()
            docs = parser.parse_directory(directory_path, recursive=True)

            if self.indexer is None:
                self.indexer = MultiCollectionIndexer(vector_db_path=str(self.vector_db_path))

            stats = parser.index_documents(docs, self.indexer)

            print(f"   ✓ Indexed {stats.get('files', 0)} documents")
            print(f"   ✓ Total chunks: {stats.get('total', 0)}")

        except Exception as e:
            print(f"   ✗ Error indexing documents: {e}")
            logger.error(f"Document indexing error: {e}", exc_info=True)

    def export_stats(self, output_file: str = "vector_db_stats.json"):
        """Export database statistics to JSON"""
        import json

        print(f"\n📤 Exporting stats to {output_file}...")

        try:
            if self.indexer is None:
                self.indexer = MultiCollectionIndexer(vector_db_path=str(self.vector_db_path))

            stats = self.indexer.get_stats()

            with open(output_file, 'w') as f:
                json.dump(stats, f, indent=2)

            print(f"✓ Stats exported to {output_file}")

        except Exception as e:
            print(f"✗ Error exporting stats: {e}")


def main():
    """Main CLI interface"""
    parser = argparse.ArgumentParser(
        description="Vector Database Management Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Show current status
  python manage_vector_db.py --status

  # Clear entire database
  python manage_vector_db.py --clear-all

  # Clear specific collection
  python manage_vector_db.py --clear abinitio

  # Re-index everything (will prompt for paths)
  python manage_vector_db.py --reindex-all

  # Re-index specific system
  python manage_vector_db.py --reindex abinitio --path /path/to/abinitio

  # Export statistics
  python manage_vector_db.py --export-stats
        """
    )

    parser.add_argument(
        '--vector-db-path',
        default='./outputs/vector_db',
        help='Path to vector database (default: ./outputs/vector_db)'
    )

    parser.add_argument(
        '--status',
        action='store_true',
        help='Show database status and statistics'
    )

    parser.add_argument(
        '--clear-all',
        action='store_true',
        help='Clear entire vector database'
    )

    parser.add_argument(
        '--clear',
        metavar='COLLECTION',
        help='Clear specific collection (abinitio, hadoop, databricks, autosys, links, documents)'
    )

    parser.add_argument(
        '--reindex-all',
        action='store_true',
        help='Re-index all collections from scratch'
    )

    parser.add_argument(
        '--reindex',
        metavar='SYSTEM',
        help='Re-index specific system (abinitio, autosys, documents)'
    )

    parser.add_argument(
        '--path',
        help='Directory path for indexing (used with --reindex)'
    )

    parser.add_argument(
        '--export-stats',
        action='store_true',
        help='Export database statistics to JSON'
    )

    parser.add_argument(
        '--yes',
        action='store_true',
        help='Auto-confirm prompts (use with caution!)'
    )

    args = parser.parse_args()

    # Create manager
    manager = VectorDBManager(vector_db_path=args.vector_db_path)

    # Execute command
    if args.status:
        manager.show_status()

    elif args.clear_all:
        manager.clear_all(confirm=args.yes)

    elif args.clear:
        manager.clear_collection(args.clear)

    elif args.reindex_all:
        manager.reindex_all()

    elif args.reindex:
        if not args.path:
            print("❌ Error: --path required for --reindex")
            print("Example: python manage_vector_db.py --reindex abinitio --path /path/to/abinitio")
            sys.exit(1)

        if args.reindex == 'abinitio':
            manager.reindex_abinitio(args.path)
        elif args.reindex == 'autosys':
            manager.reindex_autosys(args.path)
        elif args.reindex == 'documents':
            manager.reindex_documents(args.path)
        else:
            print(f"❌ Unknown system: {args.reindex}")
            print("Valid options: abinitio, autosys, documents")
            sys.exit(1)

    elif args.export_stats:
        manager.export_stats()

    else:
        # No command specified, show status by default
        manager.show_status()
        print("\nℹ️  Run with --help for usage options")


if __name__ == "__main__":
    main()
