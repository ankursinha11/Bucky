"""
Ab Initio MP File Parser - PRODUCTION VERSION
==============================================
FAWN-based parser with clean parameter extraction

Features:
- Clean parameter name/value extraction (FAWN approach)
- GraphFlow extraction with component ID mapping
- Component extraction
- DML parsing
- Transform logic extraction
"""

import re
from typing import List, Dict, Any, Optional
from loguru import logger


class MPFileParser:
    """
    Ab Initio .mp file parser with FAWN-style clean extraction
    """

    def __init__(self, patterns: Dict[str, Any]):
        """
        Initialize parser with patterns

        Args:
            patterns: Pattern dictionary for regex matching
        """
        self.patterns = patterns

    def extract_blocks(self, content: str) -> List[str]:
        """
        Extract all top-level blocks using bracket matching

        Args:
            content: Raw .mp file content

        Returns:
            List of block strings
        """
        blocks = []
        stack = []
        current_block = ''

        for char in content:
            if char == '{':
                if not stack:
                    current_block = ''
                stack.append(char)
                current_block += char
            elif char == '}':
                if stack:
                    stack.pop()
                current_block += char
                if not stack:
                    blocks.append(current_block.strip())
            elif stack:
                current_block += char

        if stack:
            logger.warning("Warning: Unmatched '{' detected. Some blocks may be incomplete.")

        return blocks

    def break_down_block(self, block: str) -> tuple:
        """
        Break down block into start, internal, and end sections (FAWN approach)

        Args:
            block: Block string

        Returns:
            Tuple of (start_section, internal_section, end_section)
        """
        # Look for internal section pattern (parameters)
        internal_match = re.search(r'XXparameter_set\|@@@@\{\{(.*?)\}\}@', block, re.DOTALL)

        if internal_match:
            start_index = internal_match.start()
            end_index = internal_match.end()

            return (
                block[:start_index].strip(),
                internal_match.group(0).strip(),
                block[end_index:].strip()
            )
        else:
            # No internal section found
            return block.strip(), "", ""

    def extract_and_store_blocks_with_hierarchy(self, content: str) -> tuple:
        """
        Extract blocks with subgraph hierarchy tracking (FAWN feature)

        This tracks nested subgraphs like: parent.child.grandchild

        Args:
            content: Raw .mp file content

        Returns:
            Tuple of (blocks_list, blocks_by_graph_id)
        """
        blocks = self.extract_blocks(content)

        # Track subgraph hierarchy
        subgraph_hierarchy = ""
        prev_subgraph = ""
        blocks_by_graph_id = {}
        graph_id_counters = {}

        for block in blocks:
            start, internal, end = self.break_down_block(block)

            # Extract graph ID from start section
            graph_id_match = re.match(r'\{(\d+)\|', start)
            if graph_id_match:
                graph_id = graph_id_match.group(1)

                # Check if this is a graph (type 1)
                if '|1|' in start or 'XXGgraph' in block:
                    # Extract graph name from end section
                    if end:
                        end_parts = end.strip('{}').split('|')
                        if len(end_parts) > 8:
                            graph_name = end_parts[8].strip()

                            # Update hierarchy
                            if graph_name and graph_name != '@@@1' and graph_name != prev_subgraph:
                                if subgraph_hierarchy == "":
                                    subgraph_hierarchy = graph_name
                                else:
                                    subgraph_hierarchy = subgraph_hierarchy + "." + graph_name
                                prev_subgraph = graph_name

                # Track block by graph ID
                if graph_id.isdigit():
                    if graph_id not in graph_id_counters:
                        graph_id_counters[graph_id] = 1

                    block_idx = graph_id_counters[graph_id]
                    graph_id_counters[graph_id] += 1

                    block_data = {
                        f"block_idx_{block_idx}": block.strip(),
                        "subgraph_hierarchy": subgraph_hierarchy,
                        "start_session": start,
                        "internal_session": internal,
                        "end_session": end
                    }

                    if graph_id not in blocks_by_graph_id:
                        blocks_by_graph_id[graph_id] = []

                    blocks_by_graph_id[graph_id].append(block_data)

        return blocks, blocks_by_graph_id

    def extract_component_name(self, block: str, component_type: str) -> str:
        """
        Extract component name from block

        Args:
            block: Component block string
            component_type: Type of component

        Returns:
            Component name or empty string
        """
        # Pattern: {ID|TYPE|NAME|...}
        pattern = rf'\{{\d+\|{re.escape(component_type)}\|([^|]+)\|'
        match = re.search(pattern, block)

        if match:
            return match.group(1).strip()

        return ""

    def extract_parameter_blocks(self, block: str) -> List[Dict[str, str]]:
        """
        Extract parameters with CLEAN name/value pairs (FAWN's approach)

        This extracts ONLY field 2 (name) and field 3 (value) from the pipe-separated format:
        {30001002|XXparameter|name|value|...}

        Args:
            block: Component block containing parameters

        Returns:
            List of clean parameter dictionaries with 'parameter_name' and 'parameter_value'
        """
        parameter_list = []

        # Look for XXparameter_set sections
        param_set_pattern = r'XXparameter_set\|@@@@\{\{(.*?)\}\}@'
        matches = re.finditer(param_set_pattern, block, re.DOTALL)

        for match in matches:
            parameter_section = match.group(1)

            # Extract individual parameters
            # Pattern: {ID|XXparameter|!?NAME|VALUE|ORDER|VERSION|TYPE|EXTRA}
            param_pattern = r'\{(\d+)\|XXparameter\|!?([^|]+)\|([^|]*)\|([^|]*)\|([^|]*)\|([^|]*)\|([^}]*)\}'

            for param_match in re.finditer(param_pattern, parameter_section):
                param_name = param_match.group(2).strip()  # Field 2: Clean name
                param_value = param_match.group(3).strip()  # Field 3: Clean value

                # Skip internal Ab Initio parameters
                if not param_name.startswith("_ab_"):
                    param_dict = {
                        "parameter_name": param_name,  # CLEAN
                        "parameter_value": param_value,  # CLEAN
                    }
                    parameter_list.append(param_dict)

        return parameter_list

    def extract_graph_parameters(self, blocks: List[str]) -> List[Dict[str, str]]:
        """
        Extract graph-level parameters

        Args:
            blocks: List of all blocks

        Returns:
            List of graph parameter dictionaries
        """
        graph_params = []

        for block in blocks:
            # FIXED: Case-sensitive - it's XXGgraph not XXgraph!
            if 'XXGgraph' in block and 'XXparameter' in block:
                params = self.extract_parameter_blocks(block)
                graph_params.extend(params)
                break

        return graph_params

    def extract_components(self, blocks: List[str], blocks_by_graph_id: Dict = None) -> List[Dict[str, Any]]:
        """
        Extract all components from blocks with subgraph hierarchy tracking

        Args:
            blocks: List of all blocks
            blocks_by_graph_id: Optional dictionary with subgraph hierarchy data

        Returns:
            List of component dictionaries with subgraph_hierarchy field
        """
        components = []
        component_types = self.patterns.get("ALLOWED_COMPONENT_TYPES", [])

        # Build a mapping of component_id to subgraph_hierarchy
        id_to_hierarchy = {}
        if blocks_by_graph_id:
            for graph_id, block_list in blocks_by_graph_id.items():
                for block_entry in block_list:
                    hierarchy = block_entry.get("subgraph_hierarchy", "")
                    # Extract component ID from the block
                    for key in block_entry.keys():
                        if key.startswith("block_idx_"):
                            block_content = block_entry[key]
                            id_match = re.search(r'\{(\d+)\|', block_content)
                            if id_match:
                                comp_id = id_match.group(1)
                                id_to_hierarchy[comp_id] = hierarchy

        for block in blocks:
            for comp_type in component_types:
                if comp_type in block:
                    # Extract component ID
                    id_match = re.search(r'\{(\d+)\|', block)
                    if id_match:
                        comp_id = id_match.group(1)

                        # Extract component name
                        comp_name = self.extract_component_name(block, comp_type)

                        # Extract parameters (CLEAN format!)
                        parameters = self.extract_parameter_blocks(block)

                        # Get subgraph hierarchy for this component
                        subgraph_hierarchy = id_to_hierarchy.get(comp_id, "")

                        # Calculate final_subgraph (last two levels)
                        final_subgraph = ""
                        if subgraph_hierarchy:
                            parts = subgraph_hierarchy.split('.')
                            if len(parts) >= 2:
                                final_subgraph = '.'.join(parts[-2:])
                            elif len(parts) == 1:
                                final_subgraph = parts[0]

                        component_data = {
                            "component_id": comp_id,
                            "component_type": comp_type,
                            "component_name": comp_name or f"{comp_type}_{comp_id}",
                            "parameters": parameters,  # List of clean param dicts
                            "parameter_count": len(parameters),
                            "subgraph_hierarchy": subgraph_hierarchy,
                            "final_subgraph": final_subgraph,
                        }

                        components.append(component_data)
                    break

        return components

    def _build_component_id_map(self, blocks: List[str]) -> Dict[str, str]:
        """
        Build mapping from component IDs to component names for GraphFlow

        Components are XXGgraph entities with prototype_path parameters
        Example: {2010600005|XXGgraph|...|{...XXparameter|!prototype_path|$PUB_ESCAN_COMPONENTS/eScanFileReader.mp|...

        Args:
            blocks: List of all blocks

        Returns:
            Dictionary mapping ID -> Name
        """
        id_map = {}

        # Combine blocks for easier pattern matching
        content = ''.join(blocks)

        # Find all XXGgraph entities with prototype_path
        # Pattern: {ID|XXGgraph|...|{...XXparameter|!prototype_path|PATH/ComponentName.mp|...
        graph_pattern = r'\{(\d+)\|XXGgraph\|[^}]*\{[^}]*XXparameter\|!prototype_path\|([^|]+)\|'

        for match in re.finditer(graph_pattern, content):
            comp_id = match.group(1)
            prototype_path = match.group(2)

            # Extract component name from path (e.g., "$PUB_ESCAN_COMPONENTS/eScanFileReader.mp" -> "eScanFileReader")
            if '/' in prototype_path:
                filename = prototype_path.split('/')[-1]
                comp_name = filename.replace('.mp', '').replace('.mfs', '')
            else:
                comp_name = prototype_path.replace('.mp', '').replace('.mfs', '')

            if comp_name:
                id_map[comp_id] = comp_name

        logger.debug(f"Built component ID map: {len(id_map)} components from XXGgraph entities")

        return id_map

    def extract_graph_flow(self, blocks: List[str]) -> List[Dict[str, str]]:
        """
        Extract GraphFlow (data lineage) connections using port-based flow system

        Flow chain: Flow → Source Port → Component A, Flow → Target Port → Component B

        Args:
            blocks: List of all blocks

        Returns:
            List of flow dictionaries with source/target component names
        """
        flows = []

        # Combine all blocks into one string for pattern matching
        content = ''.join(blocks)

        # STEP 1: Build component ID → Name mapping
        id_map = self._build_component_id_map(blocks)
        logger.debug(f"Built component ID map with {len(id_map)} components")

        # STEP 2: Build port_id → graph_id mapping (DIRECT!)
        # Format: {entity_id|XXGvertex_iport_iport|graph_id|0|port_id|0|{...}}
        # Format: {entity_id|XXGvertex_oport_oport|graph_id|0|port_id|0|{...}}
        port_to_graph = {}

        # Input ports
        iport_pattern = r'\{[^|]+\|XXGvertex_iport_iport\|(\d+)\|0\|(\d+)\|'
        for match in re.finditer(iport_pattern, content):
            graph_id = match.group(1)
            port_id = match.group(2)
            port_to_graph[port_id] = graph_id

        # Output ports
        oport_pattern = r'\{[^|]+\|XXGvertex_oport_oport\|(\d+)\|0\|(\d+)\|'
        for match in re.finditer(oport_pattern, content):
            graph_id = match.group(1)
            port_id = match.group(2)
            port_to_graph[port_id] = graph_id

        logger.debug(f"Mapped {len(port_to_graph)} ports directly to graphs")

        # STEP 4: Build flow_id → (source_port_id, target_port_id) mapping
        # Format: {entity_id|XXGiport_src_flow|flow_id|0|source_port_id|0|{...}}
        # Format: {entity_id|XXGoport_dst_flow|flow_id|0|target_port_id|0|{...}}
        flow_to_source_port = {}
        flow_to_target_port = {}

        # Source ports (output ports that are sources of flows)
        src_pattern = r'\{[^|]+\|XXGiport_src_flow\|(\d+)\|0\|(\d+)\|'
        for match in re.finditer(src_pattern, content):
            flow_id = match.group(1)
            source_port_id = match.group(2)
            flow_to_source_port[flow_id] = source_port_id

        # Target ports (input ports that are destinations of flows)
        dst_pattern = r'\{[^|]+\|XXGoport_dst_flow\|(\d+)\|0\|(\d+)\|'
        for match in re.finditer(dst_pattern, content):
            flow_id = match.group(1)
            target_port_id = match.group(2)
            flow_to_target_port[flow_id] = target_port_id

        logger.debug(f"Found {len(flow_to_source_port)} source ports and {len(flow_to_target_port)} target ports for flows")

        # STEP 4: Trace complete flow chain (2-layer mapping!)
        # Flow → Source Port → Graph (Component)
        # Flow → Target Port → Graph (Component)
        all_flow_ids = set(flow_to_source_port.keys()) | set(flow_to_target_port.keys())

        for flow_id in all_flow_ids:
            source_port_id = flow_to_source_port.get(flow_id)
            target_port_id = flow_to_target_port.get(flow_id)

            if source_port_id and target_port_id:
                # Map port → graph (component) directly
                source_graph_id = port_to_graph.get(source_port_id)
                target_graph_id = port_to_graph.get(target_port_id)

                if source_graph_id and target_graph_id:
                    source_name = id_map.get(source_graph_id, f"graph_{source_graph_id}")
                    target_name = id_map.get(target_graph_id, f"graph_{target_graph_id}")

                    flow = {
                        "flow_id": flow_id,
                        "source_component_id": source_graph_id,
                        "source_component_name": source_name,
                        "target_component_id": target_graph_id,
                        "target_component_name": target_name,
                    }
                    flows.append(flow)

        logger.debug(f"Extracted {len(flows)} complete component→component flows")

        return flows

    def parse_mp_file(self, file_path: str, content: str, use_hierarchy: bool = True) -> Dict[str, Any]:
        """
        Parse complete .mp file with FAWN enhancements

        Args:
            file_path: Path to .mp file
            content: File content
            use_hierarchy: Whether to track subgraph hierarchy (default: True, FAWN feature)

        Returns:
            Dictionary with all parsed data including subgraph hierarchy
        """
        logger.info(f"Parsing MP file with FAWN approach: {file_path}")

        # Extract blocks with or without hierarchy tracking
        if use_hierarchy:
            blocks, blocks_by_graph_id = self.extract_and_store_blocks_with_hierarchy(content)
            logger.debug(f"Extracted {len(blocks)} blocks with hierarchy tracking")
        else:
            blocks = self.extract_blocks(content)
            blocks_by_graph_id = None

        # Extract graph parameters (CLEAN format!)
        graph_parameters = self.extract_graph_parameters(blocks)

        # Extract components with hierarchy info
        components = self.extract_components(blocks, blocks_by_graph_id)

        # Extract graph flow
        graph_flow = self.extract_graph_flow(blocks)

        result = {
            "file_path": file_path,
            "total_blocks": len(blocks),
            "graph_parameters": graph_parameters,  # List of clean param dicts
            "components": components,  # Each has 'parameters' list + subgraph_hierarchy
            "component_count": len(components),
            "graph_flow": graph_flow,  # Source/target with clean names
            "flow_count": len(graph_flow),
            "blocks_by_graph_id": blocks_by_graph_id,  # For advanced analysis
        }

        logger.info(f"✓ Parsed: {len(components)} components, "
                   f"{len(graph_parameters)} graph params, {len(graph_flow)} flows")

        return result
