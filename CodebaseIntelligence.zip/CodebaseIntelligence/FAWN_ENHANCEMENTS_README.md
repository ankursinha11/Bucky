# FAWN Enhancements for Abinitio & Autosys Parsers

## Overview

This document describes the FAWN-inspired enhancements made to the CodebaseIntelligence Abinitio and Autosys parsers. These improvements enhance parsing accuracy, add AI-powered analysis, and provide better tracking and security features.

## What's New

### 1. Subgraph Hierarchy Tracking ✨

**Feature**: Tracks nested subgraphs in Ab Initio graphs with full hierarchy paths.

**Example Hierarchy**:
```
Graph4.1005_SG_HelperFoundCoverages.SG_HelperFoundCoverages.180_eScanDataReader.eScanFileReader.130_RMMF
```

**Benefits**:
- Better organization of complex graphs
- Understand component nesting levels
- Track subgraph dependencies

**Excel Columns Added**:
- `Subgraph_Hierarchy`: Full hierarchy path (e.g., `parent.child.grandchild`)
- `Final_Subgraph`: Last two levels of hierarchy (e.g., `child.grandchild`)

### 2. Execution Logging 📊

**Feature**: Automatic logging of every parser execution to CSV file.

**Log Location**: `abinitio_parser_execution_log.csv` (in output folder)

**Log Columns**:
- `execution_no`: Incremental execution number
- `timestamp`: When the parse was run
- `source_files`: List of .mp files parsed
- `graphs_parsed`: Total number of graphs
- `output_file`: Generated Excel filename

**Use Cases**:
- Audit trail of parsing activities
- Track when graphs were last parsed
- Debugging and troubleshooting

### 3. AI-Powered Analysis 🤖

**Feature**: Azure OpenAI GPT-4 analysis of Ab Initio components and Autosys jobs.

#### For Ab Initio Components:
```python
from services.ai_script_analyzer import AIScriptAnalyzer

analyzer = AIScriptAnalyzer()

# Analyze a component
analysis = analyzer.analyze_abinitio_component(component_data)
```

**Returns**:
- `business_purpose`: What the component does in business terms
- `business_logic_summary`: Detailed explanation
- `key_transformations`: List of transformations
- `data_quality_considerations`: Impact on data quality
- `optimization_suggestions`: Performance improvements
- `potential_issues`: Risks and concerns

#### For Complete Graphs:
```python
# Analyze entire graph
graph_analysis = analyzer.analyze_abinitio_graph(graph_data)
```

**Returns**:
- `business_purpose`: Overall business purpose
- `data_flow_summary`: How data flows through graph
- `business_value`: Value to the organization
- `architecture_pattern`: Design pattern used
- `complexity_assessment`: Low/Medium/High with explanation

#### For Autosys Jobs:
```python
# Analyze Autosys job
job_analysis = analyzer.analyze_autosys_job(job_data)
```

**Returns**:
- `business_purpose`: Why the job exists
- `scheduling_intent`: Why/when it runs
- `downstream_systems`: Systems it interacts with
- `business_criticality`: High/Medium/Low with explanation

### 4. Pattern File Encryption 🔐

**Feature**: Encrypt pattern YAML files for security (optional).

**Setup**:
```bash
cd CodebaseIntelligence/parsers/abinitio

# Encrypt patterns.yaml
python pattern_encryption.py encrypt patterns.yaml
```

**Files Created**:
- `.ip/pttyml`: Encrypted pattern file
- `.ip/.sk`: Encryption key (keep secure!)

**Loading Encrypted Patterns**:
```python
from parsers.abinitio.pattern_encryption import load_encrypted_patterns

patterns = load_encrypted_patterns()
```

**Benefits**:
- Protect proprietary parsing patterns
- Secure deployment to production
- Per-user decryption with automatic cleanup

## Usage Examples

### Basic Parsing with All Features

```python
from parsers.abinitio.parser import AbInitioParser

# Initialize parser with enhancements
parser = AbInitioParser(
    enable_filter=False,    # Parse all graphs (or True for filtered list)
    enable_logging=True     # Enable execution logging
)

# Parse directory
result = parser.parse_directory("/path/to/abinitio/graphs")

# Export to Excel with source files for logging
parser.export_to_excel(
    output_path="output.xlsx",
    source_files=result['source_files']
)
```

### Using AI Analysis

```python
from parsers.abinitio.parser import AbInitioParser
from services.ai_script_analyzer import AIScriptAnalyzer

# Setup
parser = AbInitioParser()
ai_analyzer = AIScriptAnalyzer()

# Parse graphs
result = parser.parse_directory("/path/to/graphs")

# Analyze each graph with AI
for mp_data in parser.raw_mp_data:
    graph_analysis = ai_analyzer.analyze_abinitio_graph(mp_data)

    print(f"Graph: {mp_data['file_name']}")
    print(f"Purpose: {graph_analysis.get('business_purpose')}")
    print(f"Complexity: {graph_analysis.get('complexity_assessment')}")
```

### Accessing Subgraph Hierarchy

```python
# After parsing
for mp_data in parser.raw_mp_data:
    components = mp_data.get("components", [])

    for comp in components:
        hierarchy = comp.get("subgraph_hierarchy", "")
        final_subgraph = comp.get("final_subgraph", "")

        print(f"Component: {comp['component_name']}")
        print(f"  Full Hierarchy: {hierarchy}")
        print(f"  Final Level: {final_subgraph}")
```

## Configuration

### Azure OpenAI Setup (for AI Features)

Set environment variables:
```bash
export AZURE_OPENAI_API_KEY="your-api-key"
export AZURE_OPENAI_ENDPOINT="https://your-endpoint.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT_NAME="gpt-4"
export AZURE_OPENAI_API_VERSION="2024-02-15-preview"
```

### Disabling Features

```python
# Disable logging
parser = AbInitioParser(enable_logging=False)

# Disable AI analysis
from parsers.abinitio.deep_parser import DeepAbInitioParser
deep_parser = DeepAbInitioParser(use_ai=False)
```

## Excel Output Format

### Sheet 1: GraphParameters
| Graph | Parameter | Value |
|-------|-----------|-------|
| graph1 | param1 | value1 |

### Sheet 2: Components&Fields (NEW COLUMNS)
| Graph | **Subgraph_Hierarchy** | **Final_Subgraph** | Component | Component_Type | Field_Name | Field_Value |
|-------|------------------------|-------------------|-----------|----------------|------------|-------------|
| graph1 | parent.child.grandchild | child.grandchild | comp1 | Transform | field1 | value1 |

### Sheet 3: GraphFlow
| Source_Graph | Target_Graph | Source_Job | Target_Job | Dependency_Type | Source |
|--------------|--------------|------------|------------|-----------------|--------|
| graph1 | graph2 | comp1 | comp2 | internal | MP_File |

### Sheet 4: Summary
| Module | Graph_Name | Total_Components | Total_Parameters | Total_Flows |
|--------|------------|------------------|------------------|-------------|
| module1 | graph1 | 100 | 50 | 20 |

## Testing

Run the test script to verify all features:

```bash
cd CodebaseIntelligence
python test_updated_parser.py
```

**Test Output**:
- Excel file with all enhanced columns
- Execution log CSV
- Console output showing hierarchy tracking

## Migration from Old Parser

The enhanced parser is **backward compatible**. Existing code will work without changes.

### Optional Upgrades:

1. **Enable Execution Logging**:
   ```python
   # Old
   parser = AbInitioParser()

   # New (with logging)
   parser = AbInitioParser(enable_logging=True)
   ```

2. **Use Subgraph Hierarchy**:
   ```python
   # Access new fields in components
   for comp in components:
       hierarchy = comp.get("subgraph_hierarchy", "")
   ```

3. **Add AI Analysis**:
   ```python
   from services.ai_script_analyzer import AIScriptAnalyzer

   analyzer = AIScriptAnalyzer()
   analysis = analyzer.analyze_abinitio_component(component_data)
   ```

## Performance Impact

- **Subgraph Hierarchy Tracking**: Minimal (<5% overhead)
- **Execution Logging**: Negligible
- **AI Analysis**: 2-5 seconds per component (network-dependent)
  - Recommended: Use AI selectively on critical components

## Troubleshooting

### Issue: Hierarchy not showing in Excel

**Solution**: Verify parser was initialized with hierarchy enabled:
```python
result = parser.mp_parser.parse_mp_file(file_path, content, use_hierarchy=True)
```

### Issue: Execution log not created

**Solution**: Check write permissions on output folder and ensure logging is enabled:
```python
parser = AbInitioParser(enable_logging=True)
```

### Issue: AI analysis fails

**Solution**: Verify Azure OpenAI credentials:
```python
import os
print(os.getenv("AZURE_OPENAI_API_KEY"))  # Should not be None
```

## Dependencies

### Required:
- pandas
- openpyxl
- loguru
- pyyaml

### Optional (for AI features):
- openai (Azure OpenAI SDK)

### Optional (for encryption):
- cryptography

**Install all**:
```bash
pip install pandas openpyxl loguru pyyaml openai cryptography
```

## Best Practices

1. **Enable Logging**: Always enable execution logging for audit trails
2. **Use Hierarchy Selectively**: Filter hierarchy in Excel for easier viewing
3. **AI Analysis Budget**: Use AI on critical graphs only to manage costs
4. **Encrypt Patterns**: Encrypt patterns before deploying to production
5. **Regular Updates**: Keep execution logs for trend analysis

## Support

For issues or questions:
1. Check execution log for parsing errors
2. Review [test_updated_parser.py](test_updated_parser.py) for examples
3. Consult [ai_script_analyzer.py](services/ai_script_analyzer.py) for AI prompts

## Credits

- **FAWN Parser**: Inspiration for hierarchy tracking and encryption
- **CodebaseIntelligence**: Base framework for multi-platform parsing
- **Azure OpenAI**: AI-powered component analysis

---

**Version**: 2.0 (FAWN Enhanced)
**Last Updated**: November 2, 2025
**Status**: Production Ready ✅
