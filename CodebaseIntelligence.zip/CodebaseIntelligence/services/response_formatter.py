"""
Structured Response Formatter
==============================
Formats RAG responses in clean, system-by-system structure

Output Format:
SYSTEM: Ab Initio + Autosys
Graph: customer_load.graph
Autosys Job: job_customer_load
Schedule: Daily at 2AM
Logic: Aggregates customer data from staging to dimension
Confidence: 0.93
Sources: [autosys_job.jil, customer_load.graph]

SYSTEM: Hadoop (Spark)
Script: customer_load_spark.py
Logic: Same aggregation using PySpark
Confidence: 0.87
Sources: [customer_load_spark.py]

COMPARISON:
- Both aggregate customer data
- Ab Initio uses lookup file join
- Hadoop uses Spark broadcast join
- Logic equivalence: 95%
"""

from typing import List, Dict, Any, Optional
from loguru import logger


class ResponseFormatter:
    """
    Format RAG responses with clean system-by-system structure
    """

    def __init__(self):
        """Initialize formatter"""
        self.system_display_names = {
            "abinitio": "Ab Initio",
            "hadoop": "Hadoop",
            "databricks": "Databricks",
            "autosys": "Autosys",
            "abinitio_autosys": "Ab Initio + Autosys",
        }

    def format_response(
        self,
        results_by_collection: Dict[str, List[Dict]],
        query: str,
        intent: str = "search",
        llm_analysis: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Format multi-collection search results into structured response

        Args:
            results_by_collection: Dict of collection_name -> results list
            query: Original user query
            intent: Query intent (lineage, comparison, logic, etc.)
            llm_analysis: Optional LLM-generated analysis

        Returns:
            Dict with formatted response sections
        """
        # Group results by system
        system_results = self._group_by_system(results_by_collection)

        # Format each system section
        system_sections = []
        for system_name, results in system_results.items():
            section = self._format_system_section(system_name, results, intent)
            if section:
                system_sections.append(section)

        # Create comparison if multiple systems
        comparison = None
        if len(system_sections) > 1 and intent == "comparison":
            comparison = self._create_comparison(system_sections, llm_analysis)

        # Build structured response
        response = {
            "query": query,
            "intent": intent,
            "system_sections": system_sections,
            "comparison": comparison,
            "total_sources": sum(len(results) for results in results_by_collection.values()),
            "confidence": self._calculate_overall_confidence(results_by_collection),
        }

        # Generate formatted text
        response["formatted_text"] = self._generate_formatted_text(response)

        return response

    def _group_by_system(self, results_by_collection: Dict[str, List[Dict]]) -> Dict[str, List[Dict]]:
        """Group results by system (abinitio, hadoop, etc.)"""
        system_results = {}

        for collection_name, results in results_by_collection.items():
            # Extract system from collection name
            if "abinitio" in collection_name:
                system = "abinitio"
            elif "hadoop" in collection_name:
                system = "hadoop"
            elif "databricks" in collection_name:
                system = "databricks"
            elif "autosys" in collection_name:
                system = "autosys"
            elif "cross_system" in collection_name:
                system = "abinitio_autosys"  # Cross-system links
            else:
                system = "other"

            if system not in system_results:
                system_results[system] = []

            system_results[system].extend(results)

        return system_results

    def _format_system_section(
        self,
        system_name: str,
        results: List[Dict],
        intent: str
    ) -> Optional[Dict[str, Any]]:
        """Format section for a single system"""
        if not results:
            return None

        # Get display name
        display_name = self.system_display_names.get(system_name, system_name.title())

        # Extract key information from top results
        top_result = results[0] if results else {}
        metadata = top_result.get("metadata", {})
        content = top_result.get("content", "")

        # Build section based on system and intent
        section = {
            "system": display_name,
            "system_key": system_name,
            "confidence": top_result.get("score", 0.0),
            "sources": [],
            "details": {},
        }

        # Extract system-specific details
        if system_name == "abinitio":
            section["details"] = self._extract_abinitio_details(results)
        elif system_name == "hadoop":
            section["details"] = self._extract_hadoop_details(results)
        elif system_name == "databricks":
            section["details"] = self._extract_databricks_details(results)
        elif system_name == "autosys":
            section["details"] = self._extract_autosys_details(results)
        elif system_name == "abinitio_autosys":
            section["details"] = self._extract_cross_system_details(results)

        # Extract sources
        for result in results[:5]:  # Top 5 sources
            metadata = result.get("metadata", {})
            source = {
                "name": metadata.get("name", "Unknown"),
                "type": metadata.get("doc_type", "Unknown"),
                "confidence": result.get("score", 0.0),
            }
            section["sources"].append(source)

        return section

    def _extract_abinitio_details(self, results: List[Dict]) -> Dict[str, Any]:
        """Extract Ab Initio-specific details"""
        details = {}

        top_result = results[0] if results else {}
        metadata = top_result.get("metadata", {})
        content = top_result.get("content", "")

        # Extract graph information
        details["graph_name"] = metadata.get("graph_name", "N/A")
        details["component_count"] = metadata.get("component_count", 0)

        # Extract logic summary from content
        if "Logic:" in content:
            logic_start = content.find("Logic:") + 6
            logic_end = content.find("\n", logic_start)
            details["logic_summary"] = content[logic_start:logic_end].strip() if logic_end > logic_start else "N/A"

        return details

    def _extract_hadoop_details(self, results: List[Dict]) -> Dict[str, Any]:
        """Extract Hadoop-specific details"""
        details = {}

        top_result = results[0] if results else {}
        metadata = top_result.get("metadata", {})

        details["script_name"] = metadata.get("script_name", metadata.get("name", "N/A"))
        details["script_type"] = metadata.get("script_type", "N/A")
        details["workflow"] = metadata.get("workflow_name", "N/A")

        return details

    def _extract_databricks_details(self, results: List[Dict]) -> Dict[str, Any]:
        """Extract Databricks-specific details"""
        details = {}

        top_result = results[0] if results else {}
        metadata = top_result.get("metadata", {})

        details["notebook_name"] = metadata.get("name", "N/A")
        details["notebook_type"] = metadata.get("doc_type", "N/A")

        return details

    def _extract_autosys_details(self, results: List[Dict]) -> Dict[str, Any]:
        """Extract Autosys-specific details"""
        details = {}

        top_result = results[0] if results else {}
        metadata = top_result.get("metadata", {})
        content = top_result.get("content", "")

        details["job_name"] = metadata.get("job_name", "N/A")
        details["job_type"] = metadata.get("job_type", "CMD")

        # Extract schedule if present
        if "Schedule:" in content or "Trigger:" in content:
            for line in content.split("\n"):
                if "Schedule:" in line or "Trigger:" in line:
                    details["schedule"] = line.split(":", 1)[1].strip()
                    break

        return details

    def _extract_cross_system_details(self, results: List[Dict]) -> Dict[str, Any]:
        """Extract cross-system link details"""
        details = {}

        top_result = results[0] if results else {}
        metadata = top_result.get("metadata", {})
        content = top_result.get("content", "")

        details["autosys_job"] = metadata.get("autosys_job", "N/A")
        details["abinitio_graph"] = metadata.get("abinitio_graph", "N/A")
        details["link_type"] = metadata.get("link_type", "execution")

        # Extract execution flow summary
        if "FULL EXECUTION FLOW:" in content:
            flow_start = content.find("FULL EXECUTION FLOW:")
            details["execution_flow"] = content[flow_start:].strip()

        return details

    def _create_comparison(
        self,
        system_sections: List[Dict],
        llm_analysis: Optional[str] = None
    ) -> Dict[str, Any]:
        """Create comparison between systems"""
        comparison = {
            "systems_compared": [s["system"] for s in system_sections],
            "similarities": [],
            "differences": [],
            "equivalence_score": 0.0,
            "recommendation": "",
        }

        # If LLM analysis provided, use it
        if llm_analysis:
            comparison["analysis"] = llm_analysis
        else:
            # Basic comparison
            comparison["analysis"] = f"Comparing {len(system_sections)} systems: {', '.join(comparison['systems_compared'])}"

        # Calculate equivalence score (simple average of confidences)
        if system_sections:
            avg_confidence = sum(s["confidence"] for s in system_sections) / len(system_sections)
            comparison["equivalence_score"] = avg_confidence

        return comparison

    def _calculate_overall_confidence(self, results_by_collection: Dict[str, List[Dict]]) -> float:
        """Calculate overall confidence score"""
        all_scores = []

        for results in results_by_collection.values():
            for result in results[:3]:  # Top 3 per collection
                score = result.get("score", 0.0)
                if score > 0:
                    all_scores.append(score)

        if all_scores:
            return sum(all_scores) / len(all_scores)
        else:
            return 0.0

    def _generate_formatted_text(self, response: Dict[str, Any]) -> str:
        """Generate formatted text output"""
        lines = []

        # Header
        lines.append("=" * 80)
        lines.append(f"QUERY: {response['query']}")
        lines.append(f"INTENT: {response['intent'].upper()}")
        lines.append(f"CONFIDENCE: {response['confidence']:.2f}")
        lines.append("=" * 80)
        lines.append("")

        # System sections
        for section in response["system_sections"]:
            lines.append(f"SYSTEM: {section['system']}")
            lines.append("-" * 80)

            # Add details
            details = section["details"]
            for key, value in details.items():
                if value and value != "N/A":
                    key_display = key.replace("_", " ").title()
                    lines.append(f"{key_display}: {value}")

            lines.append(f"Confidence: {section['confidence']:.2f}")

            # Add sources
            if section["sources"]:
                lines.append("\nSources:")
                for src in section["sources"][:3]:  # Top 3
                    lines.append(f"  - {src['name']} ({src['type']}, score: {src['confidence']:.2f})")

            lines.append("")

        # Comparison section
        if response.get("comparison"):
            comp = response["comparison"]
            lines.append("COMPARISON:")
            lines.append("-" * 80)
            lines.append(f"Systems: {', '.join(comp['systems_compared'])}")
            lines.append(f"Equivalence Score: {comp['equivalence_score']:.2f}")

            if "analysis" in comp:
                lines.append(f"\nAnalysis:")
                lines.append(comp["analysis"])

            lines.append("")

        # Footer
        lines.append("=" * 80)
        lines.append(f"Total Sources: {response['total_sources']}")

        return "\n".join(lines)

    def format_for_streamlit(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """Format response optimized for Streamlit display"""
        return {
            "header": {
                "query": response["query"],
                "intent": response["intent"],
                "confidence": response["confidence"],
            },
            "systems": [
                {
                    "name": section["system"],
                    "details": section["details"],
                    "confidence": section["confidence"],
                    "sources": section["sources"],
                }
                for section in response["system_sections"]
            ],
            "comparison": response.get("comparison"),
            "metadata": {
                "total_sources": response["total_sources"],
                "formatted_text": response["formatted_text"],
            }
        }


# Convenience function
def create_response_formatter() -> ResponseFormatter:
    """Create response formatter instance"""
    return ResponseFormatter()


# Example usage
if __name__ == "__main__":
    # Mock results for testing
    mock_results = {
        "abinitio_collection": [
            {
                "content": "Graph: customer_load.graph\nLogic: Aggregates customer data from staging to dimension",
                "metadata": {
                    "graph_name": "customer_load.graph",
                    "component_count": 50,
                },
                "score": 0.93,
            }
        ],
        "hadoop_collection": [
            {
                "content": "Spark Script: customer_load_spark.py\nLogic: Aggregates customer data using PySpark",
                "metadata": {
                    "script_name": "customer_load_spark.py",
                    "script_type": "pyspark",
                },
                "score": 0.87,
            }
        ],
    }

    formatter = ResponseFormatter()

    response = formatter.format_response(
        results_by_collection=mock_results,
        query="Compare customer load processing",
        intent="comparison"
    )

    print(response["formatted_text"])
