"""
Logic Comparator - AI-Powered Cross-System Logic Comparison
============================================================
Compares transformation logic across different systems using Azure OpenAI

Capabilities:
- Detect equivalent logic patterns
- Identify implementation differences
- Calculate logic similarity scores
- Generate migration recommendations
"""

import os
from typing import List, Dict, Any, Optional
from loguru import logger

try:
    from openai import AzureOpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False


class LogicComparator:
    """
    Compare logic across systems using AI

    Examples:
    - Ab Initio Transform vs Spark DataFrame operation
    - Hive SQL vs Ab Initio DML
    - Pig Latin vs PySpark
    """

    def __init__(self, api_key: Optional[str] = None):
        """Initialize logic comparator"""
        self.llm = None
        self.enabled = False

        if OPENAI_AVAILABLE and (api_key or os.getenv("AZURE_OPENAI_API_KEY")):
            try:
                self.llm = AzureOpenAI(
                    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                    api_key=api_key or os.getenv("AZURE_OPENAI_API_KEY"),
                    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
                )
                self.model_name = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4")
                self.enabled = True

                logger.info("✓ Logic Comparator initialized with Azure OpenAI")

            except Exception as e:
                logger.warning(f"Could not initialize Logic Comparator: {e}")
                self.enabled = False
        else:
            logger.info("Logic Comparator disabled (no Azure OpenAI)")

        self.system_prompt = self._create_system_prompt()

    def _create_system_prompt(self) -> str:
        """Create system prompt for logic comparison"""
        return """You are an expert ETL architect specializing in cross-platform logic comparison.

Your expertise spans:
- Ab Initio (Co>Operating System, GDE, transforms, DML)
- Hadoop (Hive, Pig, Spark - SQL, Python, Scala)
- Databricks (notebooks, Delta Lake, SQL)
- SQL variants (PostgreSQL, Oracle, Teradata, etc.)

When comparing logic across systems, analyze:
1. **Semantic Equivalence**: Do they accomplish the same business goal?
2. **Implementation Differences**: How do they differ technically?
3. **Data Structures**: Schema, types, transformations
4. **Performance Characteristics**: Which is more efficient and why?
5. **Migration Complexity**: How hard to migrate from one to another?
6. **Business Impact**: Any functional differences?

Provide analysis in JSON format:
{
  "are_equivalent": true/false,
  "similarity_score": 0.0-1.0,
  "semantic_summary": "Both aggregate customer data by date...",
  "similarities": ["both use", "both aggregate", ...],
  "differences": [
    {
      "aspect": "join_type",
      "system1": "lookup file join",
      "system2": "broadcast join",
      "impact": "Performance difference in large datasets"
    }
  ],
  "migration_recommendation": {
    "difficulty": "low|medium|high",
    "effort_estimate": "X days",
    "key_challenges": ["challenge 1", ...],
    "approach": "Recommended migration steps..."
  },
  "performance_comparison": {
    "system1_advantage": "Faster for...",
    "system2_advantage": "Better for...",
    "recommendation": "Use system1 for..."
  }
}

Be precise, technical, and business-aware."""

    def compare_logic(
        self,
        system1: Dict[str, Any],
        system2: Dict[str, Any],
        context: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Compare logic between two systems

        Args:
            system1: Dict with 'system_name', 'code', 'description', 'metadata'
            system2: Dict with same structure
            context: Optional context about the comparison

        Returns:
            Dict with comparison results
        """
        if not self.enabled:
            return self._fallback_comparison(system1, system2)

        user_prompt = f"""Compare the following two ETL logic implementations:

**SYSTEM 1: {system1['system_name']}**
Name: {system1.get('name', 'N/A')}
Description: {system1.get('description', 'N/A')}

Code/Logic:
```
{system1.get('code', system1.get('logic', 'N/A'))[:1500]}
```

**SYSTEM 2: {system2['system_name']}**
Name: {system2.get('name', 'N/A')}
Description: {system2.get('description', 'N/A')}

Code/Logic:
```
{system2.get('code', system2.get('logic', 'N/A'))[:1500]}
```
"""

        if context:
            user_prompt += f"\n\n**Context**: {context}"

        user_prompt += "\n\nProvide detailed comparison in JSON format."

        try:
            response = self.llm.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.1,
                max_tokens=2000,
            )

            content = response.choices[0].message.content

            # Parse JSON
            import json
            if "```json" in content:
                json_str = content.split("```json")[1].split("```")[0].strip()
            elif "```" in content:
                json_str = content.split("```")[1].split("```")[0].strip()
            else:
                json_str = content.strip()

            comparison = json.loads(json_str)

            logger.info(f"✓ Compared {system1['system_name']} vs {system2['system_name']}")
            logger.info(f"  Similarity: {comparison.get('similarity_score', 0):.2f}")

            return comparison

        except Exception as e:
            logger.error(f"Logic comparison error: {e}")
            return self._fallback_comparison(system1, system2)

    def _fallback_comparison(self, system1: Dict[str, Any], system2: Dict[str, Any]) -> Dict[str, Any]:
        """Fallback comparison without LLM"""
        return {
            "are_equivalent": False,
            "similarity_score": 0.5,
            "semantic_summary": f"Comparing {system1['system_name']} and {system2['system_name']} (AI analysis unavailable)",
            "similarities": ["Both are ETL processes"],
            "differences": [
                {
                    "aspect": "platform",
                    "system1": system1['system_name'],
                    "system2": system2['system_name'],
                    "impact": "Different platforms, manual comparison needed"
                }
            ],
            "migration_recommendation": {
                "difficulty": "unknown",
                "effort_estimate": "Requires detailed analysis",
                "key_challenges": ["Manual logic review needed"],
                "approach": "Enable Azure OpenAI for AI-powered comparison"
            }
        }

    def compare_batch(
        self,
        comparisons: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Compare multiple logic pairs

        Args:
            comparisons: List of dicts with 'system1', 'system2', 'context'

        Returns:
            List of comparison results
        """
        results = []

        for i, comp in enumerate(comparisons, 1):
            logger.info(f"Comparing {i}/{len(comparisons)}...")

            result = self.compare_logic(
                system1=comp["system1"],
                system2=comp["system2"],
                context=comp.get("context")
            )

            results.append(result)

        return results

    def detect_migration_opportunities(
        self,
        source_system: str,
        target_system: str,
        source_logic_list: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Analyze migration opportunities from source to target

        Args:
            source_system: Source system name (e.g., "Ab Initio")
            target_system: Target system name (e.g., "Databricks")
            source_logic_list: List of logic components from source

        Returns:
            Dict with migration analysis
        """
        if not self.enabled:
            return {
                "feasibility": "unknown",
                "total_components": len(source_logic_list),
                "recommendation": "Enable Azure OpenAI for migration analysis"
            }

        # Sample components for analysis (avoid hitting token limits)
        sample_size = min(10, len(source_logic_list))
        samples = source_logic_list[:sample_size]

        user_prompt = f"""Analyze migration feasibility from {source_system} to {target_system}.

Source components ({sample_size} of {len(source_logic_list)}):
"""

        for i, comp in enumerate(samples, 1):
            user_prompt += f"\n{i}. {comp.get('name', 'N/A')}: {comp.get('description', 'N/A')[:200]}"

        user_prompt += f"""

Provide migration analysis in JSON:
{{
  "feasibility": "low|medium|high",
  "estimated_effort": "X weeks/months",
  "components_easy": X,
  "components_medium": X,
  "components_hard": X,
  "key_challenges": ["challenge 1", ...],
  "recommended_approach": "Step by step migration plan",
  "automation_potential": "percentage of components that can be auto-migrated",
  "manual_work_required": "What needs manual work",
  "risk_assessment": "Migration risks and mitigation"
}}"""

        try:
            response = self.llm.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.1,
                max_tokens=1500,
            )

            content = response.choices[0].message.content

            import json
            if "```json" in content:
                json_str = content.split("```json")[1].split("```")[0].strip()
            else:
                json_str = content

            analysis = json.loads(json_str)
            analysis["total_components"] = len(source_logic_list)
            analysis["sample_size"] = sample_size

            return analysis

        except Exception as e:
            logger.error(f"Migration analysis error: {e}")
            return {
                "feasibility": "unknown",
                "error": str(e),
                "total_components": len(source_logic_list)
            }


# Convenience function
def create_logic_comparator() -> LogicComparator:
    """Create logic comparator instance"""
    return LogicComparator()


# Example usage
if __name__ == "__main__":
    comparator = LogicComparator()

    # Mock comparison
    system1 = {
        "system_name": "Ab Initio",
        "name": "customer_load.graph",
        "description": "Loads customer data from staging to dimension",
        "code": """
        TRANSFORM
          lookup_join(customer_staging, customer_master, customer_id)
          aggregate(customer_id, sum(amount))
          filter(status == 'ACTIVE')
        """
    }

    system2 = {
        "system_name": "Hadoop Spark",
        "name": "customer_load_spark.py",
        "description": "Loads customer data using PySpark",
        "code": """
        df_staging = spark.read.table("customer_staging")
        df_master = spark.read.table("customer_master")

        df_joined = df_staging.join(broadcast(df_master), "customer_id", "inner")
        df_agg = df_joined.groupBy("customer_id").agg(sum("amount"))
        df_filtered = df_agg.filter(col("status") == "ACTIVE")
        """
    }

    if comparator.enabled:
        result = comparator.compare_logic(system1, system2)

        print("\nLogic Comparison Result:")
        print(f"Equivalent: {result.get('are_equivalent')}")
        print(f"Similarity: {result.get('similarity_score', 0):.2f}")
        print(f"\nSummary: {result.get('semantic_summary')}")
    else:
        print("Logic Comparator not enabled (Azure OpenAI required)")
