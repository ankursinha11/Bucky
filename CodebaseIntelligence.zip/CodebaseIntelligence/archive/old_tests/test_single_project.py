"""
Test script to index just ONE Ab Initio project
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from parsers.abinitio.deep_parser_multi_repo import DeepAbInitioParserMultiRepo
from services.deep_indexer import DeepIndexer

# Choose which project to test
PROJECT = "blade"  # or "pub_escan"

print(f"\n{'='*70}")
print(f"🧪 TEST: Indexing ONLY the '{PROJECT}' project")
print(f"{'='*70}\n")

# Parse just one project folder
project_path = f"D:\\Abinito\\ab_initio_workspace\\{PROJECT}"
print(f"📂 Project path: {project_path}")

# Parse
parser = DeepAbInitioParserMultiRepo(use_ai=False)
result = parser.parse_directory(project_path)

# Show stats
print(f"\n📊 Parsing Results:")
print(f"   Repositories: {len(result.get('repositories', []))}")
print(f"   Workflows: {len(result.get('workflow_flows', []))}")
print(f"   Scripts: {len(result.get('script_logics', []))}")

# Index
print(f"\n{'='*70}")
print(f"📤 Indexing to vector DB...")
print(f"{'='*70}\n")

indexer = DeepIndexer(vector_db_path="./outputs/vector_db_test")
counts = indexer.index_deep_analysis(
    repository=result.get("repository"),
    repositories=result.get("repositories"),
    workflow_flows=result.get("workflow_flows", []),
    script_logics=result.get("script_logics", []),
)

print(f"\n✅ Test complete!")
print(f"   Check logs above for duplicate patterns")
