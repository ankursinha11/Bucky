#!/usr/bin/env python3
"""
Quick verification script to check if files are fixed
"""

import sys
from pathlib import Path

def verify_files():
    """Verify all fixes are in place"""

    print("=" * 70)
    print("  Verification Script - Checking All Fixes")
    print("=" * 70)

    issues = []

    # Check 1: ProcessType.AUTOSYS_JOB exists
    print("\n1. Checking ProcessType enum...")
    try:
        from core.models.process import ProcessType
        if hasattr(ProcessType, 'AUTOSYS_JOB'):
            print("   ✓ ProcessType.AUTOSYS_JOB exists")
        else:
            print("   ✗ ProcessType.AUTOSYS_JOB missing!")
            issues.append("ProcessType.AUTOSYS_JOB not found")
    except Exception as e:
        print(f"   ✗ Error: {e}")
        issues.append(f"ProcessType import error: {e}")

    # Check 2: SystemType.AUTOSYS exists
    print("\n2. Checking SystemType enum...")
    try:
        from core.models.process import SystemType
        if hasattr(SystemType, 'AUTOSYS'):
            print("   ✓ SystemType.AUTOSYS exists")
        else:
            print("   ✗ SystemType.AUTOSYS missing!")
            issues.append("SystemType.AUTOSYS not found")
    except Exception as e:
        print(f"   ✗ Error: {e}")
        issues.append(f"SystemType import error: {e}")

    # Check 3: No .add() calls in deep_parser_multi_repo.py
    print("\n3. Checking deep_parser_multi_repo.py...")
    multi_repo_file = Path("parsers/abinitio/deep_parser_multi_repo.py")
    if multi_repo_file.exists():
        content = multi_repo_file.read_text()
        if '.add(' in content and 'components' in content:
            print("   ✗ Still has .add() calls!")
            issues.append("deep_parser_multi_repo.py still uses .add()")
        else:
            print("   ✓ No .add() calls found")
    else:
        print("   ✗ File not found!")
        issues.append("deep_parser_multi_repo.py not found")

    # Check 4: No set() for components
    print("\n4. Checking for set() usage...")
    if multi_repo_file.exists():
        content = multi_repo_file.read_text()
        if '"components": set()' in content or "'components': set()" in content:
            print("   ✗ Still uses set() for components!")
            issues.append("deep_parser_multi_repo.py still uses set()")
        else:
            print("   ✓ No set() usage for components")

    # Check 5: Autosys parser uses correct enums
    print("\n5. Checking Autosys parser...")
    autosys_file = Path("parsers/autosys/parser.py")
    if autosys_file.exists():
        content = autosys_file.read_text()
        if 'ProcessType.JOB' in content:
            print("   ✗ Still has ProcessType.JOB!")
            issues.append("Autosys parser still uses ProcessType.JOB")
        elif 'ProcessType.AUTOSYS_JOB' in content:
            print("   ✓ Uses ProcessType.AUTOSYS_JOB")
        else:
            print("   ? ProcessType usage unclear")
    else:
        print("   ✗ File not found!")
        issues.append("parser.py not found")

    # Check 6: ActionType has Ab Initio specific values
    print("\n6. Checking ActionType enum...")
    try:
        from core.models.workflow_flow import ActionType
        missing = []
        for attr in ['INPUT', 'OUTPUT', 'TRANSFORM', 'JOIN', 'FILTER', 'AGGREGATE', 'SORT', 'LOOKUP', 'SCRIPT']:
            if not hasattr(ActionType, attr):
                missing.append(attr)

        if missing:
            print(f"   ✗ Missing ActionType attributes: {', '.join(missing)}")
            issues.append(f"ActionType missing: {', '.join(missing)}")
        else:
            print("   ✓ All ActionType attributes exist")
    except Exception as e:
        print(f"   ✗ Error: {e}")
        issues.append(f"ActionType import error: {e}")

    # Summary
    print("\n" + "=" * 70)
    if issues:
        print("❌ ISSUES FOUND:")
        for issue in issues:
            print(f"   - {issue}")
        print("\n⚠️  Your files may not be up to date!")
        print("   Copy the updated files from Mac to Windows")
        print("=" * 70)
        return False
    else:
        print("✅ ALL CHECKS PASSED!")
        print("   Your files are up to date and should work correctly")
        print("=" * 70)
        return True

if __name__ == "__main__":
    success = verify_files()
    sys.exit(0 if success else 1)
