## 🚀 EMI-RAG Implementation Guide

### Overview

This guide shows how to implement the complete multi-system RAG architecture for your CodebaseIntelligence project.

---

## Quick Start (30 minutes)

### Step 1: Index Your Parsed Code (10 min)

```python
from services.multi_collection_indexer import MultiCollectionIndexer
from parsers.abinitio.parser import AbInitioParser
from parsers.autosys.parser import AutosysParser
from parsers.hadoop.deep_parser_multi_repo import DeepHadoopParser

# Initialize multi-collection indexer
indexer = MultiCollectionIndexer(vector_db_path="./outputs/vector_db")

# Parse Ab Initio
abinitio_parser = AbInitioParser()
abinitio_result = abinitio_parser.parse_directory("/path/to/abinitio/graphs")

# Index Ab Initio
indexer.index_abinitio(
    processes=abinitio_result["processes"],
    components=abinitio_result["components"],
    raw_mp_data=abinitio_result.get("raw_mp_data")
)

# Parse Autosys
autosys_parser = AutosysParser()
autosys_result = autosys_parser.parse_directory("/path/to/autosys/jils")

# Index Autosys
indexer.index_autosys(jobs=autosys_result["jobs"])

# Create cross-system links (Autosys → Ab Initio)
indexer.index_cross_system_links(
    autosys_jobs=autosys_result["jobs"],
    abinitio_processes=abinitio_result["processes"]
)

# Parse Hadoop (if available)
hadoop_parser = DeepHadoopParser()
hadoop_result = hadoop_parser.parse_repository("/path/to/hadoop/code")

# Index Hadoop
indexer.index_hadoop(
    repositories=hadoop_result["repositories"],
    workflow_flows=hadoop_result["workflow_flows"],
    script_logics=hadoop_result["script_logics"]
)

print("✅ Indexing complete!")
print(f"Collections created: {list(indexer.collections.keys())}")
```

### Step 2: Query Your Codebase (5 min)

```python
from services.query_router import QueryRouter
from services.multi_collection_indexer import MultiCollectionIndexer

# Initialize
router = QueryRouter()
indexer = MultiCollectionIndexer()

# Ask a question
query = "Compare Hadoop and Ab Initio for customer load processing"

# Route query
routing = router.route_query(query)
print(f"Routing to: {routing['collections']}")

# Search relevant collections
results = indexer.search_multi_collection(
    query=query,
    collections=routing["collections"],
    top_k=5
)

# View results
for coll_name, coll_results in results.items():
    print(f"\n{coll_name}:")
    for result in coll_results[:2]:  # Show top 2
        print(f"  - {result.get('title', 'N/A')}")
        print(f"    {result.get('content', '')[:100]}...")
```

### Step 3: Use Azure OpenAI for Better Embeddings (Optional, 5 min)

```python
from services.azure_embeddings import AzureEmbeddingsClient

# Initialize Azure embeddings (requires API key in env)
embedding_client = AzureEmbeddingsClient()

# Check if using Azure or local fallback
print(f"Embedding mode: {embedding_client.mode}")
print(f"Dimensions: {embedding_client.embedding_dim}")

# Generate embedding for query
query = "customer data processing logic"
embedding = embedding_client.embed_text(query)

print(f"Embedding vector length: {len(embedding)}")
# Azure: 3072 dimensions
# Local: 384 dimensions
```

### Step 4: Full RAG with Structured Responses (10 min)

```python
from services.rag_chatbot_integrated import CodebaseRAGChatbot

# Initialize chatbot with Azure OpenAI
chatbot = CodebaseRAGChatbot(
    use_local_search=True,
    vector_db_path="./outputs/vector_db"
)

# Ask questions
response = chatbot.query("What does the customer_load graph do?")

print(f"Answer: {response['answer']}")
print(f"\nSources ({len(response['sources'])}):")
for source in response['sources'][:3]:
    print(f"  - {source['metadata'].get('name', 'N/A')}")
```

---

## Architecture Components

### 1. Multi-Collection Indexer

**Purpose**: Separate collections for clean retrieval

**Benefits**:
- ✅ Faster, more accurate search
- ✅ Better metadata filtering
- ✅ Easy cross-system comparison
- ✅ Scalable to new systems

**Collections**:
```
abinitio_collection/      ← Ab Initio graphs, components
hadoop_collection/        ← Hive, Pig, Spark scripts
databricks_collection/    ← Notebooks, jobs
autosys_collection/       ← Job schedules, triggers
cross_system_links/       ← Autosys→AbInitio flows
documents_collection/     ← PDFs, reports, docs
```

**Usage**:
```python
from services.multi_collection_indexer import MultiCollectionIndexer

indexer = MultiCollectionIndexer()

# Index different systems
indexer.index_abinitio(processes, components)
indexer.index_hadoop(repositories, workflows, scripts)
indexer.index_autosys(jobs)

# Create cross-links
indexer.index_cross_system_links(autosys_jobs, abinitio_processes)
```

### 2. Azure OpenAI Embeddings

**Purpose**: High-quality semantic embeddings

**Benefits**:
- ✅ 3072 dimensions (vs 384 for sentence-transformers)
- ✅ Better semantic understanding
- ✅ Multilingual support
- ✅ Consistent with Azure OpenAI LLM

**Fallback**: Automatically falls back to free sentence-transformers if no API key

**Usage**:
```python
from services.azure_embeddings import create_embedding_client

# Try Azure, fallback to local if needed
client = create_embedding_client(
    use_azure=True,
    fallback_to_local=True
)

# Batch embed documents
embeddings = client.embed_batch(["text1", "text2", ...])

# Single embedding
embedding = client.embed_text("query text")
```

### 3. Query Router

**Purpose**: Intelligent routing to relevant collections

**How it works**:
1. Analyzes query with Azure OpenAI
2. Detects systems mentioned (explicit or implicit)
3. Classifies intent (lineage, comparison, logic, etc.)
4. Routes to appropriate collections
5. Falls back to rules if no LLM available

**Query Intent Types**:
- `lineage`: Trace data flow → Search ALL collections
- `comparison`: Compare systems → Multiple collections
- `logic`: Transformation logic → Specific system
- `schedule`: Job timing → Autosys + cross-links
- `dependency`: Job dependencies → Autosys
- `search`: General search → Default collections

**Usage**:
```python
from services.query_router import QueryRouter

router = QueryRouter()

# Route a query
routing = router.route_query("Compare Hadoop and Ab Initio for customer load")

# Returns:
# {
#   "collections": ["hadoop_collection", "abinitio_collection"],
#   "intent": "comparison",
#   "systems": ["hadoop", "abinitio"],
#   "search_strategy": "multi_system",
#   "reasoning": "..."
# }
```

### 4. Cross-System Linker

**Purpose**: Connect Autosys jobs to Ab Initio graphs

**Example Link Document**:
```
CROSS-SYSTEM EXECUTION FLOW
============================

AUTOSYS JOB: job_customer_load
Dependencies: job_staging_complete
Schedule: Daily 2AM

EXECUTES AB INITIO GRAPH: customer_load.graph
Components: 150
Logic: Aggregates customer data from staging to dimension

FULL EXECUTION FLOW:
1. Autosys job 'job_customer_load' triggers
2. Executes command: runpset.ksh -P customer_load.pset
3. Runs Ab Initio graph: customer_load.graph
4. Graph processes 150 components
```

**Benefits**:
- ✅ End-to-end visibility
- ✅ Schedule + logic in one place
- ✅ Dependency tracking across systems

**Usage**:
```python
# Automatically created during indexing
indexer.index_cross_system_links(autosys_jobs, abinitio_processes)

# Query cross-system flows
router = QueryRouter()
routing = router.route_query("When does customer_load graph run?")
# Routes to: autosys_collection + cross_system_links
```

---

## Environment Setup

### Required Environment Variables

```bash
# Azure OpenAI (for embeddings and LLM)
export AZURE_OPENAI_API_KEY="your-api-key"
export AZURE_OPENAI_ENDPOINT="https://your-endpoint.openai.azure.com/"
export AZURE_OPENAI_API_VERSION="2024-02-15-preview"
export AZURE_OPENAI_DEPLOYMENT_NAME="gpt-4"  # For chatbot
export AZURE_OPENAI_FAST_DEPLOYMENT="gpt-35-turbo"  # For query routing (cheaper/faster)
```

### Dependencies

```bash
pip install chromadb sentence-transformers openai loguru pandas openpyxl pyyaml
```

---

## Complete Example Workflow

### Parse → Index → Query Pipeline

```python
"""
Complete EMI-RAG Pipeline Example
===================================
"""

from pathlib import Path
from services.multi_collection_indexer import MultiCollectionIndexer
from services.query_router import QueryRouter
from services.azure_embeddings import create_embedding_client
from parsers.abinitio.parser import AbInitioParser
from parsers.autosys.parser import AutosysParser

def main():
    # ========================================
    # STEP 1: Parse Codebases
    # ========================================
    print("📂 Step 1: Parsing codebases...")

    # Ab Initio
    abinitio_parser = AbInitioParser(enable_filter=False)
    abinitio_result = abinitio_parser.parse_directory(
        "/path/to/abinitio/graphs"
    )
    print(f"  ✓ Ab Initio: {len(abinitio_result['processes'])} graphs")

    # Autosys
    autosys_parser = AutosysParser()
    autosys_result = autosys_parser.parse_directory(
        "/path/to/autosys/jils"
    )
    print(f"  ✓ Autosys: {len(autosys_result['components'])} jobs")

    # ========================================
    # STEP 2: Initialize Embeddings
    # ========================================
    print("\n🔢 Step 2: Initializing embeddings...")

    embedding_client = create_embedding_client(
        use_azure=True,
        fallback_to_local=True
    )
    print(f"  ✓ Embedding mode: {embedding_client.mode}")
    print(f"  ✓ Dimensions: {embedding_client.embedding_dim}")

    # ========================================
    # STEP 3: Index into Collections
    # ========================================
    print("\n📊 Step 3: Indexing into collections...")

    indexer = MultiCollectionIndexer()

    # Index Ab Initio
    abinitio_stats = indexer.index_abinitio(
        processes=abinitio_result["processes"],
        components=abinitio_result["components"]
    )
    print(f"  ✓ Ab Initio: {abinitio_stats['total']} documents")

    # Index Autosys
    autosys_stats = indexer.index_autosys(
        jobs=[c.__dict__ for c in autosys_result["components"]]  # Convert to dicts
    )
    print(f"  ✓ Autosys: {autosys_stats['jobs']} documents")

    # Create cross-system links
    link_stats = indexer.index_cross_system_links(
        autosys_jobs=[c.__dict__ for c in autosys_result["components"]],
        abinitio_processes=abinitio_result["processes"]
    )
    print(f"  ✓ Cross-links: {link_stats['links']} links created")

    # ========================================
    # STEP 4: Query with Routing
    # ========================================
    print("\n🔍 Step 4: Testing queries...")

    router = QueryRouter()

    queries = [
        "What does the customer_load graph do?",
        "Compare Hadoop and Ab Initio for customer processing",
        "When does job_customer_etl run?",
        "Show lineage for customer_id column",
    ]

    for query in queries:
        print(f"\n  Query: {query}")

        # Route query
        routing = router.route_query(query)
        print(f"  → Collections: {routing['collections']}")
        print(f"  → Intent: {routing['intent']}")

        # Search
        results = indexer.search_multi_collection(
            query=query,
            collections=routing["collections"],
            top_k=3
        )

        # Show results
        for coll_name, coll_results in results.items():
            if coll_results:
                print(f"\n  {coll_name}:")
                for result in coll_results[:1]:  # Top 1
                    print(f"    - {result.get('title', 'N/A')}")

    # ========================================
    # STEP 5: Stats
    # ========================================
    print("\n📈 Step 5: Collection stats...")

    stats = indexer.get_stats()
    for coll_name, coll_stats in stats.items():
        doc_count = coll_stats.get("total_documents", "N/A")
        print(f"  {coll_name}: {doc_count} documents")

    print("\n✅ Pipeline complete!")


if __name__ == "__main__":
    main()
```

---

## Example Queries & Expected Routing

### Query 1: "Compare Hadoop and Ab Initio for customer load"

**Routing**:
```json
{
  "collections": ["hadoop_collection", "abinitio_collection"],
  "intent": "comparison",
  "systems": ["hadoop", "abinitio"],
  "search_strategy": "multi_system"
}
```

**Expected Results**:
- From `hadoop_collection`: Spark/Hive scripts for customer processing
- From `abinitio_collection`: Ab Initio graphs for customer processing
- LLM compares logic and identifies similarities/differences

### Query 2: "When does job_customer_load run?"

**Routing**:
```json
{
  "collections": ["autosys_collection", "cross_system_links"],
  "intent": "schedule",
  "systems": ["autosys"],
  "search_strategy": "cross_system"
}
```

**Expected Results**:
- From `autosys_collection`: Job schedule, trigger time
- From `cross_system_links`: Full execution flow including Ab Initio graph

### Query 3: "Show lineage for customer_id across all systems"

**Routing**:
```json
{
  "collections": ["abinitio_collection", "hadoop_collection", "databricks_collection", "cross_system_links"],
  "intent": "lineage",
  "systems": ["abinitio", "hadoop", "databricks"],
  "search_strategy": "all"
}
```

**Expected Results**:
- Traces `customer_id` through all systems
- Shows transformations at each step
- Cross-system lineage map

---

## Next Steps

### Phase 1 Complete ✅
- [x] Multi-Collection Indexer
- [x] Azure OpenAI Embeddings
- [x] Query Router
- [x] Cross-System Linker

### Phase 2: Enhanced Features 🚧
- [ ] Structured Response Formatter
- [ ] Logic Comparator (cross-system)
- [ ] Document Indexing (PDFs, reports)
- [ ] Versioning & Incremental Updates

### Phase 3: Production Ready 📦
- [ ] REST API wrapper
- [ ] Web UI (Streamlit)
- [ ] Lineage visualization
- [ ] Performance optimization
- [ ] Monitoring & logging

---

## Troubleshooting

### Issue: "No results found"

**Solution**: Check if collections are indexed
```python
stats = indexer.get_stats()
for coll, info in stats.items():
    print(f"{coll}: {info.get('total_documents', 0)} docs")
```

### Issue: "Azure OpenAI not working"

**Solution**: Check environment variables
```python
import os
print(f"API Key set: {bool(os.getenv('AZURE_OPENAI_API_KEY'))}")
print(f"Endpoint set: {bool(os.getenv('AZURE_OPENAI_ENDPOINT'))}")
```

Fallback to local embeddings:
```python
client = create_embedding_client(use_azure=False)
```

### Issue: "Query routing always uses rules"

**Solution**: Ensure Azure OpenAI is configured for routing
```python
from services.query_router import QueryRouter

router = QueryRouter()
print(f"Router enabled: {router.enabled}")
print(f"Model: {router.model_name if router.enabled else 'N/A'}")
```

---

## Performance Tips

1. **Batch Indexing**: Index in batches for large codebases
2. **Azure Embeddings**: Use batching (100 texts per call)
3. **Collection Selection**: Be specific with collections to reduce search time
4. **Caching**: Results can be cached for repeated queries

---

**Status**: Implementation-ready
**Estimated Setup Time**: 30-60 minutes
**Full Pipeline Runtime**: 5-10 minutes for typical codebase

🚀 **Ready to transform your codebase intelligence!**
