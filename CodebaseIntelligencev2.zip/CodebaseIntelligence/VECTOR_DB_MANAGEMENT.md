# Vector Database Management Guide

**Quick guide to managing, clearing, and re-indexing your vector database**

---

## TL;DR - Quick Commands

```bash
# Check current status
python manage_vector_db.py --status

# Clear everything and start fresh
python manage_vector_db.py --clear-all

# Re-index everything from scratch (interactive)
python manage_vector_db.py --reindex-all

# Or use the interactive menu
./reindex.sh
```

---

## Understanding the Vector Database

### What is it?
The vector database stores **embeddings** (numerical representations) of your code for semantic search. It uses **ChromaDB** and stores data in:

```
./outputs/vector_db/
├── abinitio_collection/
├── hadoop_collection/
├── databricks_collection/
├── autosys_collection/
├── cross_system_links/
└── documents_collection/
```

### When to Re-Index?

**You should re-index when:**
- ✅ Your codebase has changed significantly
- ✅ You've added new Ab Initio graphs or Autosys jobs
- ✅ You want to update with new FAWN parser features
- ✅ Vector DB is corrupted or showing errors
- ✅ You've changed embedding models (Azure → local or vice versa)

**You DON'T need to re-index for:**
- ❌ Changing AI model (GPT-4 → GPT-3.5)
- ❌ Changing temperature or top-k settings
- ❌ Minor code tweaks (wait for batch update)

---

## Option 1: Interactive Menu (Easiest)

```bash
./reindex.sh
```

**Menu options:**
1. Show database status
2. Clear ALL and re-index
3. Clear specific collection
4. Re-index Ab Initio only
5. Re-index Autosys only
6. Re-index Documents only
7. Export statistics
8. Exit

**Example flow:**
```
Select option (1-8): 1

📊 Vector Database Status
===========================================================
📁 Database Path: ./outputs/vector_db
💾 Total Size: 127.45 MB

📈 Collection Statistics:
------------------------------------------------------------

  Abinitio:
    Documents: 2,891

  Hadoop:
    Documents: 156

  Autosys:
    Documents: 432

  Cross System Links:
    Documents: 89

------------------------------------------------------------
📊 Total Documents: 3,568
```

---

## Option 2: Command Line (Power Users)

### Check Status

```bash
python manage_vector_db.py --status
```

Shows:
- Database location
- Total size (MB)
- Documents per collection
- Any errors

### Clear Everything

```bash
# Interactive (asks for confirmation)
python manage_vector_db.py --clear-all

# Auto-confirm (dangerous!)
python manage_vector_db.py --clear-all --yes
```

**What it does:**
- Deletes `./outputs/vector_db/` directory
- Removes ALL indexed data
- Requires re-indexing to use again

### Clear Specific Collection

```bash
# Clear just Ab Initio
python manage_vector_db.py --clear abinitio

# Clear just Autosys
python manage_vector_db.py --clear autosys

# Clear documents
python manage_vector_db.py --clear documents
```

**Available collections:**
- `abinitio`
- `hadoop`
- `databricks`
- `autosys`
- `links` (cross-system links)
- `documents`

### Re-Index Everything

```bash
# Interactive (prompts for paths)
python manage_vector_db.py --reindex-all
```

**You'll be prompted for:**
- Ab Initio directory path (or skip)
- Autosys directory path (or skip)
- Documents directory path (or skip)

**Example:**
```
Ab Initio directory path (or skip): /path/to/abinitio
Autosys directory path (or skip): /path/to/autosys
Documents directory path (or skip): skip

📋 Step 1: Clearing existing database...
✓ Vector database cleared

📋 Step 2: Initializing fresh indexer...
✓ Indexer initialized

📋 Indexing Ab Initio...
   ✓ Indexed 245 graphs
   ✓ Indexed 2,289 components

📋 Indexing Autosys...
   ✓ Indexed 432 jobs

✓ Re-indexing Complete!
```

### Re-Index Specific System

```bash
# Re-index Ab Initio
python manage_vector_db.py --reindex abinitio --path /path/to/abinitio

# Re-index Autosys
python manage_vector_db.py --reindex autosys --path /path/to/autosys

# Re-index Documents
python manage_vector_db.py --reindex documents --path /path/to/docs
```

### Export Statistics

```bash
python manage_vector_db.py --export-stats
```

Creates `vector_db_stats.json` with:
```json
{
  "abinitio_collection": {
    "total_documents": 2891,
    ...
  },
  "hadoop_collection": {
    "total_documents": 156,
    ...
  }
}
```

---

## Option 3: Python API

### In Your Scripts

```python
from manage_vector_db import VectorDBManager

# Create manager
manager = VectorDBManager(vector_db_path="./outputs/vector_db")

# Check status
manager.show_status()

# Clear all
manager.clear_all(confirm=True)  # Skip confirmation prompt

# Clear specific collection
manager.clear_collection("abinitio")

# Re-index
manager.reindex_abinitio("/path/to/abinitio")
manager.reindex_autosys("/path/to/autosys")
manager.reindex_documents("/path/to/docs")

# Export stats
manager.export_stats("my_stats.json")
```

---

## Common Scenarios

### Scenario 1: Fresh Start (New Project)

```bash
# 1. Clear everything
python manage_vector_db.py --clear-all --yes

# 2. Re-index all systems
python manage_vector_db.py --reindex-all
# Follow prompts to enter paths

# 3. Verify
python manage_vector_db.py --status
```

### Scenario 2: Updated Ab Initio Code

```bash
# 1. Clear just Ab Initio collection
python manage_vector_db.py --clear abinitio

# 2. Re-index Ab Initio
python manage_vector_db.py --reindex abinitio --path /path/to/abinitio

# 3. Verify
python manage_vector_db.py --status
```

### Scenario 3: Added New Documents

```bash
# 1. Don't clear - just add new docs
python manage_vector_db.py --reindex documents --path /path/to/new_docs

# New docs are added to existing collection
```

### Scenario 4: Migration (Switching Embedding Models)

```bash
# When switching from local → Azure or vice versa

# 1. Update .env with new embedding settings
export AZURE_OPENAI_EMBEDDING_MODEL="text-embedding-3-large"

# 2. Clear everything (embeddings are incompatible)
python manage_vector_db.py --clear-all --yes

# 3. Re-index with new embeddings
python manage_vector_db.py --reindex-all
```

### Scenario 5: Corrupted Database

```bash
# Symptoms: Search errors, missing results, ChromaDB errors

# Solution: Fresh re-index
python manage_vector_db.py --clear-all --yes
python manage_vector_db.py --reindex-all
```

---

## Performance Tips

### Large Codebases

**If you have 10,000+ files:**

1. **Index in batches:**
   ```bash
   # Index by subdirectory
   python manage_vector_db.py --reindex abinitio --path /path/subset1
   python manage_vector_db.py --reindex abinitio --path /path/subset2
   ```

2. **Use local embeddings** (faster than Azure):
   ```python
   # In services/azure_embeddings.py
   client = create_embedding_client(use_azure=False)
   ```

3. **Reduce chunk size** for documents:
   ```python
   # In parsers/documents/document_parser.py
   parser = DocumentParser(chunk_size=1000)  # Default: 2000
   ```

### Time Estimates

| Collection | Files | Time (Azure) | Time (Local) |
|------------|-------|--------------|--------------|
| Ab Initio | 100 graphs | ~2 min | ~30 sec |
| Ab Initio | 1000 graphs | ~20 min | ~5 min |
| Autosys | 500 jobs | ~3 min | ~45 sec |
| Documents | 100 PDFs | ~10 min | ~3 min |

**Azure is slower** but **better quality** (3072D vs 384D)

---

## Troubleshooting

### Error: "Collection not found"

**Cause:** Collection hasn't been created yet

**Solution:**
```bash
python manage_vector_db.py --reindex-all
```

### Error: "ChromaDB sqlite3 error"

**Cause:** Database corruption

**Solution:**
```bash
# Delete and recreate
rm -rf ./outputs/vector_db
python manage_vector_db.py --reindex-all
```

### Error: "Permission denied"

**Cause:** Wrong file permissions

**Solution:**
```bash
chmod -R 755 ./outputs/vector_db
```

### Warning: "0 documents indexed"

**Cause:** Parser found no valid files

**Solution:**
- Check directory path is correct
- Verify file extensions (.mp for Ab Initio, .jil for Autosys)
- Check parser logs for errors

---

## Best Practices

### 1. Regular Backups

```bash
# Backup vector database
tar -czf vector_db_backup_$(date +%Y%m%d).tar.gz ./outputs/vector_db

# Restore
tar -xzf vector_db_backup_20251102.tar.gz
```

### 2. Incremental Updates

```bash
# For small changes, just re-index changed collection
python manage_vector_db.py --clear abinitio
python manage_vector_db.py --reindex abinitio --path /path/to/abinitio
```

### 3. Monitor Size

```bash
# Check database size
du -sh ./outputs/vector_db

# If too large, consider:
# - Reducing chunk_size
# - Using lower-dimension embeddings
# - Clearing old/unused collections
```

### 4. Version Control

**DON'T** commit `./outputs/vector_db/` to git

Add to `.gitignore`:
```
outputs/vector_db/
*.chroma
```

**DO** commit your source code and parsers

### 5. Testing Before Production

```bash
# Test with small dataset first
python manage_vector_db.py --reindex abinitio --path /path/to/sample

# Verify in STAG
streamlit run stag_app.py

# If good, do full re-index
```

---

## Integration with STAG

### In STAG UI

**After re-indexing:**
1. Launch STAG: `./start_stag.sh`
2. Click "Refresh Stats" in sidebar
3. New document counts appear
4. New files are immediately searchable

**On-the-fly indexing:**
- Use STAG's file upload widget
- No need to manually re-index
- Great for ad-hoc file additions

---

## FAQ

**Q: Do I need to restart STAG after re-indexing?**
A: No! Just click "Refresh Stats" in the sidebar.

**Q: Can I re-index while STAG is running?**
A: Yes, but click "Refresh Stats" afterward.

**Q: How often should I re-index?**
A: Weekly for active development, monthly for stable codebases.

**Q: Does re-indexing delete my chat history?**
A: No, chat history is separate and not affected.

**Q: Can I run multiple re-indexes in parallel?**
A: No, run them sequentially to avoid conflicts.

**Q: What if re-indexing fails midway?**
A: Clear and restart: `python manage_vector_db.py --clear-all --yes`

---

## Summary Commands

```bash
# Check what you have
python manage_vector_db.py --status

# Full reset (nuclear option)
python manage_vector_db.py --clear-all --yes
python manage_vector_db.py --reindex-all

# Incremental update (safest)
python manage_vector_db.py --clear abinitio
python manage_vector_db.py --reindex abinitio --path /path

# Interactive menu (easiest)
./reindex.sh
```

---

**Last Updated:** November 2, 2025
**Version:** 1.0
