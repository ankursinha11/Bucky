"""
Pattern File Encryption Utility (FAWN Enhancement)
====================================================
Optional security feature to encrypt pattern YAML files

Usage:
    # Encrypt pattern file
    python pattern_encryption.py encrypt patterns.yaml

    # Use encrypted patterns in parser (automatic decryption)
    patterns = load_encrypted_patterns()
"""

import os
import yaml
import getpass
from pathlib import Path
from typing import Dict, Optional
from loguru import logger

try:
    from cryptography.fernet import Fernet
    ENCRYPTION_AVAILABLE = True
except ImportError:
    ENCRYPTION_AVAILABLE = False
    logger.warning("cryptography package not available - encryption features disabled")


class PatternEncryption:
    """Handle encryption/decryption of pattern files"""

    def __init__(self):
        """Initialize encryption handler"""
        self.script_dir = Path(__file__).parent
        self.secure_dir = self.script_dir / ".ip"
        self.encrypted_file = self.secure_dir / "pttyml"
        self.key_file = self.secure_dir / ".sk"
        self.config_dir = self.script_dir / "config"

    def generate_key(self) -> bytes:
        """Generate encryption key"""
        if not ENCRYPTION_AVAILABLE:
            raise ImportError("cryptography package required for encryption")

        key = Fernet.generate_key()
        return key

    def encrypt_pattern_file(self, pattern_file: str, output_encrypted: bool = True):
        """
        Encrypt pattern YAML file

        Args:
            pattern_file: Path to patterns.yaml file
            output_encrypted: If True, save encrypted file (default: True)

        Returns:
            Encrypted data bytes
        """
        if not ENCRYPTION_AVAILABLE:
            raise ImportError("cryptography package required for encryption")

        # Generate key if not exists
        if not self.key_file.exists():
            self.secure_dir.mkdir(exist_ok=True, parents=True)
            key = self.generate_key()

            with open(self.key_file, 'wb') as kf:
                kf.write(key)

            logger.info(f"✓ Generated encryption key: {self.key_file}")
        else:
            with open(self.key_file, 'rb') as kf:
                key = kf.read()

        # Read pattern file
        with open(pattern_file, 'rb') as pf:
            pattern_data = pf.read()

        # Encrypt
        cipher = Fernet(key)
        encrypted_data = cipher.encrypt(pattern_data)

        # Save encrypted file
        if output_encrypted:
            self.secure_dir.mkdir(exist_ok=True, parents=True)
            with open(self.encrypted_file, 'wb') as ef:
                ef.write(encrypted_data)

            logger.info(f"✓ Encrypted pattern file saved: {self.encrypted_file}")

        return encrypted_data

    def decrypt_pattern_file(self, cleanup: bool = True) -> Dict:
        """
        Decrypt pattern file and load patterns

        Args:
            cleanup: If True, delete decrypted temp file after loading (default: True)

        Returns:
            Dictionary of patterns
        """
        if not ENCRYPTION_AVAILABLE:
            raise ImportError("cryptography package required for decryption")

        # Check files exist
        if not self.encrypted_file.exists():
            raise FileNotFoundError(f"Encrypted pattern file not found: {self.encrypted_file}")

        if not self.key_file.exists():
            raise FileNotFoundError(f"Encryption key not found: {self.key_file}")

        # Read key
        with open(self.key_file, 'rb') as kf:
            key = kf.read()

        cipher = Fernet(key)

        # Read encrypted data
        with open(self.encrypted_file, 'rb') as ef:
            encrypted_data = ef.read()

        # Decrypt
        try:
            decrypted_data = cipher.decrypt(encrypted_data)
        except Exception as e:
            raise ValueError(f"Decryption failed: {e}")

        # Save to temp file for user
        self.config_dir.mkdir(exist_ok=True, parents=True)
        username = getpass.getuser()
        decrypted_file = self.config_dir / f"{username}_pattern.yaml"

        with open(decrypted_file, 'wb') as df:
            df.write(decrypted_data)

        # Load patterns
        with open(decrypted_file, 'r') as file:
            patterns = yaml.safe_load(file)

        # Cleanup temp file
        if cleanup:
            os.remove(decrypted_file)
            logger.debug(f"Temporary decrypted file cleaned up: {decrypted_file}")

        return patterns


def load_encrypted_patterns(fallback_to_plain: bool = True) -> Optional[Dict]:
    """
    Load patterns from encrypted file, with fallback to plain YAML

    Args:
        fallback_to_plain: If True and encryption not available, load from patterns.yaml

    Returns:
        Dictionary of patterns or None
    """
    encryptor = PatternEncryption()

    # Try encrypted first
    if ENCRYPTION_AVAILABLE and encryptor.encrypted_file.exists():
        try:
            patterns = encryptor.decrypt_pattern_file()
            logger.info("✓ Loaded patterns from encrypted file")
            return patterns
        except Exception as e:
            logger.warning(f"Failed to load encrypted patterns: {e}")

    # Fallback to plain YAML
    if fallback_to_plain:
        pattern_file = Path(__file__).parent / "patterns.yaml"
        if pattern_file.exists():
            with open(pattern_file, 'r') as f:
                patterns = yaml.safe_load(f)
            logger.info("✓ Loaded patterns from plain YAML file")
            return patterns

    logger.error("No pattern file found (encrypted or plain)")
    return None


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage:")
        print("  Encrypt: python pattern_encryption.py encrypt <pattern_file.yaml>")
        print("  Decrypt: python pattern_encryption.py decrypt")
        sys.exit(1)

    command = sys.argv[1].lower()
    encryptor = PatternEncryption()

    if command == "encrypt":
        if len(sys.argv) < 3:
            print("Error: Please provide pattern file path")
            sys.exit(1)

        pattern_file = sys.argv[2]
        encryptor.encrypt_pattern_file(pattern_file)
        print(f"✓ Pattern file encrypted successfully")
        print(f"  Encrypted file: {encryptor.encrypted_file}")
        print(f"  Key file: {encryptor.key_file}")

    elif command == "decrypt":
        patterns = encryptor.decrypt_pattern_file(cleanup=False)
        print(f"✓ Pattern file decrypted successfully")
        print(f"  Patterns loaded: {len(patterns)} keys")

    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
