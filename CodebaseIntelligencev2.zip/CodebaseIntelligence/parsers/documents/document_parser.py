"""
Document Parser - Parse PDFs, Excel, DOCX for Business Documentation
====================================================================
Extracts text and structure from business documents, FAWN reports, technical docs

Supported Formats:
- PDF (PyPDF2, pdfplumber)
- Excel (.xlsx, .xls)
- Word (.docx)
- Text (.txt, .md)

Integrates with MultiCollectionIndexer for documents_collection
"""

import os
from typing import List, Dict, Any, Optional
from pathlib import Path
from loguru import logger
from datetime import datetime

# PDF parsing
try:
    import pdfplumber
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False
    logger.warning("pdfplumber not available. Install: pip install pdfplumber")

# Excel parsing
try:
    import pandas as pd
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False
    logger.warning("pandas not available. Install: pip install pandas openpyxl")

# Word parsing
try:
    import docx
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False
    logger.warning("python-docx not available. Install: pip install python-docx")


class DocumentParser:
    """
    Parse business documents for indexing

    Features:
    - Multi-format support (PDF, Excel, Word, Text)
    - Metadata extraction (title, author, date)
    - Section detection
    - Table extraction from PDFs/Excel
    - Smart chunking for long documents
    """

    def __init__(self, chunk_size: int = 2000, chunk_overlap: int = 200):
        """
        Initialize document parser

        Args:
            chunk_size: Max characters per chunk
            chunk_overlap: Overlap between chunks for context
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

        logger.info("✓ DocumentParser initialized")
        logger.info(f"  PDF support: {PDF_AVAILABLE}")
        logger.info(f"  Excel support: {EXCEL_AVAILABLE}")
        logger.info(f"  DOCX support: {DOCX_AVAILABLE}")

    def parse_directory(self, directory: str, recursive: bool = True) -> List[Dict[str, Any]]:
        """
        Parse all documents in directory

        Args:
            directory: Path to directory
            recursive: Search subdirectories

        Returns:
            List of parsed document dicts
        """
        documents = []
        path = Path(directory)

        # Supported extensions
        extensions = {'.pdf', '.xlsx', '.xls', '.docx', '.txt', '.md'}

        # Find files
        if recursive:
            files = [f for f in path.rglob('*') if f.suffix.lower() in extensions]
        else:
            files = [f for f in path.glob('*') if f.suffix.lower() in extensions]

        logger.info(f"Found {len(files)} documents in {directory}")

        # Parse each file
        for file_path in files:
            try:
                doc = self.parse_file(str(file_path))
                if doc:
                    documents.append(doc)
            except Exception as e:
                logger.error(f"Error parsing {file_path.name}: {e}")

        logger.info(f"✓ Parsed {len(documents)} documents")
        return documents

    def parse_file(self, file_path: str) -> Optional[Dict[str, Any]]:
        """
        Parse single file based on extension

        Returns:
            Dict with: title, content, chunks, metadata, file_type
        """
        path = Path(file_path)
        extension = path.suffix.lower()

        logger.debug(f"Parsing {path.name}...")

        if extension == '.pdf':
            return self._parse_pdf(file_path)
        elif extension in {'.xlsx', '.xls'}:
            return self._parse_excel(file_path)
        elif extension == '.docx':
            return self._parse_docx(file_path)
        elif extension in {'.txt', '.md'}:
            return self._parse_text(file_path)
        else:
            logger.warning(f"Unsupported format: {extension}")
            return None

    def _parse_pdf(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Parse PDF file"""
        if not PDF_AVAILABLE:
            logger.warning(f"Cannot parse PDF {file_path} - pdfplumber not installed")
            return None

        path = Path(file_path)
        content = ""
        tables = []
        metadata = {}

        try:
            with pdfplumber.open(file_path) as pdf:
                # Extract metadata
                metadata = {
                    'pages': len(pdf.pages),
                    'author': pdf.metadata.get('Author', 'Unknown'),
                    'creator': pdf.metadata.get('Creator', 'Unknown'),
                    'creation_date': pdf.metadata.get('CreationDate', 'Unknown'),
                }

                # Extract text from all pages
                for i, page in enumerate(pdf.pages, 1):
                    page_text = page.extract_text()
                    if page_text:
                        content += f"\n\n--- Page {i} ---\n\n{page_text}"

                    # Extract tables
                    page_tables = page.extract_tables()
                    if page_tables:
                        for table in page_tables:
                            tables.append({
                                'page': i,
                                'data': table
                            })

        except Exception as e:
            logger.error(f"PDF parsing error for {path.name}: {e}")
            return None

        # Create chunks
        chunks = self._chunk_text(content)

        return {
            'title': path.stem,
            'file_name': path.name,
            'file_path': str(path.absolute()),
            'file_type': 'pdf',
            'content': content.strip(),
            'chunks': chunks,
            'tables': tables,
            'metadata': metadata,
            'parsed_at': datetime.now().isoformat(),
        }

    def _parse_excel(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Parse Excel file"""
        if not EXCEL_AVAILABLE:
            logger.warning(f"Cannot parse Excel {file_path} - pandas not installed")
            return None

        path = Path(file_path)
        content = ""
        sheets_data = {}

        try:
            # Read all sheets
            excel_file = pd.ExcelFile(file_path)

            for sheet_name in excel_file.sheet_names:
                df = pd.read_excel(file_path, sheet_name=sheet_name)

                # Convert to text
                sheet_text = f"\n\n=== Sheet: {sheet_name} ===\n\n"
                sheet_text += df.to_string(index=False)
                content += sheet_text

                # Store structured data
                sheets_data[sheet_name] = {
                    'rows': len(df),
                    'columns': list(df.columns),
                    'sample': df.head(5).to_dict('records'),
                }

        except Exception as e:
            logger.error(f"Excel parsing error for {path.name}: {e}")
            return None

        # Create chunks
        chunks = self._chunk_text(content)

        return {
            'title': path.stem,
            'file_name': path.name,
            'file_path': str(path.absolute()),
            'file_type': 'excel',
            'content': content.strip(),
            'chunks': chunks,
            'sheets': sheets_data,
            'metadata': {
                'sheet_count': len(excel_file.sheet_names),
                'sheet_names': excel_file.sheet_names,
            },
            'parsed_at': datetime.now().isoformat(),
        }

    def _parse_docx(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Parse Word DOCX file"""
        if not DOCX_AVAILABLE:
            logger.warning(f"Cannot parse DOCX {file_path} - python-docx not installed")
            return None

        path = Path(file_path)
        content = ""

        try:
            doc = docx.Document(file_path)

            # Extract paragraphs
            for para in doc.paragraphs:
                if para.text.strip():
                    content += para.text + "\n\n"

            # Extract tables
            tables = []
            for table in doc.tables:
                table_data = []
                for row in table.rows:
                    table_data.append([cell.text for cell in row.cells])
                tables.append(table_data)

                # Add table to content
                content += "\n[TABLE]\n"
                for row in table_data:
                    content += " | ".join(row) + "\n"
                content += "\n"

        except Exception as e:
            logger.error(f"DOCX parsing error for {path.name}: {e}")
            return None

        # Create chunks
        chunks = self._chunk_text(content)

        return {
            'title': path.stem,
            'file_name': path.name,
            'file_path': str(path.absolute()),
            'file_type': 'docx',
            'content': content.strip(),
            'chunks': chunks,
            'metadata': {
                'paragraphs': len(doc.paragraphs),
                'tables': len(doc.tables),
            },
            'parsed_at': datetime.now().isoformat(),
        }

    def _parse_text(self, file_path: str) -> Dict[str, Any]:
        """Parse plain text or markdown file"""
        path = Path(file_path)

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            logger.error(f"Text parsing error for {path.name}: {e}")
            return None

        # Create chunks
        chunks = self._chunk_text(content)

        return {
            'title': path.stem,
            'file_name': path.name,
            'file_path': str(path.absolute()),
            'file_type': 'text' if path.suffix == '.txt' else 'markdown',
            'content': content.strip(),
            'chunks': chunks,
            'metadata': {
                'lines': len(content.split('\n')),
                'characters': len(content),
            },
            'parsed_at': datetime.now().isoformat(),
        }

    def _chunk_text(self, text: str) -> List[Dict[str, Any]]:
        """
        Split text into overlapping chunks

        Returns:
            List of dicts with: chunk_id, text, start_pos, end_pos
        """
        if not text or len(text) <= self.chunk_size:
            return [{'chunk_id': 0, 'text': text, 'start_pos': 0, 'end_pos': len(text)}]

        chunks = []
        start = 0
        chunk_id = 0

        while start < len(text):
            end = start + self.chunk_size

            # Try to break at sentence boundary
            if end < len(text):
                # Look for period, newline, or other break
                for boundary in ['. ', '.\n', '\n\n', '\n']:
                    pos = text.rfind(boundary, start, end)
                    if pos != -1:
                        end = pos + len(boundary)
                        break

            chunk_text = text[start:end].strip()

            if chunk_text:
                chunks.append({
                    'chunk_id': chunk_id,
                    'text': chunk_text,
                    'start_pos': start,
                    'end_pos': end,
                })
                chunk_id += 1

            # Move start position (with overlap)
            start = end - self.chunk_overlap

        return chunks

    def index_documents(self, documents: List[Dict[str, Any]], indexer) -> Dict[str, Any]:
        """
        Index parsed documents using MultiCollectionIndexer

        Args:
            documents: List of parsed documents from parse_directory()
            indexer: MultiCollectionIndexer instance

        Returns:
            Indexing stats
        """
        from services.multi_collection_indexer import MultiCollectionIndexer

        if not isinstance(indexer, MultiCollectionIndexer):
            raise ValueError("indexer must be MultiCollectionIndexer instance")

        logger.info(f"Indexing {len(documents)} documents...")

        # Use indexer's index_documents method
        stats = indexer.index_documents(documents)

        logger.info(f"✓ Indexed {stats.get('total', 0)} document chunks")

        return stats


# Convenience function
def create_document_parser(chunk_size: int = 2000) -> DocumentParser:
    """Create document parser with sensible defaults"""
    return DocumentParser(chunk_size=chunk_size)


# Example usage
if __name__ == "__main__":
    parser = DocumentParser()

    # Parse directory
    docs = parser.parse_directory("/path/to/documents", recursive=True)

    print(f"\nParsed {len(docs)} documents:")
    for doc in docs[:5]:  # Show first 5
        print(f"  - {doc['file_name']} ({doc['file_type']})")
        print(f"    Chunks: {len(doc['chunks'])}")
        print(f"    Content preview: {doc['content'][:100]}...")

    # Index documents (requires MultiCollectionIndexer)
    # from services.multi_collection_indexer import MultiCollectionIndexer
    # indexer = MultiCollectionIndexer()
    # stats = parser.index_documents(docs, indexer)
    # print(f"\nIndexed: {stats}")
