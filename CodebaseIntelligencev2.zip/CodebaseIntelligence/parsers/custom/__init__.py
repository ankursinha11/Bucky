"""Custom Documents Parser"""
from .parser import CustomDocumentParser

__all__ = ['CustomDocumentParser']
