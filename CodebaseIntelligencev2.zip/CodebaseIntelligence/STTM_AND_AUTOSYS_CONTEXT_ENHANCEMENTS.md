# STTM Indexing & Autosys Context Enhancements

**Date:** November 4, 2025
**Status:** ✅ **COMPLETE**

---

## Overview

Enhanced the system to address two critical features:

1. **STTM Auto-Indexing** - Automatically index STTM mappings to vector DB with separate collections per system
2. **Autosys Context for Ab Initio** - Use Autosys job definitions to enrich Ab Initio graph analysis

---

## Question 1: STTM Indexing to Vector DB

### Problem
**Before:** STTM mappings were generated on-the-fly but NOT indexed to vector DB

### Solution
✅ **Added 3 STTM Collections** (one per system):
- `sttm_abinitio_collection`
- `sttm_hadoop_collection`
- `sttm_databricks_collection`

✅ **Auto-Indexing** - STTM mappings are now automatically indexed after generation

### How It Works

**Step-by-Step Flow:**

```
1. User requests lineage for "customer_load.graph" (Ab Initio)
   ↓
2. LineageOrchestrator analyzes and creates STTM mappings
   ↓
3. Auto-indexes to sttm_abinitio_collection
   ↓
4. STTM mappings are now searchable via vector DB
   ↓
5. Future queries can leverage pre-computed STTM data
```

**Code Changes:**

### 1. Added STTM Collections

**File:** [services/multi_collection_indexer.py](services/multi_collection_indexer.py)

```python
def _initialize_collections(self):
    """Initialize all collections"""
    collection_names = [
        "abinitio_collection",
        "hadoop_collection",
        "databricks_collection",
        "autosys_collection",
        "cross_system_links",
        "documents_collection",
        # STTM collections (separate per system for targeted retrieval)
        "sttm_abinitio_collection",    # NEW!
        "sttm_hadoop_collection",      # NEW!
        "sttm_databricks_collection",  # NEW!
    ]
```

### 2. Created STTM Indexing Methods

**Method: `index_sttm_mappings()`**

```python
def index_sttm_mappings(
    self,
    sttm_mappings: List[Dict[str, Any]],
    system_type: str,
    entity_name: str
) -> Dict[str, int]:
    """
    Index STTM mappings to system-specific collection

    Example:
        indexer.index_sttm_mappings(
            sttm_mappings=mappings,
            system_type="abinitio",
            entity_name="customer_load.graph"
        )
        # Indexes to sttm_abinitio_collection
    """
```

**What Gets Indexed:**

Each STTM mapping becomes a searchable document:

```json
{
  "id": "customer_load_customer_id",
  "title": "STTM: customer_id (int) from customer_load.graph",
  "content": "Target Field: customer_id (int)\nSource Dataset: raw_customer_data\nSource Fields: cust_id\nTransformation Logic: CAST(cust_id AS INT)\n...",
  "metadata": {
    "doc_type": "sttm_mapping",
    "system": "abinitio",
    "entity_name": "customer_load.graph",
    "target_field": "customer_id",
    "target_data_type": "int",
    "source_dataset": "raw_customer_data",
    "source_fields": ["cust_id"],
    "transformation_logic": "CAST(cust_id AS INT)",
    "contains_pii": false,
    "is_primary_key": true,
    "field_type": "dimension",
    "confidence_score": 0.85
  }
}
```

### 3. Created STTM Search Method

**Method: `search_sttm()`**

```python
def search_sttm(
    self,
    query: str,
    system_type: Optional[str] = None,
    top_k: int = 5,
    filters: Optional[Dict[str, Any]] = None
) -> List[Dict[str, Any]]:
    """
    Search STTM mappings with advanced filtering

    Examples:
        # Search all systems
        results = indexer.search_sttm("customer_id")

        # Search only Ab Initio
        results = indexer.search_sttm("customer_id", system_type="abinitio")

        # Search with filters
        results = indexer.search_sttm(
            query="customer",
            filters={
                "contains_pii": True,
                "field_type": "dimension",
                "min_confidence": 0.8
            }
        )
    """
```

**Available Filters:**
- `contains_pii` - Filter by PII status
- `field_type` - dimension, fact, measure, attribute
- `is_primary_key` - Filter primary keys
- `min_confidence` - Minimum confidence score

### 4. Auto-Indexing Integration

**File:** [services/lineage/lineage_agents.py](services/lineage/lineage_agents.py)

**Updated LineageOrchestrator:**

```python
def analyze_lineage(...):
    # Step 2: Create STTM mappings
    sttm_mappings = self.mapping_agent.create_mappings(...)

    # Step 2.5: Auto-index STTM mappings (NEW!)
    if self.indexer and sttm_mappings:
        logger.info("Step 2.5: Auto-indexing STTM mappings...")
        sttm_dicts = [m.to_dict() for m in sttm_mappings]
        index_result = self.indexer.index_sttm_mappings(
            sttm_mappings=sttm_dicts,
            system_type=system_type,
            entity_name=entity_name
        )
        logger.info(f"✓ Indexed {index_result['total_mappings']} mappings")

    # Continue with remaining steps...
```

---

## Question 2: Autosys Context for Ab Initio

### Problem
**Before:** When analyzing Ab Initio graphs, the system only looked at the graph itself, missing crucial orchestration context from Autosys jobs

### Solution
✅ **Cross-System Context Enrichment** - Now fetches Autosys job definitions to understand:
- What Autosys job orchestrates this graph
- Job dependencies (what runs before/after)
- Scheduling and conditions
- Position in larger workflow
- AI-powered orchestration analysis

### How It Works

**Enhanced Parsing Flow:**

```
1. User requests lineage for "customer_load.graph" (Ab Initio)
   ↓
2. ParsingAgent parses the Ab Initio graph
   ↓
3. ParsingAgent searches autosys_collection for jobs referencing "customer_load.graph"
   ↓
4. Finds Autosys job: "CUST_LOAD_JOB"
   ↓
5. Extracts orchestration context:
   - Job type, command, owner, machine
   - Dependencies (predecessor jobs)
   - Scheduling (calendar, start times)
   - Flow context (box name, description)
   ↓
6. AI analyzes Autosys job definition
   ↓
7. Returns enriched Ab Initio data WITH Autosys context
```

**Code Changes:**

### 1. Enhanced ParsingAgent

**File:** [services/lineage/lineage_agents.py](services/lineage/lineage_agents.py)

**Updated Initialization:**

```python
class ParsingAgent:
    def __init__(
        self,
        abinitio_parser=None,
        autosys_parser=None,
        hadoop_parser=None,
        indexer=None,          # NEW! For cross-system search
        ai_analyzer=None       # NEW! For AI analysis
    ):
        self.indexer = indexer
        self.ai_analyzer = ai_analyzer
        logger.info("✓ Parsing Agent initialized with cross-system context support")
```

### 2. Autosys Context Fetching

**New Method: `_fetch_autosys_context()`**

```python
def _fetch_autosys_context(self, abinitio_graph_name: str) -> Dict[str, Any]:
    """
    Fetch Autosys job context for an Ab Initio graph

    Returns orchestration context:
    - orchestrating_job: Autosys job details
    - dependencies: Predecessor jobs
    - scheduling: Run calendar, start times
    - flow_context: Box, description, related jobs
    - ai_insights: AI analysis of orchestration
    """
    # Search autosys_collection for jobs referencing this graph
    autosys_results = self.indexer.search_multi_collection(
        query=abinitio_graph_name,
        collections=["autosys_collection"],
        top_k=5
    )

    # Extract orchestration context
    context = {
        "has_autosys_context": True,
        "orchestrating_job": { ... },
        "dependencies": { ... },
        "scheduling": { ... },
        "flow_context": { ... },
        "ai_insights": None
    }

    # Use AI to interpret Autosys context
    if self.ai_analyzer:
        ai_analysis = self.ai_analyzer.analyze_with_context(
            query=f"Analyze this Autosys job and explain its role in orchestrating the Ab Initio graph...",
            context=job_content
        )
        context["ai_insights"] = ai_analysis

    return context
```

### 3. Enriched Ab Initio Data

**Updated `_parse_abinitio_entity()`:**

```python
def _parse_abinitio_entity(self, entity_name: str, file_path: Optional[str]):
    """Parse Ab Initio graph with Autosys orchestration context"""

    # Parse Ab Initio graph
    result = self.abinitio_parser.parse_file(file_path)

    # Fetch Autosys context (NEW!)
    autosys_context = self._fetch_autosys_context(entity_name)

    return {
        "system": "abinitio",
        "entity_name": entity_name,
        "processes": result.get("processes", []),
        "components": result.get("components", []),
        "metadata": result,
        "autosys_context": autosys_context  # ← ENRICHED!
    }
```

---

## Example: Complete Flow

### Scenario: Analyzing "customer_load.graph"

**1. User Query:**
```
"Trace lineage for customer_load.graph"
```

**2. System Response:**

```
💭 Analyzing query...
💭 Intent detected: LINEAGE

📋 Task Plan:
1. Parse Ab Initio entity: customer_load.graph
2. Create STTM mappings
3. Auto-index STTM to vector DB
4. Build 3-level lineage
5. Format result

⚙️ Task 1/5: Parsing Ab Initio entity...
🤖 Using ParsingAgent...
  → Parsing customer_load.graph
  → Fetching Autosys context...
  → Found Autosys job: CUST_LOAD_JOB
  → Job dependencies: EXTRACT_CUST_DATA, VALIDATE_CUST
  → Scheduling: Daily at 02:00 AM
  → AI analysis: "This job orchestrates customer data loading..."
✅ Parsing complete with Autosys context

⚙️ Task 2/5: Creating STTM mappings...
🤖 Using MappingAgent...
✅ Created 247 STTM mappings

⚙️ Task 2.5: Auto-indexing STTM mappings...
  → Indexing to sttm_abinitio_collection
✅ Indexed 247 mappings

[... continues ...]

💡 Answer:
## Ab Initio Lineage Analysis

**Entity:** customer_load.graph
**System:** Ab Initio

### Autosys Orchestration Context:
**Orchestrating Job:** CUST_LOAD_JOB
- **Type:** command
- **Owner:** etl_user
- **Machine:** prod_etl_server
- **Dependencies:**
  - EXTRACT_CUST_DATA (must complete first)
  - VALIDATE_CUST (must complete first)
- **Scheduling:** Daily at 02:00 AM (WEEKDAY_CALENDAR)
- **Flow Context:** Part of CUSTOMER_ETL_BOX workflow

**AI Insights:**
"This Autosys job orchestrates the nightly customer data load process. It depends on two upstream jobs: raw data extraction and validation. The job runs daily on weekdays at 2 AM, ensuring fresh customer data is available for morning business operations. It's part of a larger customer ETL workflow managed by the CUSTOMER_ETL_BOX."

### STTM Mappings:
Found 247 field mappings

1. **customer_id** (int)
   - Sources: cust_id
   - Logic: CAST(cust_id AS INT)
   - PII: No | PK: Yes

[... more mappings ...]
```

---

## Benefits

### STTM Indexing Benefits

✅ **Fast Lookups** - STTM data searchable via vector DB
✅ **Reusability** - No need to regenerate for same entity
✅ **Cross-Entity Search** - Find similar transformations across systems
✅ **Advanced Filtering** - Filter by PII, field type, confidence
✅ **Persistent Storage** - STTM data preserved across sessions
✅ **Semantic Search** - Find mappings by natural language queries

**Example Searches:**
```python
# Find all PII fields in Ab Initio
results = indexer.search_sttm(
    query="personal information",
    system_type="abinitio",
    filters={"contains_pii": True}
)

# Find similar transformations across systems
results = indexer.search_sttm("customer aggregation")

# Find high-confidence primary keys
results = indexer.search_sttm(
    query="primary key",
    filters={"is_primary_key": True, "min_confidence": 0.9}
)
```

### Autosys Context Benefits

✅ **Complete Picture** - Understand not just WHAT the graph does, but WHEN and WHY
✅ **Dependency Awareness** - Know what must run before/after
✅ **Scheduling Context** - Understand timing constraints
✅ **Impact Analysis** - See ripple effects of changes
✅ **Migration Planning** - Replicate orchestration in target system
✅ **AI-Enhanced Understanding** - Natural language explanation of orchestration

**Example Context:**
```json
{
  "has_autosys_context": true,
  "orchestrating_job": {
    "name": "CUST_LOAD_JOB",
    "job_type": "command",
    "command": "run_graph customer_load.graph",
    "owner": "etl_user",
    "machine": "prod_etl_server"
  },
  "dependencies": {
    "predecessor_jobs": [
      "EXTRACT_CUST_DATA",
      "VALIDATE_CUST"
    ]
  },
  "scheduling": {
    "run_calendar": "WEEKDAY_CALENDAR",
    "start_times": ["02:00"]
  },
  "flow_context": {
    "box_name": "CUSTOMER_ETL_BOX",
    "description": "Customer data load and transformation",
    "total_related_jobs": 5
  },
  "ai_insights": "This job orchestrates nightly customer loads..."
}
```

---

## Technical Implementation Summary

### Files Modified

1. **services/multi_collection_indexer.py**
   - Added 3 STTM collections
   - Added `index_sttm_mappings()` method (~60 lines)
   - Added `search_sttm()` method (~40 lines)
   - Added `_create_sttm_document()` helper (~60 lines)
   - Added `_filter_sttm_results()` helper (~30 lines)
   - **Total: ~190 new lines**

2. **services/lineage/lineage_agents.py**
   - Enhanced ParsingAgent with indexer and ai_analyzer
   - Added `_fetch_autosys_context()` method (~80 lines)
   - Updated `_parse_abinitio_entity()` to include Autosys context
   - Added auto-indexing to LineageOrchestrator (~15 lines)
   - **Total: ~110 new lines**

3. **services/chat/chat_orchestrator.py**
   - Already configured correctly (no changes needed)

### Statistics

| Metric | Value |
|--------|-------|
| **New Collections** | 3 (STTM per system) |
| **New Methods** | 5 |
| **Lines of Code** | ~300 |
| **Systems Enhanced** | Ab Initio (Autosys context) |
| **Auto-Features** | 2 (STTM indexing, Autosys fetching) |

---

## Usage Examples

### Example 1: Search STTM Across All Systems

```python
from services.multi_collection_indexer import MultiCollectionIndexer

indexer = MultiCollectionIndexer()

# Search for customer-related fields
results = indexer.search_sttm("customer name email")

for result in results:
    print(f"Field: {result['metadata']['target_field']}")
    print(f"System: {result['metadata']['system']}")
    print(f"Entity: {result['metadata']['entity_name']}")
    print(f"PII: {result['metadata']['contains_pii']}")
    print("---")
```

### Example 2: Find PII Fields in Ab Initio

```python
pii_fields = indexer.search_sttm(
    query="",
    system_type="abinitio",
    filters={"contains_pii": True}
)

print(f"Found {len(pii_fields)} PII fields in Ab Initio:")
for field in pii_fields:
    print(f"- {field['metadata']['target_field']} in {field['metadata']['entity_name']}")
```

### Example 3: Analyze with Autosys Context

```python
from services.lineage.lineage_agents import LineageOrchestrator

orchestrator = LineageOrchestrator(
    ai_analyzer=ai_analyzer,
    indexer=indexer
)

result = orchestrator.analyze_lineage(
    system_type="abinitio",
    entity_name="customer_load.graph",
    file_path="/path/to/customer_load.mp"
)

# Access Autosys context
autosys_ctx = result.entity_metadata.get("autosys_context", {})

if autosys_ctx.get("has_autosys_context"):
    job = autosys_ctx["orchestrating_job"]
    print(f"Orchestrated by: {job['job_name']}")
    print(f"Dependencies: {autosys_ctx['dependencies']['predecessor_jobs']}")
    print(f"AI Insights: {autosys_ctx['ai_insights']}")
```

---

## Answers to Your Questions

### 1. Is STTM being indexed to vector DB?

**Answer:** ✅ **YES** (now)

- **Before:** STTM was generated on-demand but NOT indexed
- **After:** STTM is automatically indexed after generation
- **Separate Collections:** Yes, one per system:
  - `sttm_abinitio_collection`
  - `sttm_hadoop_collection`
  - `sttm_databricks_collection`

**How to Verify:**
```python
# Check if STTM collections exist
indexer = MultiCollectionIndexer()
stats = indexer.get_stats()

print("STTM Collections:")
print(f"  Ab Initio: {stats['sttm_abinitio_collection']['total_documents']} docs")
print(f"  Hadoop: {stats['sttm_hadoop_collection']['total_documents']} docs")
print(f"  Databricks: {stats['sttm_databricks_collection']['total_documents']} docs")
```

### 2. Does AI use Autosys context when analyzing Ab Initio?

**Answer:** ✅ **YES**

- **Autosys jobs are indexed once** to `autosys_collection`
- **When analyzing Ab Initio**, the ParsingAgent:
  1. Parses the Ab Initio graph
  2. Searches `autosys_collection` for jobs referencing this graph
  3. Extracts orchestration context (dependencies, scheduling, etc.)
  4. Uses AI to interpret the Autosys job definition
  5. Returns enriched data WITH Autosys context

**The AI now understands:**
- What triggers the Ab Initio graph
- What jobs must complete first
- When it's scheduled to run
- How it fits in the larger workflow

**How to Verify:**
```python
result = orchestrator.analyze_lineage(
    system_type="abinitio",
    entity_name="customer_load.graph",
    file_path="/path/to/customer_load.mp"
)

# Check if Autosys context was found
if result.entity_metadata.get("autosys_context", {}).get("has_autosys_context"):
    print("✅ Autosys context found and integrated!")
    print(result.entity_metadata["autosys_context"])
else:
    print("❌ No Autosys context found (job may not be in vector DB)")
```

---

## Future Enhancements

### STTM Enhancements
- Background indexing for large datasets
- STTM versioning and change tracking
- STTM comparison across versions
- Bulk STTM operations

### Autosys Context Enhancements
- Bidirectional dependencies (dependents)
- Full dependency tree visualization
- Scheduling conflict detection
- Cross-system orchestration mapping (Autosys → Airflow, etc.)

---

## Conclusion

Both features are now fully implemented and production-ready:

✅ **STTM Auto-Indexing**
- Separate collections per system
- Auto-indexed after generation
- Searchable with advanced filters
- Persistent across sessions

✅ **Autosys Context for Ab Initio**
- Automatic Autosys job lookup
- Complete orchestration context
- AI-powered analysis
- Enriched lineage understanding

**Your system now has enterprise-grade lineage tracking with full orchestration awareness!**

---

**Status:** ✅ PRODUCTION READY
**Last Updated:** November 4, 2025
**Version:** 1.0
