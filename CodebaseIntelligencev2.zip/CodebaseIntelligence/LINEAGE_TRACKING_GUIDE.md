# 🔗 Lineage Tracking & Cross-System Analysis - Complete Guide

**AI-Powered Column-Level Lineage with STTM Mappings**

---

## 🎯 Overview

The new **Lineage Tracking** feature in STAG provides:

✅ **Column-Level Mappings** - Source-Transform-Target Mapping (STTM) with full metadata
✅ **Cross-System Matching** - Find equivalent implementations across Ab Initio, Hadoop, Databricks
✅ **AI-Driven Analysis** - Semantic understanding of transformation logic
✅ **3-Level Lineage** - Flow, Logic, and Column-level tracing
✅ **PII Detection** - Automatic identification of sensitive data
✅ **Export Capabilities** - Excel, CSV, JSON exports

---

## 🚀 Quick Start

### 1. Launch STAG

```bash
streamlit run stag_app.py
```

### 2. Go to Lineage Tab

Click **"🔗 Lineage"** tab (5th tab)

### 3. Select Entity

- **System**: Choose Ab Initio, Hadoop, or Databricks
- **Entity Name**: Enter graph/workflow/notebook name
- **File Path** (optional): Provide file path or upload file
- **Target Systems**: Select systems to find equivalents in

### 4. Analyze

Click **"🔍 Analyze Lineage"** and wait for AI processing

### 5. Explore Results

View STTM mappings, cross-system matches, and 3-level lineage!

---

## 📋 STTM (Source-Transform-Target Mapping)

### What is STTM?

**STTM** is a detailed column-level mapping structure that captures:

| Field | Description |
|-------|-------------|
| **id** | Unique identifier |
| **partner** | Business partner/domain |
| **schema** | Database schema |
| **target_table_name** | Output table |
| **target_field_name** | Output column |
| **target_field_data_type** | Data type |
| **is_primary_key** | PK flag |
| **contains_pii** | PII detection |
| **field_type** | dimension, fact, measure, attribute |
| **field_depends_on** | Dependency chain |
| **processing_order** | Execution sequence |
| **pre_processing_rules** | Data quality rules |
| **source_field_names** | Input columns |
| **source_dataset_name** | Source table/file |
| **field_definition** | Business definition |
| **transformation_logic** | How field is derived |
| **example_1/2** | Sample values |
| **confidence_score** | AI confidence (0-1) |
| **ai_reasoning** | AI analysis notes |
| **system_type** | abinitio, hadoop, databricks |
| **graph_name** | Parent entity |
| **component_name** | Transformation component |

### Example STTM Entry

```json
{
  "id": "customer_load_reformat_customer_id_0",
  "partner": "retail",
  "schema": "customer_db",
  "target_table_name": "dim_customer",
  "target_field_name": "customer_id",
  "target_field_data_type": "integer",
  "is_primary_key": true,
  "contains_pii": false,
  "field_type": "dimension",
  "field_depends_on": ["in0.cust_id"],
  "processing_order": 100,
  "pre_processing_rules": ["NULL_CHECK", "TRIM_WHITESPACE"],
  "source_field_names": ["cust_id"],
  "source_dataset_name": "raw_customers",
  "field_definition": "Unique customer identifier",
  "transformation_logic": "CAST(TRIM(in0.cust_id) AS INTEGER)",
  "confidence_score": 0.92,
  "ai_reasoning": "Direct mapping with type conversion and trimming",
  "system_type": "abinitio",
  "graph_name": "customer_load.graph",
  "component_name": "reformat_customer"
}
```

---

## 🤖 AI Agents

The lineage system uses **5 specialized AI agents**:

### 1. **Parsing Agent**
- Parses Ab Initio graphs (.mp/.dml)
- Parses Hadoop workflows (.xml/.sh/.pig/.hql)
- Parses Databricks notebooks (.py/.ipynb)
- Extracts datasets, transformations, joins, filters

### 2. **Logic Agent**
- Interprets transformation logic using AI
- Infers business purpose
- Detects data quality rules
- Assesses complexity

### 3. **Mapping Agent**
- Creates STTM mappings
- Aligns source and target fields
- Extracts transformation logic
- Builds dependency chains

### 4. **Similarity Agent**
- Embeds transformations using vector embeddings
- Searches for similar logic across systems
- Calculates semantic similarity scores (0-1)
- Ranks matches by relevance

### 5. **Lineage Agent**
- Builds column-level lineage chains
- Traces data flow through transformations
- Generates 3-level lineage (flow, logic, column)
- Creates visualization-ready JSON

---

## 📊 Three-Level Lineage

### Level 1: Flow-Level Lineage

**Process-to-Process Mapping**

Shows which systems/entities are equivalent across platforms.

```json
{
  "source_system": "abinitio",
  "source_entity": "customer_load.graph",
  "target_system": "hadoop",
  "target_entity": "customer_hive_workflow",
  "similarity_score": 0.93,
  "relationship_type": "equivalent_implementation"
}
```

**Use Cases:**
- Identify redundant implementations
- Plan system migrations
- Understand cross-platform dependencies

---

### Level 2: Logic-Level Lineage

**Transformation-Level Comparison**

Shows which transformations are equivalent across systems.

```json
{
  "transformation_type": "reformat",
  "transformation_logic": "CAST, TRIM, NULL_CHECK",
  "field_count": 15,
  "source_fields": ["cust_id", "cust_name", "cust_email"],
  "target_fields": ["customer_id", "customer_name", "customer_email"],
  "complexity": "MEDIUM"
}
```

**Use Cases:**
- Compare transformation approaches
- Identify optimization opportunities
- Validate logic equivalence

---

### Level 3: Column-Level Lineage

**Field-Level Derivation**

Traces each column back to its source with full transformation details.

```json
{
  "column_name": "customer_total_spend",
  "target_table": "dim_customer",
  "source_columns": ["order_amount", "order_count"],
  "source_dataset": "fact_orders",
  "transformation_logic": "SUM(order_amount) GROUP BY customer_id",
  "dependencies": ["order_amount", "customer_id", "FUNCTION:SUM"],
  "data_type": "decimal",
  "contains_pii": false,
  "field_type": "measure",
  "processing_order": 250,
  "confidence_score": 0.88
}
```

**Use Cases:**
- Impact analysis (what breaks if I change this?)
- Data quality troubleshooting
- Compliance auditing (PII tracking)
- Documentation generation

---

## 🔍 Cross-System Matching

### How It Works

1. **Parse Source Entity** - Extract logic from selected graph/workflow
2. **Generate Embeddings** - Create semantic vectors for transformations
3. **Search Vector Database** - Find similar logic in other systems
4. **AI Comparison** - Use GPT-4 to validate semantic equivalence
5. **Rank Results** - Score matches by similarity (0-1)

### Similarity Scoring

| Score | Meaning | Action |
|-------|---------|--------|
| **0.9-1.0** | Nearly identical | Direct 1:1 migration possible |
| **0.7-0.9** | Very similar | Minor adjustments needed |
| **0.5-0.7** | Somewhat similar | Significant refactoring required |
| **<0.5** | Different | Not equivalent |

### Example Match Output

```json
{
  "selected_system": "abinitio",
  "selected_graph": "customer_load.graph",
  "matched_systems": {
    "hadoop": {
      "workflow": "customer_hive_workflow.xml",
      "similarity_score": 0.93
    },
    "databricks": {
      "pipeline": "customer_load_notebook",
      "similarity_score": 0.90
    }
  }
}
```

---

## 💡 Use Cases & Examples

### Use Case 1: Migration Planning

**Scenario:** Migrating from Ab Initio to Databricks

**Steps:**
1. Select Ab Initio graph in Lineage tab
2. Set target systems: [databricks]
3. Analyze lineage
4. Review similarity scores
5. Export STTM mappings for migration team
6. Use logic-level comparison to identify changes needed

**Result:** Clear migration path with field-by-field mapping

---

### Use Case 2: Data Quality Issue Investigation

**Scenario:** Customer_email field has nulls in production

**Steps:**
1. Search for customer_email in column-level lineage
2. View source columns and transformations
3. Check pre-processing rules
4. Trace back through dependency chain
5. Identify missing NULL_CHECK in source

**Result:** Root cause identified in 5 minutes vs 2 hours manual search

---

### Use Case 3: Compliance Audit (PII Tracking)

**Scenario:** Need to document all PII fields for GDPR

**Steps:**
1. Analyze all graphs in Lineage tab
2. Filter STTM mappings for contains_pii = true
3. Export filtered results to Excel
4. Review PII fields with business owners
5. Document handling procedures

**Result:** Complete PII inventory with lineage

---

### Use Case 4: System Decommissioning

**Scenario:** Shutting down legacy Hadoop cluster

**Steps:**
1. Analyze each Hadoop workflow
2. Find equivalent implementations in Databricks
3. Review similarity scores
4. Validate logic equivalence
5. Create migration checklist from STTM

**Result:** Safe decommissioning with zero data loss

---

## 📤 Export Options

### 1. STTM Excel Export

**Includes:**
- All STTM fields in spreadsheet format
- Filter and pivot capabilities
- Color-coded PII fields
- Confidence score visualization

**Use For:** Sharing with business analysts, documentation

---

### 2. STTM CSV Export

**Includes:**
- All STTM fields in CSV format
- Easy import to other tools
- Git-friendly for version control

**Use For:** Loading into BI tools, data catalogs

---

### 3. Full Lineage JSON Export

**Includes:**
- Complete lineage result object
- STTM mappings
- Cross-system matches
- 3-level lineage
- AI reasoning notes

**Use For:** System integration, API consumption, archival

**Structure:**
```json
{
  "selected_system": "abinitio",
  "selected_entity": "customer_load.graph",
  "entity_metadata": {...},
  "sttm_mappings": [...],
  "matched_systems": {...},
  "comparisons": {...},
  "column_lineage": [...],
  "flow_level_lineage": [...],
  "logic_level_lineage": [...],
  "ai_reasoning_notes": "...",
  "confidence_score": 0.85,
  "created_at": "2025-11-04T10:30:00"
}
```

---

### 4. Save to Metadata Store

**Saves to:** `./outputs/lineage/`

**File naming:** `lineage_{system}_{entity}_{timestamp}.json`

**Use For:** Building historical lineage repository, retraining AI models

---

## 🎨 UI Features

### STTM Mappings Tab

**Features:**
- ✅ Searchable, sortable table
- ✅ Filter by PII, confidence, field type
- ✅ Statistics summary
- ✅ Export options

**Filters:**
- **Show PII fields only** - Compliance view
- **Min Confidence** - Quality control
- **Field Type** - dimension, fact, measure, attribute

---

### Cross-System Matches Tab

**Features:**
- ✅ Similarity gauge (green/yellow/red)
- ✅ Match details per system
- ✅ Comparison summaries
- ✅ Expandable views

---

### 3-Level Lineage Tab

**Flow-Level:**
- Process-to-process mapping table
- Flow JSON export
- Visual graph (placeholder for React Flow)

**Logic-Level:**
- Transformation summary table
- Detailed transformation cards
- Complexity indicators

**Column-Level:**
- Column selector
- Source/target details
- Transformation code
- Dependency tree
- Full column table view

---

### AI Reasoning Tab

**Features:**
- ✅ Natural language analysis summary
- ✅ Analysis metadata
- ✅ Comparison summaries
- ✅ Insight highlights

---

## 🔧 Technical Architecture

```
┌─────────────────────────────────────────────────────────┐
│                  STAG Lineage Tab UI                    │
│          (ui/lineage_tab.py)                            │
└─────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────┐
│              Lineage Orchestrator                       │
│          (services/lineage/lineage_agents.py)           │
│                                                         │
│  Coordinates 5 Agents:                                  │
│  1. Parsing Agent   - Extract data from code            │
│  2. Logic Agent     - Interpret transformations         │
│  3. Mapping Agent   - Create STTM mappings              │
│  4. Similarity Agent - Find cross-system matches        │
│  5. Lineage Agent   - Build lineage chains              │
└─────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────┐
│              STTM Generator                             │
│        (services/lineage/sttm_generator.py)             │
│                                                         │
│  Generates column-level mappings for:                   │
│  - Ab Initio (.mp/.dml)                                 │
│  - Hadoop (.hql/.pig/.xml)                              │
│  - Databricks (.py/.ipynb)                              │
└─────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────┐
│         Azure OpenAI + Vector Database                  │
│                                                         │
│  GPT-4:              ChromaDB:                          │
│  - Logic analysis    - Semantic search                  │
│  - Comparison        - Similarity matching              │
│  - Reasoning         - Cross-system retrieval           │
└─────────────────────────────────────────────────────────┘
```

---

## 🛠️ API Usage (Programmatic)

### Generate STTM for Ab Initio

```python
from services.lineage.sttm_generator import STTMGenerator
from parsers.abinitio.parser import AbInitioParser

# Parse Ab Initio graph
parser = AbInitioParser()
result = parser.parse_file("customer_load.mp")

# Generate STTM mappings
sttm_gen = STTMGenerator()
mappings = []

for component in result['components']:
    comp_mappings = sttm_gen.generate_from_abinitio_component(
        component=component,
        graph_name="customer_load",
        partner="retail"
    )
    mappings.extend(comp_mappings)

# Export to Excel
sttm_gen.export_to_excel(mappings, "customer_load_sttm.xlsx")

print(f"Generated {len(mappings)} STTM mappings")
```

---

### Run Complete Lineage Analysis

```python
from services.lineage.lineage_agents import LineageOrchestrator

# Initialize orchestrator
orchestrator = LineageOrchestrator()

# Analyze lineage
result = orchestrator.analyze_lineage(
    system_type="abinitio",
    entity_name="customer_load.graph",
    file_path="/path/to/customer_load.mp",
    target_systems=["hadoop", "databricks"],
    partner="retail"
)

# Access results
print(f"STTM Mappings: {len(result.sttm_mappings)}")
print(f"Matches: {result.matched_systems}")
print(f"Confidence: {result.confidence_score:.0%}")

# Export JSON
with open("lineage_result.json", "w") as f:
    f.write(result.to_json())
```

---

## 📚 Advanced Features

### PII Detection

**Automatic detection of sensitive data:**

Patterns detected:
- SSN, Credit Card
- Email, Phone
- Address, ZIP code
- Birth Date, Age
- Driver License, Passport
- Account Numbers
- Salary, Income

**Usage:**
Filter STTM table by "contains_pii" to get compliance view

---

### Confidence Scoring

**AI-generated confidence scores (0-1):**

| Score | Meaning |
|-------|---------|
| **0.9-1.0** | High confidence - AI + strong patterns |
| **0.7-0.9** | Good confidence - AI analysis |
| **0.5-0.7** | Medium confidence - Rule-based |
| **<0.5** | Low confidence - Uncertain |

**Usage:**
Filter by minimum confidence to focus on high-quality mappings

---

### Field Type Classification

**Automatic classification:**

- **Dimension** - IDs, dates, names, codes
- **Fact** - Aggregated values
- **Measure** - Numeric metrics (amount, count, sum)
- **Attribute** - Descriptive fields

**Usage:**
Group by field_type to understand data model structure

---

### Dependency Tracking

**Captures:**
- Direct field dependencies (source columns)
- Function dependencies (SUM, AVG, etc.)
- Nested dependencies (calculated from calculated)

**Usage:**
Impact analysis - what breaks if source changes?

---

## 🚨 Troubleshooting

### Issue: "No STTM mappings generated"

**Causes:**
- Entity not found
- File path incorrect
- Parser error

**Solutions:**
1. Verify entity name spelling
2. Check file path exists
3. Upload file directly
4. Check logs in terminal

---

### Issue: "No cross-system matches found"

**Causes:**
- Other systems not indexed
- Query too specific
- Low similarity threshold

**Solutions:**
1. Index target systems first (Database tab)
2. Try broader entity name
3. Lower similarity threshold (if added to UI)

---

### Issue: "Low confidence scores"

**Causes:**
- Complex transformations
- Insufficient context
- Rule-based fallback (AI not available)

**Solutions:**
1. Verify Azure OpenAI credentials
2. Add more context to entity
3. Review transformation logic manually

---

## 📊 Best Practices

### 1. Naming Conventions

**Use clear, consistent names:**
- ✅ `customer_load.graph`
- ✅ `product_transform_v2`
- ❌ `graph1.mp`
- ❌ `temp_workflow`

---

### 2. Documentation

**Add comments to code:**
- Helps AI understand business logic
- Improves confidence scores
- Better reasoning notes

---

### 3. Incremental Analysis

**Start small:**
1. Analyze one graph first
2. Review STTM quality
3. Adjust naming if needed
4. Scale to full codebase

---

### 4. Regular Updates

**Keep lineage fresh:**
- Re-analyze after code changes
- Build lineage repository over time
- Version control STTM exports

---

### 5. Collaboration

**Share with team:**
- Export STTM to Excel for review
- Save JSON to shared drive
- Use in design reviews
- Reference in documentation

---

## 🎯 Roadmap

### v1.1 (Next Release)
- [ ] Visual lineage graphs (React Flow integration)
- [ ] Batch analysis (analyze multiple entities)
- [ ] Lineage diff (compare versions)
- [ ] Custom PII patterns

### v1.2 (Future)
- [ ] Real-time lineage updates
- [ ] Lineage-based recommendations
- [ ] Automated documentation generation
- [ ] REST API endpoints

---

## 📞 Support

### Documentation
- This guide: LINEAGE_TRACKING_GUIDE.md
- STAG guide: STAG_README.md
- Quick reference: QUICK_REFERENCE.md

### Code Locations
- UI: `ui/lineage_tab.py`
- Agents: `services/lineage/lineage_agents.py`
- STTM Generator: `services/lineage/sttm_generator.py`

---

## 🎉 Summary

You now have a **world-class AI-powered lineage tracking system** that:

✅ Generates detailed column-level mappings (STTM)
✅ Finds equivalent implementations across systems
✅ Provides 3-level lineage (flow, logic, column)
✅ Uses AI to understand transformation semantics
✅ Detects PII automatically
✅ Exports to Excel, CSV, JSON
✅ Integrates seamlessly with STAG UI

**Start exploring lineage in STAG → 🔗 Lineage tab!**

---

**Last Updated:** November 4, 2025
**Version:** 1.0
**Status:** ✅ PRODUCTION READY
