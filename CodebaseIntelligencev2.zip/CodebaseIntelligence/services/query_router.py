"""
Query Router - Intelligent Multi-System Query Routing
======================================================
Uses Azure OpenAI to detect intent and route queries to relevant collections

Routing Logic:
1. Detect mentioned systems (Ab Initio, Hadoop, Databricks, Autosys)
2. Classify intent (lineage, logic, comparison, schedule, etc.)
3. Route to relevant collections
4. Handle cross-system queries

Examples:
- "Compare Hadoop and Ab Initio for customer load" → [hadoop_collection, abinitio_collection]
- "When does job X run?" → [autosys_collection, cross_system_links]
- "Show lineage for customer_id" → ALL collections
"""

import os
import json
from typing import List, Dict, Any, Optional
from loguru import logger

try:
    from openai import AzureOpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False


class QueryRouter:
    """
    Intelligent query router using Azure OpenAI

    Routes queries to appropriate collections based on:
    - System mentions (explicit or implicit)
    - Query intent (lineage, comparison, logic, schedule)
    - Context from conversation history
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        use_fast_model: bool = True,
    ):
        """
        Initialize query router

        Args:
            api_key: Azure OpenAI API key (optional, reads from env)
            use_fast_model: Use GPT-3.5 for faster routing (default: True)
        """
        self.llm = None
        self.enabled = False

        if OPENAI_AVAILABLE and (api_key or os.getenv("AZURE_OPENAI_API_KEY")):
            try:
                self.llm = AzureOpenAI(
                    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                    api_key=api_key or os.getenv("AZURE_OPENAI_API_KEY"),
                    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
                )

                # Use fast model for routing (cheaper, faster)
                if use_fast_model:
                    self.model_name = os.getenv("AZURE_OPENAI_FAST_DEPLOYMENT", "gpt-35-turbo")
                else:
                    self.model_name = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4")

                self.enabled = True
                logger.info(f"✓ Query Router initialized with {self.model_name}")

            except Exception as e:
                logger.warning(f"Could not initialize query router: {e}")
                logger.warning("Falling back to rule-based routing")
                self.enabled = False
        else:
            logger.info("Query Router disabled (no Azure OpenAI). Using rule-based routing.")

        # System prompt for routing
        self.system_prompt = self._create_routing_prompt()

    def _create_routing_prompt(self) -> str:
        """Create system prompt for query routing"""
        return """You are an expert query router for a multi-system ETL codebase.

Available Collections:
1. **abinitio_collection**: Ab Initio graphs, components, DMLs, transformations
2. **hadoop_collection**: Hive scripts, Pig scripts, Spark jobs, Oozie workflows
3. **databricks_collection**: Databricks notebooks, jobs, SQL/Python/Scala code
4. **autosys_collection**: Job schedules, triggers, dependencies
5. **cross_system_links**: Autosys→AbInitio execution flows, cross-system dependencies
6. **documents_collection**: Business docs, PDFs, reports, FAWN documentation

Your task: Analyze the user's query and determine:
1. Which systems are mentioned or implied (Ab Initio, Hadoop, Databricks, Autosys)
2. What is the query intent:
   - **lineage**: Trace data flow, column mappings
   - **logic**: Understand transformation logic, business rules
   - **comparison**: Compare logic across systems
   - **schedule**: Job scheduling, triggers, timing
   - **dependency**: Job dependencies, execution order
   - **search**: General code search
   - **cross_system**: Relationships between systems
3. Which collections to search (return as list)

Routing Rules:
- If query mentions "schedule", "trigger", or "when": Include autosys_collection
- If query mentions "compare", "difference", or multiple systems: Include all relevant system collections
- If query mentions "lineage" or "flow": Include ALL collections (cross-system lineage)
- If query mentions "Autosys job runs graph": Include autosys_collection AND cross_system_links
- If query mentions specific system (Hadoop, Databricks): Include that system's collection
- If query is about documentation or reports: Include documents_collection
- Default fallback: Search abinitio_collection, hadoop_collection, databricks_collection

Return response in JSON format:
{
  "collections": ["collection1", "collection2", ...],
  "intent": "lineage | logic | comparison | schedule | dependency | search | cross_system",
  "systems": ["abinitio", "hadoop", "databricks", "autosys"],
  "reasoning": "Brief explanation of routing decision",
  "search_strategy": "single_system | multi_system | cross_system | all"
}

Be intelligent but conservative - when in doubt, search more collections rather than fewer."""

    def route_query(self, query: str, context: Optional[str] = None) -> Dict[str, Any]:
        """
        Route query to appropriate collections

        Args:
            query: User's natural language query
            context: Optional context from conversation history

        Returns:
            Dict with collections, intent, systems, and routing reasoning
        """
        if self.enabled:
            return self._route_with_llm(query, context)
        else:
            return self._route_with_rules(query)

    def _route_with_llm(self, query: str, context: Optional[str] = None) -> Dict[str, Any]:
        """Route using Azure OpenAI"""
        user_prompt = f"""User Query: {query}"""

        if context:
            user_prompt += f"\n\nConversation Context:\n{context}"

        user_prompt += "\n\nProvide routing decision in JSON format."

        try:
            response = self.llm.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.1,  # Low temperature for consistent routing
                max_tokens=500,
            )

            content = response.choices[0].message.content

            # Parse JSON response
            if "```json" in content:
                json_str = content.split("```json")[1].split("```")[0].strip()
            elif "```" in content:
                json_str = content.split("```")[1].split("```")[0].strip()
            else:
                json_str = content.strip()

            routing = json.loads(json_str)

            # Validate collections
            valid_collections = [
                "abinitio_collection",
                "hadoop_collection",
                "databricks_collection",
                "autosys_collection",
                "cross_system_links",
                "documents_collection",
            ]

            routing["collections"] = [
                c for c in routing.get("collections", [])
                if c in valid_collections
            ]

            # Ensure at least one collection
            if not routing["collections"]:
                routing["collections"] = ["abinitio_collection", "hadoop_collection"]
                routing["reasoning"] += " (Added default collections as fallback)"

            logger.info(f"🧭 Route: {query[:50]}... → {routing['collections']}")
            logger.debug(f"   Intent: {routing.get('intent')}")
            logger.debug(f"   Reasoning: {routing.get('reasoning')}")

            return routing

        except Exception as e:
            logger.error(f"LLM routing error: {e}")
            logger.warning("Falling back to rule-based routing")
            return self._route_with_rules(query)

    def _route_with_rules(self, query: str) -> Dict[str, Any]:
        """Fallback rule-based routing"""
        query_lower = query.lower()

        collections = []
        systems = []
        intent = "search"

        # Detect systems
        if "ab initio" in query_lower or "abinitio" in query_lower or "graph" in query_lower:
            collections.append("abinitio_collection")
            systems.append("abinitio")

        if "hadoop" in query_lower or "hive" in query_lower or "pig" in query_lower or "spark" in query_lower:
            collections.append("hadoop_collection")
            systems.append("hadoop")

        if "databricks" in query_lower or "notebook" in query_lower:
            collections.append("databricks_collection")
            systems.append("databricks")

        if "autosys" in query_lower or "job" in query_lower or "schedule" in query_lower:
            collections.append("autosys_collection")
            systems.append("autosys")

        # Detect intent
        if "lineage" in query_lower or "flow" in query_lower or "trace" in query_lower:
            intent = "lineage"
            # Lineage queries should search all collections
            collections = [
                "abinitio_collection",
                "hadoop_collection",
                "databricks_collection",
                "cross_system_links"
            ]

        elif "compare" in query_lower or "difference" in query_lower or "vs" in query_lower:
            intent = "comparison"
            # Ensure at least 2 collections for comparison
            if len(collections) < 2:
                collections = ["abinitio_collection", "hadoop_collection"]

        elif "schedule" in query_lower or "trigger" in query_lower or "when" in query_lower:
            intent = "schedule"
            if "autosys_collection" not in collections:
                collections.append("autosys_collection")
            if "cross_system_links" not in collections:
                collections.append("cross_system_links")

        elif "dependency" in query_lower or "depends on" in query_lower or "after" in query_lower:
            intent = "dependency"
            if "autosys_collection" not in collections:
                collections.append("autosys_collection")

        elif "doc" in query_lower or "report" in query_lower or "pdf" in query_lower:
            collections.append("documents_collection")

        # Default fallback
        if not collections:
            collections = ["abinitio_collection", "hadoop_collection"]
            systems = ["abinitio", "hadoop"]

        # Remove duplicates
        collections = list(set(collections))
        systems = list(set(systems))

        # Determine search strategy
        if len(systems) > 1:
            search_strategy = "multi_system"
        elif "cross_system_links" in collections:
            search_strategy = "cross_system"
        elif len(collections) > 3:
            search_strategy = "all"
        else:
            search_strategy = "single_system"

        routing = {
            "collections": collections,
            "intent": intent,
            "systems": systems,
            "reasoning": f"Rule-based routing: detected {', '.join(systems)} systems with {intent} intent",
            "search_strategy": search_strategy,
        }

        logger.info(f"🧭 Route (rules): {query[:50]}... → {collections}")

        return routing


# Convenience function
def create_query_router(use_llm: bool = True) -> QueryRouter:
    """
    Create query router with sensible defaults

    Args:
        use_llm: Try to use LLM routing (default: True)

    Returns:
        QueryRouter instance
    """
    if use_llm:
        return QueryRouter()
    else:
        # Force rule-based routing
        return QueryRouter(api_key=None)


# Example usage
if __name__ == "__main__":
    router = create_query_router()

    # Test queries
    test_queries = [
        "Compare Hadoop and Ab Initio for customer load",
        "When does job customer_etl run?",
        "Show lineage for customer_id column",
        "What's the transformation logic in graph X?",
        "Find dependencies for job_Y",
        "Search for patient data processing",
    ]

    print("\nQuery Routing Tests:")
    print("=" * 80)

    for query in test_queries:
        routing = router.route_query(query)

        print(f"\nQuery: {query}")
        print(f"Collections: {routing['collections']}")
        print(f"Intent: {routing['intent']}")
        print(f"Systems: {routing['systems']}")
        print(f"Strategy: {routing.get('search_strategy', 'N/A')}")
        print(f"Reasoning: {routing.get('reasoning', 'N/A')}")
