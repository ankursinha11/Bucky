# STAG Database Management Tab - User Guide

**Complete vector database management directly in STAG UI** ⚙️

---

## Overview

The new **"Database"** tab in STAG provides full control over your vector database:
- ✅ View real-time database status
- ✅ Clear collections (specific or all)
- ✅ Re-index from directories or file uploads
- ✅ Export statistics
- ✅ Progress tracking with visual indicators

**No more command-line needed!** Everything is in the UI.

---

## Accessing the Database Tab

1. Launch STAG: `./start_stag.sh`
2. Click the **"⚙️ Database"** tab (4th tab)

---

## Features

### 1. 📊 Database Status (Top Section)

**Real-time metrics:**
- **Total Documents**: Count across all collections
- **Collections**: Number of active collections
- **Database Size**: Total storage in MB

**Refresh Button**: Click to update stats after operations

**Collection Details**: Expandable sections showing:
- Document count per collection
- Any errors or warnings

---

### 2. 🛠️ Management Operations (Dropdown)

Select from 8 operations:

#### **View Status Only** (Default)
Just shows database info, no actions

#### **Clear Specific Collection**
- Choose collection from dropdown:
  - Ab Initio
  - Hadoop
  - Databricks
  - Autosys
  - Cross-System Links
  - Documents
- Shows current document count
- Requires checkbox confirmation
- ⚠️ **Warning**: Permanent deletion!

#### **Clear All Collections**
- **DANGER ZONE** - deletes entire database
- Shows total documents to be deleted
- Requires:
  1. Checkbox: "I understand this will delete all data"
  2. Text confirmation: Type "DELETE ALL"
- Double-safety to prevent accidents

#### **Re-index Ab Initio**
Two options:
1. **Directory Path**: Enter path like `/path/to/abinitio`
2. **File Upload**: Drag & drop .mp files

Features:
- Progress bar shows parsing → indexing
- Success message with counts
- Auto-refreshes stats

#### **Re-index Autosys**
Same as Ab Initio but for .jil files

#### **Re-index Documents**
- Supports: PDF, Excel, Word, Markdown
- **Checkbox**: "Include subdirectories" (default: on)
- Progress tracking for large batches

#### **Re-index Everything**
Complete fresh start:
- Enter paths for each system (optional)
- Clears all existing data
- Re-indexes in sequence
- Shows multi-step progress:
  - Step 1/4: Clearing database
  - Step 2/4: Initializing indexer
  - Step 3/4: Indexing systems
  - Step 4/4: Finalizing
- **🎈 Balloons** on completion!

#### **Export Statistics**
- Generates JSON with full stats
- Includes timestamp
- Download button appears
- Filename: `vector_db_stats_YYYYMMDD_HHMMSS.json`

---

## Example Workflows

### Workflow 1: Check Database Status

```
1. Open STAG
2. Click "⚙️ Database" tab
3. View metrics at top
4. Expand collections to see details
5. Click "🔄 Refresh Status" if needed
```

**What you'll see:**
```
Total Documents: 3,568
Collections: 6
Database Size: 127.45 MB

Collection Details:
├─ Abinitio: 2,891 documents
├─ Hadoop: 156 documents
├─ Autosys: 432 documents
├─ Cross System Links: 89 documents
└─ Documents: 0 documents
```

---

### Workflow 2: Clear and Re-index Ab Initio

```
1. Click "⚙️ Database" tab
2. Select "Clear Specific Collection"
3. Choose "Ab Initio"
4. Check "I understand..."
5. Click "Clear Collection"
   → Collection cleared ✓
6. Change dropdown to "Re-index Ab Initio"
7. Enter directory path: /path/to/abinitio
8. Click "Start Indexing"
   → Progress bar: 0% → 20% → 50% → 100%
   → "✓ Indexed 245 graphs and 2,289 components"
```

---

### Workflow 3: Upload New Documents

```
1. Click "⚙️ Database" tab
2. Select "Re-index Documents"
3. Choose "Option 2: Upload Files"
4. Drag & drop PDFs/Excel files
5. Click "Start Indexing"
   → Files parsed and indexed immediately
   → "✓ Indexed 10 documents (47 chunks)"
```

---

### Workflow 4: Complete Fresh Start

```
1. Click "⚙️ Database" tab
2. Select "Re-index Everything"
3. Enter paths:
   - Ab Initio Directory: /data/abinitio
   - Autosys Directory: /data/autosys
   - Documents Directory: /data/docs
4. Check "Clear existing data and re-index"
5. Click "Start Full Re-index"

Progress shown:
├─ Step 1/4: Clearing existing database... [10%]
├─ Step 2/4: Initializing fresh indexer... [20%]
├─ Step 3/4: Indexing Ab Initio (1/3)... [50%]
├─ Step 3/4: Indexing Autosys (2/3)... [70%]
├─ Step 3/4: Indexing Documents (3/3)... [90%]
└─ Step 4/4: Finalizing... [100%]

"✓ Full re-index complete!" 🎈
```

---

## Safety Features

### 1. Confirmation Checkboxes
All destructive operations require explicit confirmation

### 2. Double Confirmation for "Clear All"
Must check AND type "DELETE ALL" - prevents accidents

### 3. Current Count Display
Shows exactly how many documents will be deleted

### 4. Progress Tracking
Visual feedback during long operations

### 5. Error Handling
Clear error messages if something goes wrong

---

## Integration with Other Tabs

### After Re-indexing:
1. **Chat Tab**: New files immediately searchable
2. **Compare Tab**: Can compare newly indexed systems
3. **Analytics Tab**: Updated statistics shown

### No Restart Needed!
All changes reflected instantly in STAG

---

## Keyboard Shortcuts (Coming Soon)

- `Ctrl+R`: Refresh status
- `Ctrl+Shift+C`: Open clear confirmation
- `Esc`: Cancel operation

---

## Performance Notes

### Operation Times (Approximate)

| Operation | Small (100 files) | Large (1000 files) |
|-----------|-------------------|--------------------|
| Clear Collection | <1 sec | <1 sec |
| Clear All | <2 sec | <2 sec |
| Index Ab Initio | ~30 sec | ~5 min |
| Index Autosys | ~20 sec | ~3 min |
| Index Documents | ~2 min | ~10 min |
| Full Re-index | ~3 min | ~20 min |

**Tip**: Use Azure embeddings for quality, local for speed

---

## Troubleshooting

### Issue: "No database statistics available"

**Solution**: Initialize indexer first by indexing some files

### Issue: Progress bar stuck

**Solution**: Check browser console (F12) for errors, refresh page

### Issue: "Collection doesn't exist"

**Solution**: Collection may already be empty, check status first

### Issue: Path not found

**Solution**: Verify directory path is absolute (starts with /)

---

## Screenshots Guide

### Database Status View
```
┌────────────────────────────────────────────┐
│ ⚙️ Vector Database Management             │
├────────────────────────────────────────────┤
│ Manage your vector database collections   │
│                                            │
│ ────────────────────────────────────────── │
│ 📊 Database Status                         │
│ ┌──────────┐ ┌──────────┐ ┌─────────────┐│
│ │  3,568   │ │    6     │ │  127.45 MB  ││
│ │ Documents│ │Collections│ │Database Size││
│ └──────────┘ └──────────┘ └─────────────┘│
│                                            │
│ [🔄 Refresh Status                      ] │
│                                            │
│ ────────────────────────────────────────── │
│ 📈 Collection Details                      │
│ ▼ 📁 Abinitio                              │
│   Documents: 2,891                         │
│                                            │
│ ▶ 📁 Hadoop                                │
│ ▶ 📁 Autosys                               │
│ ▶ 📁 Cross System Links                    │
│                                            │
│ ────────────────────────────────────────── │
│ 🛠️ Management Operations                   │
│ [Select Operation ▼                     ] │
│   • View Status Only                       │
│   • Clear Specific Collection              │
│   • Clear All Collections                  │
│   • Re-index Ab Initio                     │
│   • Re-index Autosys                       │
│   • Re-index Documents                     │
│   • Re-index Everything                    │
│   • Export Statistics                      │
└────────────────────────────────────────────┘
```

### Re-index Interface
```
┌────────────────────────────────────────────┐
│ 🔄 Re-index Ab Initio                      │
├────────────────────────────────────────────┤
│ ℹ️ Index Ab Initio .mp files with          │
│    FAWN-enhanced parser                    │
│                                            │
│ Option 1: Index from Directory             │
│ ┌────────────────────────────────────────┐│
│ │ /path/to/abinitio                      ││
│ └────────────────────────────────────────┘│
│                                            │
│ Option 2: Upload Files                     │
│ ┌────────────────────────────────────────┐│
│ │ Drag files here or click to browse    ││
│ │                                        ││
│ └────────────────────────────────────────┘│
│                                            │
│ [Start Indexing                          ] │
│                                            │
│ Progress:                                  │
│ ████████████████░░░░░░░░░░ 50%           │
│ Indexing graphs and components...          │
└────────────────────────────────────────────┘
```

---

## Comparison: UI vs CLI

| Task | UI Method | CLI Method |
|------|-----------|------------|
| **Check Status** | Click Database tab | `python manage_vector_db.py --status` |
| **Clear Collection** | Select from dropdown | `python manage_vector_db.py --clear abinitio` |
| **Re-index** | Enter path or upload | `python manage_vector_db.py --reindex abinitio --path /path` |
| **Export Stats** | Click Export button | `python manage_vector_db.py --export-stats` |

**UI Advantages:**
✅ Visual progress bars
✅ Drag & drop file upload
✅ Real-time stats display
✅ No terminal needed
✅ Error messages in UI
✅ Confirmation dialogs

**CLI Advantages:**
✅ Scriptable/automatable
✅ Works in headless environments
✅ Better for CI/CD pipelines

**Recommendation**: Use UI for manual operations, CLI for automation

---

## Best Practices

### 1. Check Status Before Clearing
Always review current counts before deleting

### 2. Test with Small Batch First
Upload a few files to test before full directory index

### 3. Use Incremental Updates
Clear and re-index only changed collections

### 4. Export Stats Regularly
Keep snapshots for comparison

### 5. Monitor Database Size
Keep track of storage growth

---

## FAQ

**Q: Do I still need command-line scripts?**
A: No! Everything is in the UI now. CLI scripts are optional for automation.

**Q: Can I index while STAG is running?**
A: Yes! Just click "Refresh Status" after indexing.

**Q: What happens if I close browser during indexing?**
A: Operation continues in backend. Refresh page to see status.

**Q: Can I undo a clear operation?**
A: No, it's permanent. Always check counts before clearing.

**Q: How to backup before clearing?**
A: Use CLI: `tar -czf backup.tar.gz ./outputs/vector_db`

---

## Summary

The **Database tab** brings all vector database management into STAG:

✅ **View**: Real-time status and statistics
✅ **Clear**: Specific collections or entire database
✅ **Re-index**: From directories or file uploads
✅ **Export**: Download stats as JSON
✅ **Progress**: Visual tracking for all operations
✅ **Safety**: Confirmation dialogs prevent accidents

**No more switching between terminal and UI!**

---

**Last Updated**: November 2, 2025
**STAG Version**: 1.1 (with Database Management Tab)
