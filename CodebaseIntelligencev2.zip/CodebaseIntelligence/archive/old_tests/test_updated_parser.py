"""
Test Updated Abinitio Parser with FAWN Enhancements
====================================================
Tests the enhanced parser with:
- Subgraph hierarchy tracking
- Execution logging
- AI analysis (optional)
- Excel export with new columns
"""

import os
import sys
from pathlib import Path
from datetime import datetime
from loguru import logger

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from parsers.abinitio.parser import AbInitioParser


def test_parser_with_sample_files():
    """Test updated parser with sample MP files"""

    # Sample MP files directory
    mp_directory = "/Users/ankurshome/Desktop/Hadoop_Parser/OneDrive_1_7-25-2025/Ab-Initio"

    logger.info("="*80)
    logger.info("Testing Updated Abinitio Parser with FAWN Enhancements")
    logger.info("="*80)

    # Create output directory
    output_dir = Path(__file__).parent / "test_output"
    output_dir.mkdir(exist_ok=True)

    # Initialize parser with enhancements
    parser = AbInitioParser(
        enable_filter=False,  # Parse all graphs
        enable_logging=True   # Enable execution logging
    )

    logger.info(f"\n📂 Parsing MP files from: {mp_directory}")

    # Parse directory
    result = parser.parse_directory(mp_directory)

    # Print summary
    logger.info(f"\n✓ Parsing Complete:")
    logger.info(f"  - Processes: {len(result['processes'])}")
    logger.info(f"  - Components: {len(result['components'])}")

    # Check for subgraph hierarchy in first component
    if result['components']:
        first_comp = result['components'][0]
        logger.info(f"\n📊 First Component Details:")
        logger.info(f"  - Name: {first_comp.name}")
        logger.info(f"  - Type: {first_comp.component_type.value}")
        logger.info(f"  - Parameters: {len(first_comp.parameters)}")

    # Get source files for logging
    import glob
    source_files = glob.glob(os.path.join(mp_directory, "*.mp"))

    # Export to Excel
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = output_dir / f"abinitio_parsed_{timestamp}.xlsx"

    logger.info(f"\n📊 Exporting to Excel: {output_file}")

    parser.export_to_excel(
        output_path=str(output_file),
        source_files=source_files
    )

    logger.info(f"\n✅ Test Complete!")
    logger.info(f"  - Output file: {output_file}")

    if parser.execution_log_path:
        logger.info(f"  - Execution log: {parser.execution_log_path}")

    # Check raw MP data for hierarchy info
    if parser.raw_mp_data:
        logger.info(f"\n📝 Raw MP Data Summary:")
        for mp_data in parser.raw_mp_data:
            file_name = mp_data.get("file_name", "Unknown")
            components = mp_data.get("components", [])

            logger.info(f"\n  Graph: {file_name}")
            logger.info(f"    - Components: {len(components)}")

            # Check for hierarchy in components
            components_with_hierarchy = [
                c for c in components
                if c.get("subgraph_hierarchy")
            ]

            if components_with_hierarchy:
                logger.info(f"    - Components with hierarchy: {len(components_with_hierarchy)}")
                # Show first one
                sample = components_with_hierarchy[0]
                logger.info(f"    - Sample hierarchy: {sample.get('subgraph_hierarchy')}")

    return output_file


if __name__ == "__main__":
    logger.remove()  # Remove default handler
    logger.add(sys.stdout, format="<green>{time:HH:mm:ss}</green> | <level>{message}</level>", level="INFO")

    try:
        output_file = test_parser_with_sample_files()
        print(f"\n✅ Success! Open the Excel file to see results:")
        print(f"   {output_file}")

    except Exception as e:
        logger.error(f"Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
