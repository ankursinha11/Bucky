# CodebaseIntelligence RAG System - Architecture Analysis & Improvement Plan

## Executive Summary

**Current State**: Good foundation with parsers, AI analysis, and basic RAG
**Goal**: Comprehensive multi-system RAG with context-aware routing and cross-system correlation

---

## What's Built ✅

### 1. Parsing Layer (EXCELLENT)
- ✅ Ab Initio parser with FAWN enhancements
- ✅ Autosys parser with dependency extraction
- ✅ Hadoop parsers (Hive, Pig, Spark, Oozie)
- ✅ Databricks parser (notebooks, SQL, Python, Scala)
- ✅ AI-powered semantic analysis (Azure OpenAI GPT-4)

### 2. Data Models (COMPREHENSIVE)
- ✅ **Tier 1**: Repository (overall statistics)
- ✅ **Tier 2**: WorkflowFlow (execution flow diagrams)
- ✅ **Tier 3**: ScriptLogic (transformations, lineage)
- ✅ Process/Component models
- ✅ Column lineage tracking

### 3. Indexing (PARTIALLY COMPLETE)
- ✅ **CodebaseIndexer**: Basic process/component indexing
- ✅ **DeepIndexer**: 3-tier hierarchical indexing
- ✅ Transformation-level granularity
- ✅ Column lineage indexing

### 4. Vector Search (WORKING)
- ✅ ChromaDB integration (local, free)
- ✅ Sentence-transformers embeddings
- ✅ Metadata filtering
- ✅ Persistent storage

### 5. RAG Chatbot (BASIC)
- ✅ Query and answer capability
- ✅ Azure OpenAI integration (optional)
- ✅ Context building from search results
- ✅ Conversation history

---

## What's Missing ❌

### 1. Separate Collections per System 🔴 CRITICAL
**Current**: Single "codebase" collection for all systems
**Needed**: Separate namespaces/collections for clean retrieval

```
Needed Structure:
├── abinitio_collection/
│   ├── graphs
│   ├── components
│   └── autosys_links
├── hadoop_collection/
│   ├── hive_scripts
│   ├── pig_scripts
│   ├── spark_scripts
│   └── oozie_workflows
├── databricks_collection/
│   ├── notebooks
│   └── jobs
└── documents_collection/
    ├── fawn_docs
    └── pdf_reports
```

### 2. Azure OpenAI Embeddings 🟡 IMPORTANT
**Current**: sentence-transformers (all-MiniLM-L6-v2)
**Needed**: text-embedding-3-large for better semantic understanding

**Why**:
- Higher quality embeddings (3072 dimensions vs 384)
- Better multilingual support
- More accurate semantic matching
- Consistent with Azure OpenAI LLM

### 3. Multi-System Query Routing 🔴 CRITICAL
**Current**: No intent detection
**Needed**: Smart routing based on query intent

**Example**:
```
Query: "Compare Hadoop and Ab Initio for customer load"
→ Route to: [hadoop_collection, abinitio_collection]

Query: "When does job X run?"
→ Route to: [autosys_collection, abinitio_collection] (linked)

Query: "Show lineage for customer_id"
→ Route to: ALL collections
```

### 4. Autosys + Ab Initio Cross-Linking 🟡 IMPORTANT
**Current**: Parsed separately, not linked in vector DB
**Needed**: Combined documents showing full execution flow

**Example Document**:
```json
{
  "id": "autosys_job_X_abinitio_graph_Y",
  "content": "
    Autosys Job: job_customer_load
    Schedule: Daily 2AM
    Runs Ab Initio Graph: customer_load.graph
    Graph Logic: Aggregates customer data...
  ",
  "metadata": {
    "doc_type": "cross_system_link",
    "autosys_job": "job_customer_load",
    "abinitio_graph": "customer_load.graph",
    "systems": ["autosys", "abinitio"]
  }
}
```

### 5. Structured Response Format 🟡 IMPORTANT
**Current**: Free-text responses
**Needed**: System-by-system breakdown

**Example Output**:
```
SYSTEM: Ab Initio + Autosys
Graph: customer_load.graph
Autosys Job: job_customer_load
Trigger: Daily at 2AM
Logic: Aggregates customer data from staging to dimension

SYSTEM: Hadoop (Spark)
Script: customer_load_spark.py
Purpose: Same aggregation in modern pipeline

COMPARISON:
- Both aggregate customer data
- Ab Initio uses lookup file join
- Hadoop uses Spark broadcast join
- Logic equivalence: 95%
```

### 6. Cross-System Comparison 🟡 IMPORTANT
**Current**: Limited to basic search
**Needed**: AI-powered logic comparison

**Capabilities**:
- Detect equivalent logic across systems
- Find differences in implementation
- Identify migration opportunities
- Compare performance characteristics

### 7. Document Indexing (PDFs, FAWN Reports) 🟢 NICE-TO-HAVE
**Current**: Only code indexing
**Needed**: Index business documentation

**Sources**:
- FAWN reports (Excel → text)
- PDF documentation
- Confluence pages
- Business requirement docs

### 8. Incremental Updates & Versioning 🟡 IMPORTANT
**Current**: Full reindex every time
**Needed**: Smart incremental updates

**Features**:
- Version tagging (v1, v2, etc.)
- Delta indexing (only changed files)
- Rollback capability
- Change tracking

---

## Priority Implementation Plan

### Phase 1: Multi-Collection Architecture (Week 1) 🔴
**Goal**: Separate collections for clean retrieval

**Tasks**:
1. Create `MultiCollectionIndexer` class
2. Implement collection-per-system strategy
3. Add collection routing logic
4. Test with Ab Initio + Hadoop

**Files to Create/Update**:
- `services/multi_collection_indexer.py` (NEW)
- `services/local_search/local_search_client.py` (UPDATE)

### Phase 2: Azure OpenAI Embeddings (Week 1) 🟡
**Goal**: Higher quality semantic search

**Tasks**:
1. Add Azure OpenAI embedding client
2. Make embedding model configurable
3. Batch embedding generation
4. Fallback to sentence-transformers if no API key

**Files to Create/Update**:
- `services/azure_embeddings.py` (NEW)
- `services/local_search/local_search_client.py` (UPDATE)

### Phase 3: Intent Detection & Query Routing (Week 2) 🔴
**Goal**: Smart multi-system queries

**Tasks**:
1. Create `QueryRouter` using Azure OpenAI
2. Detect query intent (lineage, comparison, logic, schedule, etc.)
3. Route to relevant collections
4. Merge results intelligently

**Files to Create/Update**:
- `services/query_router.py` (NEW)
- `services/rag_chatbot_integrated.py` (UPDATE)

### Phase 4: Autosys + Ab Initio Linking (Week 2) 🟡
**Goal**: End-to-end execution flow visibility

**Tasks**:
1. Create cross-system link documents during parsing
2. Index in special "cross_system" collection
3. Extract Autosys → Ab Initio mappings
4. Build combined lineage view

**Files to Create/Update**:
- `parsers/cross_system_linker.py` (NEW)
- `services/multi_collection_indexer.py` (UPDATE)

### Phase 5: Structured Response Generator (Week 3) 🟡
**Goal**: Clear system-by-system answers

**Tasks**:
1. Create response template system
2. Parse LLM outputs into structured format
3. Add system badges and sections
4. Include comparison summaries

**Files to Create/Update**:
- `services/response_formatter.py` (NEW)
- `services/rag_chatbot_integrated.py` (UPDATE)

### Phase 6: Cross-System Comparison (Week 3) 🟡
**Goal**: AI-powered logic comparison

**Tasks**:
1. Extract comparable logic patterns
2. Use Azure OpenAI to compare semantics
3. Detect equivalent transformations
4. Generate migration recommendations

**Files to Create/Update**:
- `services/logic_comparator.py` (NEW)
- `services/ai_script_analyzer.py` (UPDATE)

### Phase 7: Document Indexing (Week 4) 🟢
**Goal**: Index business docs and reports

**Tasks**:
1. PDF text extraction
2. Excel → text conversion
3. Chunk business documents
4. Index in documents collection

**Files to Create/Update**:
- `parsers/document_parser.py` (NEW)
- `services/multi_collection_indexer.py` (UPDATE)

### Phase 8: Versioning & Incremental Updates (Week 4) 🟡
**Goal**: Efficient updates without full reindex

**Tasks**:
1. Add version tags to all documents
2. Track file hashes to detect changes
3. Implement delta indexing
4. Add rollback capability

**Files to Create/Update**:
- `services/version_manager.py` (NEW)
- `services/multi_collection_indexer.py` (UPDATE)

---

## Technical Architecture (Proposed)

```
┌─────────────────────────────────────────────────────────┐
│           User Query (Natural Language)                 │
└─────────────────┬───────────────────────────────────────┘
                  │
          ┌───────▼─────────┐
          │  Query Router    │ ← Azure OpenAI intent detection
          │ (Intent Detect)  │
          └───────┬─────────┘
                  │
      ┌───────────┴──────────────┐
      │ Route to Collections:     │
      │ - abinitio_collection    │
      │ - hadoop_collection      │
      │ - databricks_collection  │
      │ - autosys_collection     │
      │ - documents_collection   │
      │ - cross_system_links     │
      └───────┬──────────────────┘
              │
   ┌──────────▼─────────────────────────────┐
   │  Multi-Collection Vector Search        │
   │  (ChromaDB + Azure OpenAI Embeddings)  │
   └──────────┬─────────────────────────────┘
              │
      ┌───────▼──────────┐
      │ Context Aggregator│ ← Merge results, re-rank
      └───────┬──────────┘
              │
      ┌───────▼──────────┐
      │ Response Formatter│ ← Structure by system
      └───────┬──────────┘
              │
      ┌───────▼──────────┐
      │   Azure OpenAI    │ ← Generate final answer
      │   GPT-4/GPT-5     │
      └───────┬──────────┘
              │
      ┌───────▼──────────┐
      │  Structured Output│
      │ SYSTEM: Ab Initio │
      │ SYSTEM: Hadoop    │
      │ COMPARISON:       │
      └───────────────────┘
```

---

## Collection Structure (Detailed)

### Collection 1: abinitio_collection
```python
{
  "id": "abinitio_graph_customer_load_abc123",
  "content": "Graph: customer_load.graph\nComponents: 50\nLogic: Aggregates daily customer data...",
  "metadata": {
    "doc_type": "abinitio_graph",
    "system": "abinitio",
    "graph_name": "customer_load.graph",
    "module": "CDD",
    "component_count": 50,
    "has_autosys_link": true,
    "autosys_job": "job_customer_load"
  }
}
```

### Collection 2: hadoop_collection
```python
{
  "id": "hadoop_spark_customer_load_xyz789",
  "content": "Spark Script: customer_load_spark.py\nLogic: Aggregates customer data using PySpark...",
  "metadata": {
    "doc_type": "hadoop_spark",
    "system": "hadoop",
    "script_type": "pyspark",
    "script_name": "customer_load_spark.py",
    "workflow": "customer_etl_flow"
  }
}
```

### Collection 3: cross_system_links
```python
{
  "id": "link_autosys_job_customer_load",
  "content": "
    AUTOSYS JOB: job_customer_load
    Schedule: Daily 2AM
    Dependencies: job_staging_complete

    EXECUTES AB INITIO GRAPH: customer_load.graph
    Graph Logic: Aggregates customer staging data into dimension table

    FULL EXECUTION FLOW:
    1. Autosys triggers at 2AM
    2. Ab Initio graph reads staging tables
    3. Performs lookup join with customer master
    4. Writes to dim_customer
  ",
  "metadata": {
    "doc_type": "cross_system_link",
    "systems": ["autosys", "abinitio"],
    "autosys_job": "job_customer_load",
    "abinitio_graph": "customer_load.graph",
    "link_type": "job_executes_graph"
  }
}
```

---

## Quick Wins (Can Implement Today)

### 1. Create Multi-Collection Indexer (2 hours)
- Separate collections per system
- Immediate better retrieval

### 2. Add Azure OpenAI Embeddings (1 hour)
- Higher quality search
- Better semantic matching

### 3. Create Cross-System Link Documents (2 hours)
- Autosys + Ab Initio linking
- End-to-end flow visibility

### 4. Basic Intent Detection (2 hours)
- Route queries to correct collections
- Multi-system queries work

---

## Success Metrics

### Before Improvements:
- Single collection for all systems
- Generic text embeddings (384 dim)
- No cross-system awareness
- Free-text responses only

### After Improvements:
- ✅ 6+ separate collections (by system)
- ✅ Azure OpenAI embeddings (3072 dim)
- ✅ Smart query routing to relevant systems
- ✅ Cross-system linking (Autosys + Ab Initio)
- ✅ Structured responses by system
- ✅ AI-powered logic comparison
- ✅ Document search (PDFs, reports)
- ✅ Versioning and incremental updates

---

## Next Steps

**Immediate Actions (This Week)**:
1. Implement multi-collection indexer
2. Add Azure OpenAI embeddings
3. Create cross-system link documents
4. Test with sample queries

**Following Week**:
5. Implement query router
6. Create structured response formatter
7. Add logic comparison

**Month Goal**:
Complete all 8 phases and have production-ready RAG system

---

## Questions to Address

1. **Embedding Model Choice**: Use Azure text-embedding-3-large or keep sentence-transformers as backup?
2. **Collection Strategy**: Separate ChromaDB clients per collection or single client with namespaces?
3. **Versioning**: Store multiple versions in same collection or separate collections per version?
4. **Cost**: Azure OpenAI embeddings cost - batch generation vs on-demand?

---

**Status**: Ready to implement improvements
**Priority**: Phase 1-4 are critical for core functionality
**Timeline**: 4 weeks to full implementation
