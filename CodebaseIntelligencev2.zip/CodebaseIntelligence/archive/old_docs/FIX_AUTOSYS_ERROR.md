# ✅ Fixed: Autosys Parser Error

## Error
```
AttributeError: type object 'ProcessType' has no attribute 'JOB'
```

## Root Cause
The Autosys parser was trying to use `ProcessType.JOB` which didn't exist in the enum.

## Fix Applied

### 1. Added `AUTOSYS_JOB` to ProcessType Enum
**File:** [core/models/process.py](core/models/process.py:32)

```python
class ProcessType(Enum):
    """Types of processes"""
    # Ab Initio
    GRAPH = "graph"

    # Hadoop
    OOZIE_WORKFLOW = "oozie_workflow"
    OOZIE_COORDINATOR = "oozie_coordinator"

    # Databricks
    NOTEBOOK = "notebook"
    ADF_PIPELINE = "adf_pipeline"

    # Custom Documents
    DOCUMENT = "document"

    # Autosys Scheduler
    AUTOSYS_JOB = "autosys_job"  # ← NEW!

    # Generic
    ...
```

### 2. Added `AUTOSYS` to SystemType Enum
**File:** [core/models/process.py](core/models/process.py:12)

```python
class SystemType(Enum):
    """System types"""
    ABINITIO = "abinitio"
    HADOOP = "hadoop"
    DATABRICKS = "databricks"
    AUTOSYS = "autosys"  # ← NEW!
    CUSTOM = "custom"
```

### 3. Updated Autosys Parser
**File:** [parsers/autosys/parser.py](parsers/autosys/parser.py:317)

**Before:**
```python
process = Process(
    id=process_id,
    name=job_name,
    system=SystemType.ABINITIO if abinitio_graph else SystemType.CUSTOM,
    process_type=ProcessType.JOB,  # ← ERROR!
    ...
)
```

**After:**
```python
process = Process(
    id=process_id,
    name=job_name,
    system=SystemType.AUTOSYS,  # ← Fixed!
    process_type=ProcessType.AUTOSYS_JOB,  # ← Fixed!
    ...
)
```

## ✅ Error Fixed!

Now you can run:
```bash
python3 index_codebase.py --parser abinitio \
  --source /path/to/abinitio \
  --autosys /path/to/autosys_jobs \
  --deep
```

Should work without errors! 🚀
