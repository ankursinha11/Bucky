# Ab Initio Graph Filtering

## Overview
To solve the Excel size limit issue and focus on critical business graphs, the parser now filters and only processes **36 specific graphs** out of 387 total graphs.

## What Changed

### 1. Graph Filter Configuration
**File:** `parsers/abinitio/graph_filter_config.py`

Contains the list of 36 critical graphs organized by module:
- **Commercial Generation** (11 graphs)
- **Medicare Leads Generation** (6 graphs)
- **CDD** (15 graphs)
- **GHIC** (1 graph)
- **Data Ingestion** (5 graphs)

### 2. Parser Updates
**File:** `parsers/abinitio/parser.py`

- Added `enable_filter` parameter (default: `True`)
- Filters graphs during directory parsing
- Adds `module` field to each graph
- Logs filtered vs total graph counts

### 3. Excel Export Enhancement
**File:** `parsers/abinitio/parser.py` (export_to_excel)

Summary sheet now includes **Module** column showing which business module each graph belongs to

## Benefits

✅ **No data truncation** - All 36 graphs fully exported
✅ **Excel size manageable** - Under 1M rows per sheet
✅ **Business-focused** - Only critical graphs parsed
✅ **Faster parsing** - 36 graphs instead of 387
✅ **Module organization** - Easy to see which module each graph belongs to

## Usage

### Enabled by default (parse only 36 critical graphs)
```bash
python index_codebase.py --parser abinitio --source "D:\Abinito\ab_initio_workspace" --autosys "D:\Autosys" --deep
```

### Disable filter (parse all 387 graphs)
To disable filtering in code:
```python
from parsers.abinitio.integrated_parser import IntegratedAbInitioAutosysParser

# Disable filter
parser = IntegratedAbInitioAutosysParser(use_ai=True, enable_filter=False)
```

## Modifying the Filter

To add/remove graphs from the filter, edit:
**`parsers/abinitio/graph_filter_config.py`**

Update the `INCLUDED_GRAPHS` list with graph names (without `.mp` extension):

```python
INCLUDED_GRAPHS = [
    "100_commGenPrePrep",
    "105_commGenPrePrep",
    # ... add more graphs here
]
```

Also update `MODULE_MAP` to assign modules to new graphs.

## Excel Output Structure

### Multi-Project Export (blade + pub_escan)
Creates **3 Excel files**:

1. **`abinitio_integrated_analysis_blade.xlsx`**
   - GraphParameters
   - Components&Fields
   - GraphFlow
   - Summary (with Module column)

2. **`abinitio_integrated_analysis_pub_escan.xlsx`**
   - GraphParameters
   - Components&Fields
   - GraphFlow
   - Summary (with Module column)

3. **`abinitio_integrated_analysis_ALL_PROJECTS.xlsx`**
   - ProjectSummary
   - AutosysJobs (all 43 jobs)
   - OverallSummary

## Performance Impact

**Before filtering:**
- Total graphs found: 387
- Parsing time: ~5-10 minutes
- Excel size: 5M+ rows (exceeds limit)

**After filtering:**
- Total graphs found: 387
- Filtered graphs: 36 (351 skipped)
- Parsing time: ~1-2 minutes
- Excel size: Well under 1M rows per sheet

## Troubleshooting

### Graph not found
If a graph from the filter list is not found in the codebase:
- Check the graph name matches exactly (case-sensitive)
- Verify the graph exists in the Ab Initio directory
- Check if it's a `.mp` or `.plan` file

### Want to parse all graphs
Set `enable_filter=False` when creating the parser instance

### Excel still too large
If filtering to 36 graphs still creates sheets over 1M rows:
- Check component parameters (some graphs may have thousands of parameters per component)
- Consider splitting into smaller graph groups
- Use the CSV export option instead of Excel
