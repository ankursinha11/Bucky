# Agent-Based Chat - User Guide

**Date:** November 4, 2025
**Status:** Production Ready

---

## Overview

The STAG Chat tab now uses an **intelligent agent-based orchestration system** that mimics Claude Code's thinking process. Instead of just returning answers, it shows you:

1. **Thinking Process** - How it analyzes your question
2. **Task Decomposition** - Step-by-step plan
3. **Agent Execution** - Which specialized agents are called
4. **Final Answer** - Complete response with sources

---

## What Changed

### Before (Simple RAG)
```
User: "Compare Ab Initio and Hadoop workflows"
[Spinner shows "Analyzing..."]
Assistant: [Direct answer appears]
```

### After (Agent Orchestration)
```
User: "Compare Ab Initio and Hadoop workflows"

💭 Analyzing query: "Compare Ab Initio and Hadoop workflows"
💭 Intent detected: COMPARISON (confidence: 95%)
💭 Reasoning: Detected comparison query with 2 systems: abinitio, hadoop
💭 Systems involved: abinitio, hadoop

📋 Task Plan:
1. Parse entities from abinitio, hadoop
2. Extract transformations and logic
3. Compare implementations using similarity scoring
4. Identify differences and similarities
5. Generate comparison report

⚙️ Task 1/5: Parsing entities from 2 systems...
🤖 Using ParsingAgent to extract entity data...
  → Parsed abinitio entity
  → Parsed hadoop entity
✅ ParsingAgent completed: Parsed 2 systems

⚙️ Task 2/5: Extracting transformation logic...
🤖 Using LogicAgent to analyze transformations...
  → Analyzed abinitio logic
  → Analyzed hadoop logic
✅ LogicAgent completed: Analyzed 2 systems

[... continues through all tasks ...]

---
💡 Answer:
## Cross-System Comparison Results
[Detailed comparison with similarity scores, findings, etc.]
```

---

## Intent Types

The system automatically detects what type of question you're asking:

### 1. SIMPLE_RAG (Direct Questions)
**Triggers:** Basic questions answerable from documentation

**Examples:**
- "What is Ab Initio?"
- "How do I parse Autosys workflows?"
- "Show me the project structure"

**Agents Used:**
- RAGAgent (vector search)

**Task Plan:**
1. Search vector database
2. Retrieve top results
3. Generate answer from context

---

### 2. COMPARISON (Cross-System Queries)
**Triggers:** Questions comparing multiple systems

**Examples:**
- "Compare Ab Initio customer_load with Hadoop customer_etl"
- "What's the difference between these two workflows?"
- "Find similar implementations in Databricks"

**Agents Used:**
- ParsingAgent (extract entity data)
- LogicAgent (analyze transformations)
- SimilarityAgent (semantic matching)

**Task Plan:**
1. Parse entities from both systems
2. Extract transformation logic
3. Calculate similarity scores
4. Identify differences
5. Generate comparison report

---

### 3. LINEAGE (Data Flow Tracing)
**Triggers:** Questions about data lineage, sources, targets

**Examples:**
- "Where does customer_id come from?"
- "Trace the lineage of total_sales field"
- "Show me all dependencies for this column"

**Agents Used:**
- ParsingAgent (extract entity structure)
- MappingAgent (create STTM mappings)
- LineageAgent (build 3-level lineage)

**Task Plan:**
1. Parse entity for lineage analysis
2. Create column-level mappings (STTM)
3. Build dependency chains
4. Construct 3-level lineage
5. Format lineage report

---

### 4. LOGIC_ANALYSIS (Understanding Transformations)
**Triggers:** Questions about how code works

**Examples:**
- "Explain how this transformation works"
- "What does the customer aggregation logic do?"
- "Show me the business rules in this component"

**Agents Used:**
- ParsingAgent (retrieve code)
- LogicAgent (AI-powered analysis)
- RAGAgent (context enrichment)

**Task Plan:**
1. Retrieve code for analysis
2. Extract transformation logic
3. Interpret business rules using AI
4. Generate natural language explanation
5. Document findings

---

### 5. CODE_SEARCH (Finding Patterns)
**Triggers:** Questions about locating code

**Examples:**
- "Find all graphs that use customer_table"
- "Show me workflows with JOIN operations"
- "List all Databricks notebooks"

**Agents Used:**
- RAGAgent (vector search)
- ParsingAgent (code extraction)

**Task Plan:**
1. Search codebase for pattern
2. Filter by systems
3. Rank results by relevance
4. Extract code snippets
5. Present findings

---

## Viewing Agent Execution

### During Query Processing

While your query is being processed, you'll see real-time updates:

**Thinking Updates** (💭):
```
💭 Analyzing query: "Compare..."
💭 Intent detected: COMPARISON
💭 Reasoning: Detected comparison query...
```

**Task Plan** (📋):
```
📋 Task Plan:
1. Parse entities from systems
2. Extract transformation logic
3. Compare implementations
```

**Agent Execution** (⚙️/🤖/✅):
```
⚙️ Task 1/5: Parsing entities...
🤖 Using ParsingAgent to extract entity data...
  → Parsed abinitio entity
  → Parsed hadoop entity
✅ ParsingAgent completed: Parsed 2 systems
```

---

### After Query Completion

Click the **"📊 Query Details"** expander to see:

**🧠 Thinking Process:**
- All reasoning steps
- Intent classification
- Detected entities and systems

**📋 Task Plan:**
- Numbered list of planned tasks
- Shows the strategy used

**🔧 Agent Execution:**
- Complete log of agent calls
- Progress updates
- Completion confirmations

**📄 Data:**
- Raw JSON output
- Sources used
- Metadata

---

## Example Queries and Responses

### Example 1: Simple Question

**Query:**
```
"What parsers are available?"
```

**Intent:** SIMPLE_RAG

**Response:**
```
💭 Analyzing query: "What parsers are available?"
💭 Intent detected: SIMPLE_RAG (confidence: 60%)
💭 Reasoning: No specific patterns matched - using simple RAG search

📋 Task Plan:
1. Search vector database for: 'What parsers are available?'
2. Retrieve top 5 relevant chunks
3. Generate answer from context

⚙️ Task 1/3: Searching vector database...
✅ Found 5 relevant documents

⚙️ Task 2/3: Extracting relevant context...
✅ Extracted 5 context chunks

⚙️ Task 3/3: Generating answer using AI...
✅ Answer generated

---
💡 Answer:
The codebase includes three main parsers:
1. Ab Initio Parser - Parses .mp/.dml files
2. Autosys Parser - Parses JIL workflows
3. Document Parser - Parses PDF/DOCX/Excel files
```

---

### Example 2: Comparison Query

**Query:**
```
"Compare customer_load.graph from Ab Initio with customer_etl.hql from Hadoop"
```

**Intent:** COMPARISON

**Response:**
```
💭 Analyzing query: "Compare customer_load.graph from Ab Initio..."
💭 Intent detected: COMPARISON (confidence: 95%)
💭 Reasoning: Detected comparison query with 2 systems: abinitio, hadoop
💭 Entities detected: customer_load.graph, customer_etl.hql
💭 Systems involved: abinitio, hadoop

📋 Task Plan:
1. Parse entities from abinitio, hadoop
2. Extract transformations and logic
3. Compare implementations using similarity scoring
4. Identify differences and similarities
5. Generate comparison report

⚙️ Task 1/5: Parsing entities from 2 systems...
🤖 Using ParsingAgent to extract entity data...
  → Parsed abinitio entity
  → Parsed hadoop entity
✅ ParsingAgent completed: Parsed 2 systems

⚙️ Task 2/5: Extracting transformation logic...
🤖 Using LogicAgent to analyze transformations...
  → Analyzed abinitio logic
  → Analyzed hadoop logic
✅ LogicAgent completed: Analyzed 2 systems

⚙️ Task 3/5: Calculating cross-system similarity...
🤖 Using SimilarityAgent for semantic matching...
  → Similarity abinitio vs hadoop: 87%
✅ SimilarityAgent completed: 1 comparisons

⚙️ Task 4/5: Generating comparison report...
✅ Comparison report generated

⚙️ Task 5/5: Formatting final answer...

---
💡 Answer:
## Cross-System Comparison Results

**Systems Compared:** abinitio, hadoop

**Average Similarity:** 87%

### Key Findings:
- abinitio_vs_hadoop: 87% similar

### Detailed Analysis:

**ABINITIO:**
- Business Purpose: Load customer data with transformations
- Complexity: Medium

**HADOOP:**
- Business Purpose: ETL process for customer dimension
- Complexity: Medium
```

---

### Example 3: Lineage Query

**Query:**
```
"Trace the lineage of customer_total_spend field"
```

**Intent:** LINEAGE

**Response:**
```
💭 Analyzing query: "Trace the lineage of customer_total_spend field"
💭 Intent detected: LINEAGE (confidence: 90%)
💭 Reasoning: Detected lineage/tracing query with keywords: trace
💭 Entities detected: customer_total_spend
💭 Systems involved: [auto-detected from search]

📋 Task Plan:
1. Parse entity for lineage analysis
2. Create column-level mappings (STTM)
3. Build dependency chains
4. Construct 3-level lineage
5. Format lineage report

⚙️ Task 1/5: Parsing entity for lineage analysis...
🤖 Using ParsingAgent to extract entity structure...
✅ ParsingAgent completed: Entity structure extracted

⚙️ Task 2/5: Creating column-level mappings (STTM)...
🤖 Using MappingAgent to build source-target mappings...
  → Created 15 STTM mappings
✅ MappingAgent completed: 15 mappings created

⚙️ Task 3/5: Building dependency chains...
✅ Identified 15 field dependencies

⚙️ Task 4/5: Constructing 3-level lineage...
🤖 Using LineageAgent to build complete lineage...
  → Built flow-level lineage
  → Built logic-level lineage
  → Built column-level lineage
✅ LineageAgent completed: 3-level lineage built

⚙️ Task 5/5: Formatting lineage report...

---
💡 Answer:
## Data Lineage Analysis

**Entity:** customer_total_spend
**System:** hadoop

### Column-Level Mappings:
Found **15 field mappings**

1. **customer_total_spend** (decimal)
   - Sources: order_amount, customer_id
   - Logic: SUM(order_amount) GROUP BY customer_id

2. **customer_id** (int)
   - Sources: cust_id
   - Logic: CAST(cust_id AS INT)

[... more mappings ...]

### Dependencies:
- `customer_total_spend` depends on: order_amount, customer_id
- `customer_id` depends on: cust_id

### Lineage Levels:
- Flow-level: 3 process relationships
- Logic-level: 5 transformation groups
- Column-level: 15 field derivations
```

---

## Benefits of Agent-Based Chat

### 1. Transparency
- See exactly how the system processes your query
- Understand which agents are involved
- Track progress in real-time

### 2. Better Answers
- Specialized agents for different tasks
- AI reasoning for complex logic
- Multi-step processing for accuracy

### 3. Learning Tool
- Learn how to structure questions
- Understand system capabilities
- See agent coordination in action

### 4. Debugging
- Identify where queries fail
- See which agents succeeded/failed
- Review complete execution trace

### 5. Trust
- Full visibility into reasoning
- Source attribution
- Confidence scores

---

## Tips for Better Results

### 1. Be Specific
✅ **Good:** "Compare customer_load.graph from Ab Initio with customer_etl.hql"
❌ **Bad:** "Compare stuff"

### 2. Mention Systems
✅ **Good:** "Find Ab Initio graphs that use customer table"
❌ **Bad:** "Find graphs" (system unclear)

### 3. Use Domain Terms
✅ **Good:** "Trace lineage of customer_id field"
❌ **Bad:** "Where does this come from?" (unclear what "this" is)

### 4. One Intent Per Query
✅ **Good:** "Compare these two workflows" OR "Trace this lineage"
❌ **Bad:** "Compare workflows and trace lineage and find graphs" (multiple intents)

---

## Architecture

```
User Query
    ↓
Query Classifier
    ↓ (determines intent)
Chat Orchestrator
    ↓ (creates task plan)
Specialized Agents:
  - ParsingAgent
  - LogicAgent
  - MappingAgent
  - SimilarityAgent
  - LineageAgent
  - RAGAgent
    ↓
Stream Updates (real-time)
    ↓
Final Answer
```

---

## Agent Descriptions

### ParsingAgent
**Purpose:** Extract structured data from code entities
**Input:** System type, entity name, file path
**Output:** Parsed entity with transformations and metadata
**Used For:** Comparison, Lineage, Logic Analysis

---

### LogicAgent
**Purpose:** AI-powered transformation logic interpretation
**Input:** Transformation code
**Output:** Business purpose, complexity score, data quality rules
**Used For:** Comparison, Logic Analysis

---

### MappingAgent
**Purpose:** Create Source-Transform-Target Mappings (STTM)
**Input:** Parsed entity data
**Output:** List of column-level mappings with metadata
**Used For:** Lineage

---

### SimilarityAgent
**Purpose:** Find equivalent implementations across systems
**Input:** Entity data, target systems
**Output:** Similarity scores and matched entities
**Used For:** Comparison, Cross-system search

---

### LineageAgent
**Purpose:** Build 3-level lineage structure
**Input:** STTM mappings, entity data
**Output:** Flow/Logic/Column level lineage
**Used For:** Lineage tracing

---

### RAGAgent
**Purpose:** Vector search and context retrieval
**Input:** Query text
**Output:** Relevant documents from vector database
**Used For:** Simple RAG, Code Search

---

## Technical Details

### Streaming Implementation
- Uses Python generators for real-time updates
- Yields `StreamUpdate` objects at each step
- Streamlit containers for organized display

### Update Types
- `THINKING` - Analysis and reasoning
- `TASK_PLAN` - Task decomposition
- `TASK_START/PROGRESS/COMPLETE` - Task execution
- `AGENT_START/PROGRESS/COMPLETE` - Agent execution
- `FINAL_ANSWER` - Complete response
- `ERROR` - Error messages

### Metadata Tracking
Every response includes:
- `thinking` - All reasoning steps
- `task_plan` - Planned tasks
- `agent_execution` - Complete agent logs
- `data` - Raw JSON output
- `timestamp` - When response was generated

---

## Troubleshooting

### Issue: "Chat orchestrator not initialized"
**Solution:** Refresh the STAG page to reinitialize components

### Issue: Agent execution fails
**Symptom:** See error messages in agent execution section
**Solution:** Check the Query Details expander for full error trace

### Issue: Wrong intent detected
**Symptom:** System uses wrong agents for your query
**Solution:** Rephrase query with clearer keywords (e.g., "compare", "trace", "find")

### Issue: Slow responses
**Symptom:** Long wait times between updates
**Solution:** Normal for complex queries (comparison, lineage). Simpler queries are faster.

### Issue: Empty task plan
**Symptom:** No tasks shown in plan
**Solution:** Query may be too vague. Try being more specific.

---

## Comparison with Standard Chat

| Feature | Standard RAG | Agent-Based Chat |
|---------|-------------|------------------|
| **Thinking Visible** | ❌ No | ✅ Yes |
| **Task Plan** | ❌ No | ✅ Yes |
| **Agent Tracking** | ❌ No | ✅ Yes |
| **Multi-Step Processing** | ❌ Single step | ✅ Multiple tasks |
| **Specialized Handling** | ❌ One-size-fits-all | ✅ Intent-specific |
| **Transparency** | ⚠️ Limited | ✅ Full visibility |
| **Debugging** | ⚠️ Difficult | ✅ Easy with logs |

---

## Future Enhancements

### Planned (v1.1)
- Interactive task plan editing
- Agent performance metrics
- Custom intent patterns
- Query optimization suggestions

### Under Consideration (v2.0)
- Visual agent execution graph
- Agent result caching
- Parallel agent execution
- User-defined agents

---

## FAQ

**Q: Can I disable the thinking process display?**
A: Not currently, but it's collapsible in the "Query Details" expander after completion.

**Q: How many agents can run at once?**
A: Currently sequential. Parallel execution planned for v2.0.

**Q: Can I create custom agents?**
A: Not in v1.0. Custom agents planned for future release.

**Q: What's the performance impact?**
A: Minimal. Agent orchestration adds <0.5s overhead vs standard RAG.

**Q: Are streaming updates real-time?**
A: Yes, using Python generators for instant updates as agents complete tasks.

---

## Summary

The agent-based chat transforms STAG from a simple Q&A system into an **intelligent orchestration platform** that:

✅ Shows its thinking process
✅ Decomposes complex queries into tasks
✅ Calls specialized agents for each task
✅ Provides full transparency and traceability
✅ Handles 5 different intent types intelligently

**Try it now:** Go to the **💬 Chat** tab and ask a question!

---

**Version:** 1.0
**Last Updated:** November 4, 2025
**Status:** ✅ Production Ready
