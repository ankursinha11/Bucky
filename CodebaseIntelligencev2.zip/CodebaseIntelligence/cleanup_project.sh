#!/bin/bash

# Project Cleanup Script
# ======================
# Organizes files by moving old/redundant docs and tests to archive

echo "🧹 Cleaning up CodebaseIntelligence project..."
echo ""

# Create archive directories
mkdir -p archive/old_docs
mkdir -p archive/old_tests
mkdir -p archive/old_scripts

echo "📁 Creating archive directories..."

# Move redundant/old documentation
echo ""
echo "📄 Archiving old documentation files..."

OLD_DOCS=(
    "ALL_FIXES_SUMMARY.md"
    "COMPLETE_FIX_LIST.md"
    "FINAL_FIX_SUMMARY.md"
    "FIX_ALL_ERRORS.md"
    "FIX_AUTOSYS_ERROR.md"
    "COMPLETE_GRAPHFLOW_SOLUTION.md"
    "SESSION_ENHANCEMENTS.md"
    "IMPLEMENTATION_FILES.md"
    "ABINITIO_USAGE.md"
    "QUICK_START.md"
    "GRAPH_FILTER_README.md"
    "PROJECT_STATUS_SUMMARY.md"
    "ARCHITECTURE_ANALYSIS.md"
    "DEPLOYMENT_GUIDE.md"
    "ABINITIO_MULTIREPO_READY.md"
)

for doc in "${OLD_DOCS[@]}"; do
    if [ -f "$doc" ]; then
        echo "  Moving: $doc → archive/old_docs/"
        mv "$doc" archive/old_docs/
    fi
done

# Move test scripts
echo ""
echo "🧪 Archiving old test scripts..."

OLD_TESTS=(
    "VERIFY_FIX.py"
    "test_abinitio_multirepo.py"
    "test_single_project.py"
    "test_updated_parser.py"
    "check_vector_db.py"
)

for test in "${OLD_TESTS[@]}"; do
    if [ -f "$test" ]; then
        echo "  Moving: $test → archive/old_tests/"
        mv "$test" archive/old_tests/
    fi
done

# Show summary
echo ""
echo "✓ Cleanup complete!"
echo ""
echo "📊 Summary:"
echo "  • Old documentation moved to: archive/old_docs/"
echo "  • Old tests moved to: archive/old_tests/"
echo ""
echo "Essential files kept in root:"
echo ""
echo "📚 Documentation:"
echo "  ✓ README.md - Main project readme"
echo "  ✓ QUICK_REFERENCE.md - Quick commands"
echo "  ✓ STAG_README.md - STAG UI guide"
echo "  ✓ STAG_DATABASE_TAB_GUIDE.md - Database management in UI"
echo "  ✓ VECTOR_DB_MANAGEMENT.md - Vector DB CLI guide"
echo "  ✓ EMI_RAG_IMPLEMENTATION_GUIDE.md - Full implementation"
echo "  ✓ PROJECT_COMPLETION_SUMMARY.md - Project status"
echo "  ✓ FAWN_ENHANCEMENTS_README.md - FAWN features"
echo ""
echo "🚀 Main Scripts:"
echo "  ✓ stag_app.py - STAG Streamlit app"
echo "  ✓ start_stag.sh - Launch STAG"
echo "  ✓ manage_vector_db.py - Database management"
echo "  ✓ reindex.sh - Interactive reindexing"
echo "  ✓ index_codebase.py - Codebase indexing"
echo "  ✓ chatbot_cli.py - CLI chatbot"
echo "  ✓ run_analysis.py - Run analysis"
echo ""
echo "🔧 Utilities:"
echo "  ✓ setup_venv.sh - Virtual environment setup"
echo "  ✓ INSTALL.sh - Quick installer"
echo "  ✓ package_for_windows.sh - Windows packaging"
echo ""
echo "To restore archived files:"
echo "  mv archive/old_docs/<file> ."
echo ""
