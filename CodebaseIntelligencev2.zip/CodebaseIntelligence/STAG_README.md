# 🚀 STAG - Smart Transform and Analysis Generator

**Comprehensive Streamlit Frontend for CodebaseIntelligence RAG System**

STAG is an intelligent chatbot interface that enables natural language interaction with your multi-system codebase (Ab Initio, Hadoop, Databricks, Autosys).

---

## Features

### Core Capabilities
- ✅ **Multi-System Chat**: Query across Ab Initio, Hadoop, Databricks, Autosys in natural language
- ✅ **Conversation Memory**: Maintains context across queries
- ✅ **Intelligent Routing**: Automatically routes queries to relevant systems
- ✅ **Structured Responses**: Clean, system-by-system answers with confidence scores
- ✅ **Source Attribution**: Shows exactly where answers come from

### Advanced Features
- ✅ **On-the-Fly Indexing**: Upload and index files directly in the UI
- ✅ **Cross-System Comparison**: Compare logic across different platforms
- ✅ **Export Capabilities**: Export comparisons to Excel/PDF
- ✅ **Configurable AI**: Adjust temperature, top-k, top-p parameters
- ✅ **Fuzzy Matching**: Handles typos and common misspellings
- ✅ **Adaptive Learning**: Caches frequent queries for faster responses
- ✅ **Query History**: Track all queries in the session
- ✅ **Analytics Dashboard**: Visualize collection statistics
- ✅ **Database Management Tab**: Complete vector DB control in UI (clear, re-index, export stats)

---

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements_stag.txt
```

### 2. Set Environment Variables

```bash
export AZURE_OPENAI_API_KEY="your-api-key"
export AZURE_OPENAI_ENDPOINT="https://your-endpoint.openai.azure.com/"
export AZURE_OPENAI_API_VERSION="2024-02-15-preview"
export AZURE_OPENAI_DEPLOYMENT_NAME="gpt-4"
export AZURE_OPENAI_FAST_DEPLOYMENT="gpt-35-turbo"
export AZURE_OPENAI_EMBEDDING_MODEL="text-embedding-3-large"
```

### 3. Index Your Codebase (One-Time Setup)

```python
from services.multi_collection_indexer import MultiCollectionIndexer
from parsers.abinitio.parser import AbInitioParser
from parsers.autosys.parser import AutosysParser

# Initialize indexer
indexer = MultiCollectionIndexer()

# Parse and index Ab Initio
abinitio_parser = AbInitioParser()
result = abinitio_parser.parse_directory("/path/to/abinitio")
indexer.index_abinitio(result["processes"], result["components"])

# Parse and index Autosys
autosys_parser = AutosysParser()
result = autosys_parser.parse_directory("/path/to/autosys")
indexer.index_autosys([j.__dict__ for j in result["components"]])

# Create cross-system links
indexer.index_cross_system_links(
    autosys_jobs=[j.__dict__ for j in result["components"]],
    abinitio_processes=abinitio_result["processes"]
)
```

### 4. Launch STAG

```bash
streamlit run stag_app.py
```

The app will open in your browser at `http://localhost:8501`

---

## Using STAG

### Chat Interface

1. **Ask Questions** in natural language:
   - "What does the customer_load graph do?"
   - "Compare Hadoop and Ab Initio for customer processing"
   - "When does job_customer_etl run?"
   - "Show lineage for customer_id column"

2. **View Structured Responses**:
   - System-by-system breakdown
   - Confidence scores for each source
   - Source attribution with file paths

3. **Conversation Context**:
   - Follow-up questions maintain context
   - "Tell me more about that"
   - "How does it compare to Hadoop?"

### On-the-Fly File Upload

1. Click **"Upload Files"** in sidebar
2. Select .mp (Ab Initio), .jil (Autosys), or documents (PDF, Excel)
3. Click **"Index Uploaded Files"**
4. Files are immediately searchable

### Comparison Mode

1. Switch to **"Compare"** tab
2. Enter System 1 name (e.g., "customer_load.graph")
3. Enter System 2 name (e.g., "customer_load_spark.py")
4. Click **"Compare Logic"**
5. View:
   - Similarity score
   - Semantic equivalence
   - Key differences
   - Migration recommendations
6. Export to Excel or PDF

### Database Management Tab (NEW!)

1. Switch to **"⚙️ Database"** tab
2. **View Status**:
   - Total documents across all collections
   - Database size in MB
   - Per-collection statistics
3. **Select Operation** from dropdown:
   - **Clear Specific Collection**: Delete Ab Initio, Autosys, etc.
   - **Clear All Collections**: Full reset (requires "DELETE ALL" confirmation)
   - **Re-index Ab Initio/Autosys/Documents**: From directory or file upload
   - **Re-index Everything**: Complete fresh start
   - **Export Statistics**: Download JSON
4. **Track Progress**: Visual progress bars for all operations
5. **No CLI Needed**: Everything in the UI!

**See [STAG_DATABASE_TAB_GUIDE.md](STAG_DATABASE_TAB_GUIDE.md) for detailed guide**

### Configuration (Sidebar)

**AI Model Selection**:
- GPT-4 (best quality)
- GPT-4o (fast + quality balance)
- GPT-3.5 Turbo (fastest, cheapest)

**AI Parameters**:
- **Temperature**: 0.0 (deterministic) to 1.0 (creative)
- **Top K**: Number of search results (1-20)
- **Top P**: Nucleus sampling threshold (0.1-1.0)

**System Filters**:
- Select which systems to search
- Default: All systems

---

## Example Queries

### System-Specific Queries

```
"What components are in the customer_load graph?"
→ Routes to: abinitio_collection

"Show me all Spark jobs for customer processing"
→ Routes to: hadoop_collection

"List Databricks notebooks related to ETL"
→ Routes to: databricks_collection
```

### Cross-System Queries

```
"Compare customer load logic in Hadoop vs Ab Initio"
→ Routes to: hadoop_collection, abinitio_collection

"When does job_X run and what graph does it execute?"
→ Routes to: autosys_collection, cross_system_links

"Show end-to-end lineage for customer_id"
→ Routes to: ALL collections
```

### Schedule Queries

```
"What jobs run at 2 AM?"
→ Routes to: autosys_collection

"Show dependencies for job_customer_etl"
→ Routes to: autosys_collection, cross_system_links
```

---

## Advanced Features

### Adaptive Learning

STAG caches frequently asked queries for instant responses:

```python
# First query: 3-5 seconds (AI processing)
"What does customer_load do?"

# Same query later: <1 second (cached)
"What does customer_load do?"
```

### Fuzzy Matching

STAG auto-corrects common typos:

```
"abinito customer load" → "abinitio customer load"
"hadop scripts" → "hadoop scripts"
"sparc jobs" → "spark jobs"
```

### Confidence Scoring

Each source shows confidence based on relevance:

- **Green (80-100%)**: Highly relevant
- **Orange (60-79%)**: Moderately relevant
- **Red (<60%)**: Possibly relevant

---

## Architecture

```
┌─────────────────────────────────────────────────┐
│              STAG Streamlit UI                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐     │
│  │   Chat   │  │ Compare  │  │Analytics │     │
│  └──────────┘  └──────────┘  └──────────┘     │
└─────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────┐
│           RAG Processing Layer                  │
│  ┌────────────┐  ┌─────────────┐  ┌─────────┐ │
│  │   Query    │→ │   Multi-    │→ │Response │ │
│  │   Router   │  │ Collection  │  │Formatter│ │
│  └────────────┘  │  Indexer    │  └─────────┘ │
│                  └─────────────┘                │
└─────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────┐
│          Vector Database (ChromaDB)             │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌──────┐ │
│  │AbInitio │ │ Hadoop  │ │Databricks│ │Autosys││
│  │Collection│ │Collection│ │Collection│ │Collection││
│  └─────────┘ └─────────┘ └─────────┘ └──────┘ │
│  ┌──────────┐ ┌──────────┐                     │
│  │Cross-Sys │ │Documents │                     │
│  │  Links   │ │Collection│                     │
│  └──────────┘ └──────────┘                     │
└─────────────────────────────────────────────────┘
```

---

## Troubleshooting

### Issue: "Indexer not initialized"

**Solution**: Ensure vector database exists. Run initial indexing:

```python
from services.multi_collection_indexer import MultiCollectionIndexer
indexer = MultiCollectionIndexer()
```

### Issue: "No results found"

**Solution**: Check collections are indexed:

```python
stats = indexer.get_stats()
print(stats)
```

### Issue: "Azure OpenAI error"

**Solution**: Verify environment variables:

```bash
echo $AZURE_OPENAI_API_KEY
echo $AZURE_OPENAI_ENDPOINT
```

Or use local embeddings:

```python
from services.azure_embeddings import create_embedding_client
client = create_embedding_client(use_azure=False)
```

### Issue: "Slow responses"

**Solutions**:
1. Switch to GPT-3.5 Turbo (faster)
2. Reduce Top K (fewer results)
3. Enable caching (automatic in STAG)

---

## Keyboard Shortcuts

- **Ctrl+L**: Clear conversation
- **Ctrl+Enter**: Send message
- **Esc**: Close expanders

---

## Performance Tips

1. **Use Fast Model for Simple Queries**: GPT-3.5 Turbo for simple lookups
2. **Limit Top K**: Start with 3-5 results, increase if needed
3. **Cache Frequent Queries**: Automatic in STAG
4. **Index Incrementally**: Upload small batches of files

---

## Export Options

### Chat History Export

1. Click **"Export Chat History"** in sidebar
2. Downloads JSON file with full conversation
3. Includes timestamps, routing info, sources

### Comparison Export

**Excel**:
- Summary sheet: Similarity, equivalence
- Differences sheet: All differences in table format
- Migration sheet: Recommendations

**PDF** (coming soon):
- Formatted report with charts
- Side-by-side code comparison

---

## Support & Documentation

### Quick Help
- Press `?` in UI for tooltips
- Hover over settings for explanations

### Full Documentation
- [QUICK_REFERENCE.md](QUICK_REFERENCE.md) - Quick commands
- [EMI_RAG_IMPLEMENTATION_GUIDE.md](EMI_RAG_IMPLEMENTATION_GUIDE.md) - Full implementation
- [PROJECT_STATUS_SUMMARY.md](PROJECT_STATUS_SUMMARY.md) - Project status

### Example Workflows
- See [QUICK_REFERENCE.md](QUICK_REFERENCE.md) for common tasks

---

## Roadmap

### v1.1 (Next Release)
- [ ] PDF report generation with charts
- [ ] Lineage visualization (interactive graph)
- [ ] Multi-language support (Spanish, French, etc.)
- [ ] Voice input/output
- [ ] Slack/Teams integration

### v1.2 (Future)
- [ ] Code generation (Ab Initio → Spark)
- [ ] Automated testing suggestions
- [ ] Performance optimization recommendations
- [ ] Git integration for versioning

---

## Credits

Built with:
- **Streamlit**: Web UI framework
- **Azure OpenAI**: AI/LLM capabilities
- **ChromaDB**: Vector database
- **Sentence Transformers**: Local embeddings

---

## License

Internal use only. See your organization's license agreement.

---

## Contact

For support, issues, or feature requests:
- Check documentation in `/CodebaseIntelligence/`
- Review logs in UI (sidebar → "View Logs")

---

**Status**: ✅ Production Ready
**Version**: 1.0
**Last Updated**: November 2, 2025

🚀 **Happy querying with STAG!**
